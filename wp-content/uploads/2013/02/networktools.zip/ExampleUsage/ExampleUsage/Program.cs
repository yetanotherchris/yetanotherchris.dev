using System;
using System.Collections.Generic;
using System.Text;

namespace Sloppycode
{
    class Program
    {
        /// <summary>
        /// This example does a Nameserver lookup, but the others are left in as examples.
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            Console.WriteLine( "Please enter your ISP's DNS server or prefered DNS server:" );
            string dnsServer = Console.ReadLine();

            Console.WriteLine( "Enter a hostname:" );
            string hostname = Console.ReadLine();

            DnsEx.DnsServers = new string[] { dnsServer };
            DnsEx dns = new DnsEx();
            DnsServerResponse response = null;
            response = dns.Query( hostname, QTYPE.NS );
            StringBuilder sb = new StringBuilder();

            // Alternative lookups
            // response = dns.Query(this.TextBoxQuery.Text, QTYPE.CNAME);
            // response = dns.Query(this.TextBoxQuery.Text, QTYPE.MX);

            foreach ( object rec in response.Answers )
            {

                if ( rec is NS_Record )
                {
                    sb.Append( ( (NS_Record) rec ).NameServer + "\n" );
                }
                else if ( rec is CNAME_Record )
                {
                    sb.Append( ( (CNAME_Record) rec ).Alias + "\n" );
                }

                else if ( rec is MX_Record )
                {
                    sb.Append( ( (MX_Record) rec ).Host + " " );
                    sb.Append( "(Preference: " + ( (MX_Record) rec ).Preference.ToString() + ") \n" );
                }
            }

            // Show the results
            Console.WriteLine("");
            Console.WriteLine( "Results:" );
            Console.WriteLine( sb.ToString() );
            Console.ReadLine();
        }
    }
}
