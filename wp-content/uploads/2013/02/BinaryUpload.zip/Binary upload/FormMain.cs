using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using System.Resources;
using System.IO;
using System.Threading;

namespace BinaryUpload
{
	/// <summary>
	/// This uses a global connection, which ideally should be changed to a
	/// using ( dbconnection = new SqlConnection(...) ) { } clause instead
	/// </summary>
	public class FormMain : System.Windows.Forms.Form
	{
		#region Components
		private System.Windows.Forms.OpenFileDialog openFileDialog1;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.Button buttonUpload;
		private System.Windows.Forms.Button buttonChooseFile;
		private System.Windows.Forms.Button buttonCancel;
		private System.Windows.Forms.Label labelPassword;
		private System.Windows.Forms.Label labelUsername;
		private System.Windows.Forms.Label labelHost;
		private System.Windows.Forms.ComboBox comboBoxDatabase;
		private System.Windows.Forms.ComboBox comboBoxTable;
		private System.Windows.Forms.ComboBox comboBoxColumn;
		private System.Windows.Forms.TextBox textBoxHost;
		private System.Windows.Forms.TextBox textBoxUsername;
		private System.Windows.Forms.TextBox textBoxPassword;
		private System.Windows.Forms.Label labelDatabase;
		private System.Windows.Forms.Label labelTable;
		private System.Windows.Forms.Label labelColumn;
		private System.Windows.Forms.Button buttonConnect;
		private System.Windows.Forms.StatusBar statusBar1;
		private System.Windows.Forms.StatusBarPanel statusBarPanel1;
		private System.Windows.Forms.StatusBarPanel statusBarPanel2;
		private System.ComponentModel.IContainer components;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.CheckBox checkBoxWhereClause;
		private System.Windows.Forms.TextBox textBoxPkColumn;
		private System.Windows.Forms.TextBox textBoxPKColumnId;
		private System.Windows.Forms.GroupBox groupBox3;
		private System.Windows.Forms.Label label1;
		#endregion

		#region Private fields
		private SqlConnection dbConnection;
		private bool isDbConnection = false;
		private string uploadFilename = "";
		#endregion

		#region Constructor, dispose, main
		public FormMain()
		{
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new FormMain());
		}
		#endregion

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(FormMain));
			this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			this.buttonUpload = new System.Windows.Forms.Button();
			this.buttonChooseFile = new System.Windows.Forms.Button();
			this.buttonCancel = new System.Windows.Forms.Button();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.buttonConnect = new System.Windows.Forms.Button();
			this.textBoxPassword = new System.Windows.Forms.TextBox();
			this.textBoxUsername = new System.Windows.Forms.TextBox();
			this.textBoxHost = new System.Windows.Forms.TextBox();
			this.labelPassword = new System.Windows.Forms.Label();
			this.labelUsername = new System.Windows.Forms.Label();
			this.labelHost = new System.Windows.Forms.Label();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.label1 = new System.Windows.Forms.Label();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.textBoxPKColumnId = new System.Windows.Forms.TextBox();
			this.textBoxPkColumn = new System.Windows.Forms.TextBox();
			this.checkBoxWhereClause = new System.Windows.Forms.CheckBox();
			this.label3 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.labelColumn = new System.Windows.Forms.Label();
			this.labelTable = new System.Windows.Forms.Label();
			this.labelDatabase = new System.Windows.Forms.Label();
			this.comboBoxColumn = new System.Windows.Forms.ComboBox();
			this.comboBoxTable = new System.Windows.Forms.ComboBox();
			this.comboBoxDatabase = new System.Windows.Forms.ComboBox();
			this.statusBar1 = new System.Windows.Forms.StatusBar();
			this.statusBarPanel1 = new System.Windows.Forms.StatusBarPanel();
			this.statusBarPanel2 = new System.Windows.Forms.StatusBarPanel();
			this.groupBox1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel2)).BeginInit();
			this.SuspendLayout();
			// 
			// openFileDialog1
			// 
			this.openFileDialog1.Filter = "All files|*.*";
			// 
			// buttonUpload
			// 
			this.buttonUpload.Enabled = false;
			this.buttonUpload.Location = new System.Drawing.Point(290, 357);
			this.buttonUpload.Name = "buttonUpload";
			this.buttonUpload.TabIndex = 0;
			this.buttonUpload.Text = "Upload";
			this.buttonUpload.Click += new System.EventHandler(this.buttonUpload_Click);
			// 
			// buttonChooseFile
			// 
			this.buttonChooseFile.Location = new System.Drawing.Point(208, 357);
			this.buttonChooseFile.Name = "buttonChooseFile";
			this.buttonChooseFile.TabIndex = 1;
			this.buttonChooseFile.Text = "Choose file";
			this.buttonChooseFile.Click += new System.EventHandler(this.buttonChooseFile_Click);
			// 
			// buttonCancel
			// 
			this.buttonCancel.Location = new System.Drawing.Point(372, 357);
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.TabIndex = 2;
			this.buttonCancel.Text = "Cancel";
			this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.buttonConnect);
			this.groupBox1.Controls.Add(this.textBoxPassword);
			this.groupBox1.Controls.Add(this.textBoxUsername);
			this.groupBox1.Controls.Add(this.textBoxHost);
			this.groupBox1.Controls.Add(this.labelPassword);
			this.groupBox1.Controls.Add(this.labelUsername);
			this.groupBox1.Controls.Add(this.labelHost);
			this.groupBox1.Location = new System.Drawing.Point(8, 8);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(440, 115);
			this.groupBox1.TabIndex = 9;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = " Connection details";
			// 
			// buttonConnect
			// 
			this.buttonConnect.Location = new System.Drawing.Point(358, 86);
			this.buttonConnect.Name = "buttonConnect";
			this.buttonConnect.TabIndex = 14;
			this.buttonConnect.Text = "Connect";
			this.buttonConnect.Click += new System.EventHandler(this.buttonConnect_Click);
			// 
			// textBoxPassword
			// 
			this.textBoxPassword.Location = new System.Drawing.Point(104, 79);
			this.textBoxPassword.Name = "textBoxPassword";
			this.textBoxPassword.PasswordChar = '*';
			this.textBoxPassword.Size = new System.Drawing.Size(232, 21);
			this.textBoxPassword.TabIndex = 13;
			this.textBoxPassword.Text = "";
			// 
			// textBoxUsername
			// 
			this.textBoxUsername.Location = new System.Drawing.Point(104, 54);
			this.textBoxUsername.Name = "textBoxUsername";
			this.textBoxUsername.Size = new System.Drawing.Size(232, 21);
			this.textBoxUsername.TabIndex = 12;
			this.textBoxUsername.Text = "";
			// 
			// textBoxHost
			// 
			this.textBoxHost.Location = new System.Drawing.Point(104, 30);
			this.textBoxHost.Name = "textBoxHost";
			this.textBoxHost.Size = new System.Drawing.Size(232, 21);
			this.textBoxHost.TabIndex = 11;
			this.textBoxHost.Text = "";
			// 
			// labelPassword
			// 
			this.labelPassword.Location = new System.Drawing.Point(8, 79);
			this.labelPassword.Name = "labelPassword";
			this.labelPassword.Size = new System.Drawing.Size(56, 16);
			this.labelPassword.TabIndex = 10;
			this.labelPassword.Text = "Password";
			// 
			// labelUsername
			// 
			this.labelUsername.Location = new System.Drawing.Point(8, 54);
			this.labelUsername.Name = "labelUsername";
			this.labelUsername.Size = new System.Drawing.Size(56, 16);
			this.labelUsername.TabIndex = 9;
			this.labelUsername.Text = "Username";
			// 
			// labelHost
			// 
			this.labelHost.Location = new System.Drawing.Point(8, 30);
			this.labelHost.Name = "labelHost";
			this.labelHost.Size = new System.Drawing.Size(38, 16);
			this.labelHost.TabIndex = 8;
			this.labelHost.Text = "Host";
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.label1);
			this.groupBox2.Controls.Add(this.groupBox3);
			this.groupBox2.Controls.Add(this.textBoxPKColumnId);
			this.groupBox2.Controls.Add(this.textBoxPkColumn);
			this.groupBox2.Controls.Add(this.checkBoxWhereClause);
			this.groupBox2.Controls.Add(this.label3);
			this.groupBox2.Controls.Add(this.label2);
			this.groupBox2.Controls.Add(this.labelColumn);
			this.groupBox2.Controls.Add(this.labelTable);
			this.groupBox2.Controls.Add(this.labelDatabase);
			this.groupBox2.Controls.Add(this.comboBoxColumn);
			this.groupBox2.Controls.Add(this.comboBoxTable);
			this.groupBox2.Controls.Add(this.comboBoxDatabase);
			this.groupBox2.Location = new System.Drawing.Point(8, 128);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(440, 221);
			this.groupBox2.TabIndex = 10;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Destination to insert into";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 117);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(424, 16);
			this.label1.TabIndex = 21;
			this.label1.Text = "If there is no where clause (an insert), then the other columns should allow null" +
				"s.";
			// 
			// groupBox3
			// 
			this.groupBox3.Location = new System.Drawing.Point(9, 104);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(415, 8);
			this.groupBox3.TabIndex = 20;
			this.groupBox3.TabStop = false;
			// 
			// textBoxPKColumnId
			// 
			this.textBoxPKColumnId.Enabled = false;
			this.textBoxPKColumnId.Location = new System.Drawing.Point(104, 184);
			this.textBoxPKColumnId.Name = "textBoxPKColumnId";
			this.textBoxPKColumnId.Size = new System.Drawing.Size(24, 21);
			this.textBoxPKColumnId.TabIndex = 19;
			this.textBoxPKColumnId.Text = "";
			// 
			// textBoxPkColumn
			// 
			this.textBoxPkColumn.Enabled = false;
			this.textBoxPkColumn.Location = new System.Drawing.Point(104, 160);
			this.textBoxPkColumn.Name = "textBoxPkColumn";
			this.textBoxPkColumn.TabIndex = 18;
			this.textBoxPkColumn.Text = "";
			// 
			// checkBoxWhereClause
			// 
			this.checkBoxWhereClause.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.checkBoxWhereClause.Location = new System.Drawing.Point(8, 136);
			this.checkBoxWhereClause.Name = "checkBoxWhereClause";
			this.checkBoxWhereClause.Size = new System.Drawing.Size(110, 24);
			this.checkBoxWhereClause.TabIndex = 17;
			this.checkBoxWhereClause.Text = "Where clause?";
			this.checkBoxWhereClause.CheckedChanged += new System.EventHandler(this.checkBoxWhereClause_CheckedChanged);
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(9, 192);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(79, 16);
			this.label3.TabIndex = 16;
			this.label3.Text = "PK Column Id";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(8, 168);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(96, 16);
			this.label2.TabIndex = 15;
			this.label2.Text = "PK Column name";
			// 
			// labelColumn
			// 
			this.labelColumn.Location = new System.Drawing.Point(8, 80);
			this.labelColumn.Name = "labelColumn";
			this.labelColumn.Size = new System.Drawing.Size(88, 16);
			this.labelColumn.TabIndex = 13;
			this.labelColumn.Text = "Binary Column";
			// 
			// labelTable
			// 
			this.labelTable.Location = new System.Drawing.Point(8, 52);
			this.labelTable.Name = "labelTable";
			this.labelTable.Size = new System.Drawing.Size(56, 16);
			this.labelTable.TabIndex = 12;
			this.labelTable.Text = "Table";
			// 
			// labelDatabase
			// 
			this.labelDatabase.Location = new System.Drawing.Point(8, 24);
			this.labelDatabase.Name = "labelDatabase";
			this.labelDatabase.Size = new System.Drawing.Size(56, 16);
			this.labelDatabase.TabIndex = 11;
			this.labelDatabase.Text = "Database";
			// 
			// comboBoxColumn
			// 
			this.comboBoxColumn.Enabled = false;
			this.comboBoxColumn.Location = new System.Drawing.Point(104, 80);
			this.comboBoxColumn.Name = "comboBoxColumn";
			this.comboBoxColumn.Size = new System.Drawing.Size(304, 21);
			this.comboBoxColumn.TabIndex = 2;
			this.comboBoxColumn.TextChanged += new System.EventHandler(this.comboBoxColumn_TextChanged);
			// 
			// comboBoxTable
			// 
			this.comboBoxTable.Enabled = false;
			this.comboBoxTable.Location = new System.Drawing.Point(104, 52);
			this.comboBoxTable.Name = "comboBoxTable";
			this.comboBoxTable.Size = new System.Drawing.Size(304, 21);
			this.comboBoxTable.TabIndex = 1;
			this.comboBoxTable.TextChanged += new System.EventHandler(this.comboBoxTable_TextChanged);
			// 
			// comboBoxDatabase
			// 
			this.comboBoxDatabase.Enabled = false;
			this.comboBoxDatabase.Location = new System.Drawing.Point(104, 24);
			this.comboBoxDatabase.Name = "comboBoxDatabase";
			this.comboBoxDatabase.Size = new System.Drawing.Size(304, 21);
			this.comboBoxDatabase.TabIndex = 0;
			this.comboBoxDatabase.TextChanged += new System.EventHandler(this.comboBoxDatabase_TextChanged);
			// 
			// statusBar1
			// 
			this.statusBar1.Location = new System.Drawing.Point(0, 386);
			this.statusBar1.Name = "statusBar1";
			this.statusBar1.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
																						  this.statusBarPanel1,
																						  this.statusBarPanel2});
			this.statusBar1.ShowPanels = true;
			this.statusBar1.Size = new System.Drawing.Size(458, 22);
			this.statusBar1.SizingGrip = false;
			this.statusBar1.TabIndex = 11;
			this.statusBar1.Text = "statusBar1";
			// 
			// statusBarPanel1
			// 
			this.statusBarPanel1.Width = 428;
			// 
			// statusBarPanel2
			// 
			this.statusBarPanel2.Icon = ((System.Drawing.Icon)(resources.GetObject("statusBarPanel2.Icon")));
			this.statusBarPanel2.Width = 32;
			// 
			// FormMain
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(458, 408);
			this.Controls.Add(this.statusBar1);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.buttonCancel);
			this.Controls.Add(this.buttonChooseFile);
			this.Controls.Add(this.buttonUpload);
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Name = "FormMain";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Insert file into database";
			this.groupBox1.ResumeLayout(false);
			this.groupBox2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel2)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion
	
		#region Choose file, connect button event handling
		private void buttonChooseFile_Click(object sender, System.EventArgs e)
		{
			openFileDialog1.ShowDialog();

			// There's a file, its path and file exists
			if ( openFileDialog1.FileName != "" 
				&& openFileDialog1.CheckFileExists
				&& openFileDialog1.CheckPathExists
				)
			{
				uploadFilename = openFileDialog1.FileName;
				statusBarPanel1.Text = uploadFilename;
				enableUploadButton();
			}
		}

		private void buttonConnect_Click(object sender, System.EventArgs e)
		{
			
			if ( textBoxHost.Text == "" )
			{
				MessageBox.Show("Please enter a database host","Installer Upload",MessageBoxButtons.OK,MessageBoxIcon.Information);
				return;
			} 
			else if ( textBoxUsername.Text == "" )
			{
				MessageBox.Show("Please enter a database username","Installer Upload",MessageBoxButtons.OK,MessageBoxIcon.Information);
			}
			else
			{
				// Check if there is a database connection
				// already, if so close it
				if ( isDbConnection )
				{
					try
					{
						dbConnection.Close();
					}
					finally
					{
						//
					}
				}

				// Make up DSN, and connect
				string DSN = "Server=" +textBoxHost.Text;
				DSN += ";uid=" +textBoxUsername.Text;
				DSN += ";pwd=" +textBoxPassword.Text;

				dbConnection = new SqlConnection( DSN );
	
				// Try to connect, otherwise throw error
				try
				{
					dbConnection.Open();	
				}
				catch (SqlException error) 
				{
					dbConnection.Close();

					MessageBox.Show("Error #" + error.Number + " connecting to database.\nDescription: " + error.Message);
					return;

				}
				finally
				{
				
				}


				isDbConnection = true;

				// Change the bottom right icon
				ResourceManager rm = new ResourceManager( this.GetType() );
				Icon dbIcon = (Icon) rm.GetObject("greenIcon");
				statusBarPanel2.Icon = dbIcon;

				// Populate the list of databases
				// (tables + columns are done dynmically)
				DataSet dataSet = GetDatabases();
				DataTable dataTable = dataSet.Tables[0];

				// Loop through the row collection
				// of row objects, add to the list box
				comboBoxDatabase.Enabled = true;
				comboBoxDatabase.Items.Clear();
				foreach (DataRow dataRow in dataTable.Rows)
				{
					comboBoxDatabase.Items.Add( dataRow["DATABASE_NAME"] );
				}
				comboBoxDatabase.SelectedIndex = 0;
			}
		}
		#endregion

		#region Helpers
		private DataSet GetDatabases()
		{
			SqlCommand sqlCommand = new SqlCommand("sp_databases", dbConnection);
			sqlCommand.CommandType = CommandType.StoredProcedure;

			// Fill a dataset
			DataSet dataSet = new DataSet();
			try
			{
				SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
				sqlDataAdapter.SelectCommand = sqlCommand;

				sqlDataAdapter.Fill(dataSet);
			}
			catch (SqlException error) 
			{
				dbConnection.Close();

				MessageBox.Show("Error #" + error.Number + " connecting to database.\nDescription: " + error.Message,"Installer Upload",MessageBoxButtons.OK,MessageBoxIcon.Information);
				return dataSet;

			}
			finally
			{
				// Error catching here
			}
			return dataSet;
			
		}

		private DataSet GetTables(string databaseName)
		{
			SqlCommand sqlCommand = new SqlCommand("sp_tables", dbConnection);
			sqlCommand.CommandType = CommandType.StoredProcedure;
			
			SqlParameter sqlParameter = new SqlParameter();

			sqlParameter = sqlCommand.Parameters.Add("@table_qualifier", SqlDbType.VarChar);
			sqlParameter.Value = databaseName;
			sqlParameter.Direction = ParameterDirection.Input;

			// Fill a dataset
			DataSet dataSet = new DataSet();
			try
			{
				SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
				sqlDataAdapter.SelectCommand = sqlCommand;
	
				sqlDataAdapter.Fill(dataSet);
				
			}
			catch (SqlException error) 
			{
				dbConnection.Close();

				MessageBox.Show("Error #" + error.Number + " connecting to database.\nDescription: " + error.Message,"Installer Upload",MessageBoxButtons.OK,MessageBoxIcon.Information);
				return dataSet;

			}
			finally
			{
				// Error catching here
			}

			return dataSet;

		}

		private DataSet GetColumns(string tableName)
		{	
			SqlCommand sqlCommand = new SqlCommand("sp_columns", dbConnection);
			sqlCommand.CommandType = CommandType.StoredProcedure;
			
			SqlParameter sqlParameter = new SqlParameter();

			sqlParameter = sqlCommand.Parameters.Add("@table_name", SqlDbType.VarChar);
			sqlParameter.Value = tableName;
			sqlParameter.Direction = ParameterDirection.Input;

			// Fill a dataset
			DataSet dataSet = new DataSet();
			try
			{
				SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
				sqlDataAdapter.SelectCommand = sqlCommand;
	
				sqlDataAdapter.Fill(dataSet);
				
			}
			catch (SqlException error) 
			{
				dbConnection.Close();

				MessageBox.Show("Error #" + error.Number + " connecting to database.\nDescription: " + error.Message,"Installer Upload",MessageBoxButtons.OK,MessageBoxIcon.Information);
				return dataSet;

			}
			finally
			{
				// Error catching here
			}

			return dataSet;
		}


		private void comboBoxDatabase_TextChanged(object sender, System.EventArgs e)
		{
			statusBarPanel1.Text = comboBoxDatabase.SelectedItem.ToString();
			if ( comboBoxDatabase.SelectedItem.ToString() != "" )
			{		
				dbConnection.ChangeDatabase(comboBoxDatabase.SelectedItem.ToString());
				
				// Populate the list of tables
				DataSet dataSet = GetTables(comboBoxDatabase.SelectedItem.ToString());
				DataTable dataTable = dataSet.Tables[0];

				// Loop through the row collection
				// of row objects, add to the list box
				comboBoxTable.Enabled = true;
				comboBoxTable.Items.Clear();
				foreach (DataRow dataRow in dataTable.Rows)
				{
					comboBoxTable.Items.Add( dataRow["TABLE_NAME"] );
				}
				comboBoxTable.SelectedIndex = 0;
			}
			else
			{
				comboBoxTable.Items.Clear();
				comboBoxTable.Enabled = false;
			}
		}

		private void comboBoxTable_TextChanged(object sender, System.EventArgs e)
		{
			if ( comboBoxTable.SelectedItem.ToString() != "" )
			{
				// Populate the list of columns
				DataSet dataSet = GetColumns( comboBoxTable.SelectedItem.ToString() );
				DataTable dataTable = dataSet.Tables[0];

				// Loop through the row collection
				// of row objects, add to the list box
				comboBoxColumn.Enabled = true;
				comboBoxColumn.Items.Clear();
				foreach (DataRow dataRow in dataTable.Rows)
				{
					comboBoxColumn.Items.Add( dataRow["COLUMN_NAME"] );
				}
				comboBoxColumn.SelectedIndex = 0;
			}
			else
			{
				comboBoxColumn.Items.Clear();
				comboBoxColumn.Enabled = false;
			}
		}

		private void comboBoxColumn_TextChanged(object sender, System.EventArgs e)
		{

			enableUploadButton();
		}

		private void enableUploadButton()
		{
			if ( comboBoxDatabase.SelectedItem.ToString() != "" &&  
				 comboBoxTable.SelectedItem.ToString() != "" && 
				 comboBoxColumn.SelectedItem.ToString() != "" && 
				 uploadFilename != "")
			{
				buttonUpload.Enabled = true;
			}
			else if ( comboBoxColumn.SelectedItem.ToString() == "" )
			{
				buttonUpload.Enabled = false;
			}

		}
		private void buttonUpload_Click(object sender, System.EventArgs e)
		{
			
			if ( comboBoxDatabase.SelectedItem.ToString() != "" &&  
				 comboBoxTable.SelectedItem.ToString() != "" && 
				 comboBoxColumn.SelectedItem.ToString() != "" && 
				 uploadFilename != ""
				)
			{
				this.Cursor = Cursors.WaitCursor;
				this.buttonCancel.Enabled = false;
				this.buttonChooseFile.Enabled = false;
				this.buttonUpload.Enabled = false;

				if ( File2SqlBlob(uploadFilename) )
				{
					MessageBox.Show("File uploaded successfully");
				}

				this.Cursor = Cursors.Default;
				this.buttonCancel.Enabled = true;
				this.buttonChooseFile.Enabled = true;
				this.buttonUpload.Enabled = true;
			}
			else
			{
				MessageBox.Show("Please a database/table/column","Installer Upload",MessageBoxButtons.OK,MessageBoxIcon.Information);
			}
		}

		private bool File2SqlBlob(string sourceFilePath)
		{
			// Open the file, read its contents
			FileStream fileStream = new FileStream(sourceFilePath,FileMode.Open,FileAccess.Read);
			byte[] fileContents = new byte[fileStream.Length];
			fileStream.Read(fileContents,0,fileContents.Length);
			fileStream.Close();

			if ( this.checkBoxWhereClause.Checked )
			{
				string sql;
				sql  = "UPDATE " +comboBoxTable.SelectedItem.ToString()+ " ";
				sql += "SET " +comboBoxColumn.SelectedItem.ToString()+ "=(@image) ";
				sql += "WHERE " +this.textBoxPkColumn.Text+ "=" +this.textBoxPKColumnId.Text;
				this.statusBarPanel1.Text = sql;
			
				SqlCommand sqlCommand = new SqlCommand(sql);
				SqlParameter sqlParam = new SqlParameter("@image",fileContents);
				sqlCommand.Parameters.Add(sqlParam);
				sqlCommand.Connection = dbConnection;

				try
				{
					sqlCommand.ExecuteNonQuery();
					return true;
				}
				catch (SqlException er)
				{
					MessageBox.Show(er.Message);
					return false;
				}

			}
			else
			{
				// Execute SQL Query (assumes db connection is already open)
				string sql;
				sql  = "INSERT INTO " + comboBoxTable.SelectedItem.ToString();
				sql += "(" + comboBoxColumn.SelectedItem.ToString() + ") VALUES ";
				sql += "(@image)";
				this.statusBarPanel1.Text = sql;
			
				SqlCommand sqlCommand = new SqlCommand(sql);
				SqlParameter sqlParam = new SqlParameter("@image",fileContents);
				sqlCommand.Parameters.Add(sqlParam);
				sqlCommand.Connection = dbConnection;

				try
				{
					sqlCommand.ExecuteNonQuery();
					return true;
				}
				catch (SqlException er)
				{
					MessageBox.Show(er.Message);
					return false;
				}
			}

		}
		#endregion

		#region Cancel, where clause checkbox
		private void buttonCancel_Click(object sender, System.EventArgs e)
		{
			Application.Exit();
		}

		private void checkBoxWhereClause_CheckedChanged(object sender, System.EventArgs e)
		{
			this.textBoxPkColumn.Enabled = ( this.checkBoxWhereClause.Checked);
			this.textBoxPKColumnId.Enabled = ( this.checkBoxWhereClause.Checked);
		}
		#endregion
	}
}
