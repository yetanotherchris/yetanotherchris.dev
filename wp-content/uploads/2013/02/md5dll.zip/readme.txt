MD5 ASP Component
Version 1.00

� W.Tracz  2000-2001
Bugs + info: wtracz@yahoo.co.uk
Website: www.nervetoxin.co.uk/www.sloppycode.net

Contents
========

1. Introduction
2. Installation
3. Documentation
4. Example usage

1. Introduction
---------------
The message digest algorithm was developed by Professor Ronald L. Rivest of MIT. 'The MD5 algorithm is intended for digital signature applications, where a large file must be "compressed" in a secure manner before being encrypted with a private (secret) key under a public-key cryptosystem such as RSA.' MD5 is a hash, i.e it is not reversible without a lot of effort (probably about a year and a half on a 1ghz athlon).

2. Installation
---------------
To install this ASP Component for PWS or IIS 4/5, first copy it to your favourite directory, then enter the command prompt by using Start>Run>Command.com (or cmd in Win2k). Use the 'CD' (change directory) command to navigate the directory where you stored the DLL file, and then type

regsvr32 md5dll.dll

This should register the ASP Component as ready to use by your computer.

3. Documentation
---------------
See the manual.html file that comes with this package.

4. Example Usage
---------------
Example usage can be found in the example.asp file that comes with this package.