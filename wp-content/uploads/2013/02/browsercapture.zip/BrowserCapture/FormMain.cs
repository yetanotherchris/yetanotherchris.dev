﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.Threading;

namespace BrowserCapture
{
	public partial class FormMain : Form
	{
		[DllImport("user32")]
		public static extern int GetWindowText(int hwnd, StringBuilder lpString, uint bufferSize);

		[DllImport("user32.dll")]
		public static extern int EnumWindows(EnumWindowsCallback callback, int lParam);

		[DllImport("User32.dll")]
		public static extern int RealGetWindowClass(int hWnd, StringBuilder pszType, uint bufferSize);

		[DllImport("user32.dll")]
		public static extern bool PostMessage(IntPtr hwnd, uint msg, int wParam, int lParam);

		public delegate bool EnumWindowsCallback(int hwnd, int lParam);

		private const int WMCLOSE = 0x10;


		public FormMain()
		{
			InitializeComponent();
		}

		private void buttonStart_Click(object sender, EventArgs e)
		{
			if ( _checkBoxIE7.Checked )
			{
				Process processIE = Process.Start(_textBoxIePath.Text, _textBoxWebsite.Text);
			}

			if ( _checkBoxFF2.Checked )
			{
				Process processFirefox = Process.Start(_textBoxFirefoxPath.Text, "-new-window \"" +_textBoxWebsite.Text+ "\"");
			}

			if ( _checkBoxSafari.Checked )
			{
				Process processSafari = Process.Start(_textBoxSafariPath.Text, "\"" +_textBoxWebsite.Text+ "\"");
			}

			if (_checkBoxOpera.Checked)
			{
				Process processOpera = Process.Start(_textBoxPathOpera.Text, "-nosession -newwindow \"" + _textBoxWebsite.Text + "\"");
			}

			Thread.Sleep(int.Parse(_maskedTextBoxWait1.Text) *1000);

			EnumWindowsCallback cb = new EnumWindowsCallback(GetWindows);
			EnumWindows(cb, 0);
		}

		private bool GetWindows(int hWnd, int lParam)
		{
			StringBuilder windowName = new StringBuilder(255);
			StringBuilder className = new StringBuilder(255);
			string savePath = _textBoxPath.Text + "\\{0}";
			int width = int.Parse(_maskedTextBoxWidth.Text);
			int height = int.Parse(_maskedTextBoxHeight.Text);

			GetWindowText(hWnd, windowName, 255);
			RealGetWindowClass(hWnd, className, 255);

			ScreenCapture sc = new ScreenCapture();
			IntPtr hwndPtr = new IntPtr(hWnd);

			if (windowName.ToString().IndexOf("Internet Explorer") != -1 && className.ToString().IndexOf("IEFrame") != -1 && _checkBoxIE7.Checked )
			{
				sc.SetWindowSize(hwndPtr, 0, 0, width, height);
				Thread.Sleep(1000);
				sc.CaptureWindowToFile(hwndPtr, string.Format(savePath, "ie7.png"), ImageFormat.Png);

				// NB WMCLOSE instead of Process.Kill, as Process.Kill doesn't save any config data
				if ( _checkBoxClose.Checked )
					PostMessage(hwndPtr, WMCLOSE, 0, 0);
			}
			else if (className.ToString().StartsWith("{1C0") && _checkBoxSafari.Checked)
			{
				sc.SetWindowSize(hwndPtr, 0, 0, width, height);
				Thread.Sleep(1000);
				sc.CaptureWindowToFile(hwndPtr, string.Format(savePath, "safari.png"), ImageFormat.Png);

				if (_checkBoxClose.Checked)
					PostMessage(hwndPtr, WMCLOSE, 0, 0);
			}
			else if (windowName.ToString().IndexOf("Firefox") != -1 && _checkBoxFF2.Checked)
			{
				sc.SetWindowSize(hwndPtr, 0, 0, width, height);
				Thread.Sleep(1000);
				sc.CaptureWindowToFile(hwndPtr, string.Format(savePath, "ff2.png"), ImageFormat.Png);

				if (_checkBoxClose.Checked)
					PostMessage(hwndPtr, WMCLOSE, 0, 0);
			}
			else if (windowName.ToString().IndexOf("Opera") != -1 && className.ToString().StartsWith("OpWindow") && _checkBoxOpera.Checked)
			{
				sc.SetWindowSize(hwndPtr, 0, 0, width, height);
				Thread.Sleep(1000);
				sc.CaptureWindowToFile(hwndPtr, string.Format(savePath, "opera.png"), ImageFormat.Png);

				if (_checkBoxClose.Checked)
					PostMessage(hwndPtr, WMCLOSE, 0, 0);
			}

			return true;
		}

		private void buttonExplore_Click(object sender, EventArgs e)
		{
			if (_folderBrowserDialog1.ShowDialog() == DialogResult.OK)
			{
				_textBoxPath.Text = _folderBrowserDialog1.SelectedPath;
			}
		}
	}
}
