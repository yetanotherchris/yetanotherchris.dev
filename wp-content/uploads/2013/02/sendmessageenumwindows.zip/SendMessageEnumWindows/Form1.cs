using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Text;
using System.Diagnostics;


namespace SendMessageEnumWindows
{
	public class Form1 : System.Windows.Forms.Form
	{
		#region Components
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.TextBox textBoxWindows;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.TextBox textBoxIrc;
		private System.Windows.Forms.Button buttonWindows;
		private System.Windows.Forms.Button buttonTrillian;
		private System.Windows.Forms.Button buttonMirc;
		private System.Windows.Forms.GroupBox groupBox3;
		private System.Windows.Forms.GroupBox groupBox4;
		private System.Windows.Forms.ComboBox comboBoxTrillian;
		private System.Windows.Forms.ComboBox comboBoxMirc;
		private System.Windows.Forms.Button buttonRefresh;
		private System.ComponentModel.Container components = null;
		#endregion

		#region win32 imports
		public delegate bool EnumWindowsCallback(int hwnd, int lParam);

		[DllImport("user32")] public static extern int GetWindowText(int hwnd,StringBuilder lpString, uint bufferSize);
		
		[DllImport("user32.dll")] public static extern int EnumWindows (EnumWindowsCallback callback, int lParam);
		[DllImport("User32.dll")] public static extern int EnumChildWindows (int hWndParent,EnumWindowsCallback callback, int lParam);

		[DllImport("User32.dll")] public static extern int RealGetWindowClass(int hWnd,StringBuilder pszType,uint bufferSize);
		[DllImport("User32.dll")] public static extern int SendMessage( int hwnd, int uMsg, int wParam, [MarshalAs(System.Runtime.InteropServices.UnmanagedType.LPStr)] string lParam);

		
		[DllImport("user32.dll") ]	static extern int FindWindow (string lpClassName,string WindowName);
		[DllImport("user32.dll") ]	static extern int FindWindowEx (int hWnd,int hWnd2,string lpsz,string lpsz2);
		[DllImport("user32.dll") ]	static extern int SetWindowText(int hWnd,string lpsz);
		#endregion

		#region Constants + fields
		public static int GW_HWNDNEXT = 2;
		public static int GW_CHILD = 5;
		public static int GW_OWNER = 4;
		public static int GWL_HWNDPARENT = -8;
		public static int WM_SETTEXT =  12;
		public const int HWND_MESSAGE = -3;
		public const int WM_CHAR = 258;
		private string _windowText = "";
		#endregion

		#region Constructor, dipose, main
		public Form1()
		{
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}
		#endregion

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.textBoxWindows = new System.Windows.Forms.TextBox();
			this.buttonWindows = new System.Windows.Forms.Button();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.buttonRefresh = new System.Windows.Forms.Button();
			this.groupBox4 = new System.Windows.Forms.GroupBox();
			this.comboBoxMirc = new System.Windows.Forms.ComboBox();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.comboBoxTrillian = new System.Windows.Forms.ComboBox();
			this.buttonMirc = new System.Windows.Forms.Button();
			this.buttonTrillian = new System.Windows.Forms.Button();
			this.textBoxIrc = new System.Windows.Forms.TextBox();
			this.groupBox1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.groupBox4.SuspendLayout();
			this.groupBox3.SuspendLayout();
			this.SuspendLayout();
			// 
			// groupBox1
			// 
			this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.groupBox1.Controls.Add(this.textBoxWindows);
			this.groupBox1.Controls.Add(this.buttonWindows);
			this.groupBox1.Location = new System.Drawing.Point(8, 8);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(520, 200);
			this.groupBox1.TabIndex = 4;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Enumerate windows";
			// 
			// textBoxWindows
			// 
			this.textBoxWindows.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxWindows.Location = new System.Drawing.Point(8, 16);
			this.textBoxWindows.Multiline = true;
			this.textBoxWindows.Name = "textBoxWindows";
			this.textBoxWindows.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.textBoxWindows.Size = new System.Drawing.Size(500, 144);
			this.textBoxWindows.TabIndex = 3;
			this.textBoxWindows.Text = "";
			// 
			// buttonWindows
			// 
			this.buttonWindows.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.buttonWindows.Location = new System.Drawing.Point(8, 168);
			this.buttonWindows.Name = "buttonWindows";
			this.buttonWindows.TabIndex = 2;
			this.buttonWindows.Text = "Enumerate";
			this.buttonWindows.Click += new System.EventHandler(this.buttonWindows_Click);
			// 
			// groupBox2
			// 
			this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.groupBox2.Controls.Add(this.buttonRefresh);
			this.groupBox2.Controls.Add(this.groupBox4);
			this.groupBox2.Controls.Add(this.groupBox3);
			this.groupBox2.Controls.Add(this.buttonMirc);
			this.groupBox2.Controls.Add(this.buttonTrillian);
			this.groupBox2.Controls.Add(this.textBoxIrc);
			this.groupBox2.Location = new System.Drawing.Point(8, 216);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(520, 184);
			this.groupBox2.TabIndex = 5;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "mIRC / Trillian";
			// 
			// buttonRefresh
			// 
			this.buttonRefresh.Location = new System.Drawing.Point(224, 80);
			this.buttonRefresh.Name = "buttonRefresh";
			this.buttonRefresh.TabIndex = 9;
			this.buttonRefresh.Text = "Refresh";
			this.buttonRefresh.Click += new System.EventHandler(this.buttonRefresh_Click);
			// 
			// groupBox4
			// 
			this.groupBox4.Controls.Add(this.comboBoxMirc);
			this.groupBox4.Location = new System.Drawing.Point(264, 24);
			this.groupBox4.Name = "groupBox4";
			this.groupBox4.Size = new System.Drawing.Size(240, 48);
			this.groupBox4.TabIndex = 8;
			this.groupBox4.TabStop = false;
			this.groupBox4.Text = "mIRC window";
			// 
			// comboBoxMirc
			// 
			this.comboBoxMirc.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxMirc.Location = new System.Drawing.Point(7, 18);
			this.comboBoxMirc.Name = "comboBoxMirc";
			this.comboBoxMirc.Size = new System.Drawing.Size(224, 21);
			this.comboBoxMirc.TabIndex = 1;
			// 
			// groupBox3
			// 
			this.groupBox3.Controls.Add(this.comboBoxTrillian);
			this.groupBox3.Location = new System.Drawing.Point(8, 24);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(240, 48);
			this.groupBox3.TabIndex = 7;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "Trillian window";
			// 
			// comboBoxTrillian
			// 
			this.comboBoxTrillian.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxTrillian.Location = new System.Drawing.Point(8, 20);
			this.comboBoxTrillian.Name = "comboBoxTrillian";
			this.comboBoxTrillian.Size = new System.Drawing.Size(224, 21);
			this.comboBoxTrillian.TabIndex = 0;
			// 
			// buttonMirc
			// 
			this.buttonMirc.Location = new System.Drawing.Point(120, 152);
			this.buttonMirc.Name = "buttonMirc";
			this.buttonMirc.Size = new System.Drawing.Size(96, 23);
			this.buttonMirc.TabIndex = 6;
			this.buttonMirc.Text = "Send to mIRC";
			this.buttonMirc.Click += new System.EventHandler(this.buttonMirc_Click);
			// 
			// buttonTrillian
			// 
			this.buttonTrillian.Location = new System.Drawing.Point(8, 152);
			this.buttonTrillian.Name = "buttonTrillian";
			this.buttonTrillian.Size = new System.Drawing.Size(104, 23);
			this.buttonTrillian.TabIndex = 5;
			this.buttonTrillian.Text = "Send to Trillian";
			this.buttonTrillian.Click += new System.EventHandler(this.buttonTrillian_Click);
			// 
			// textBoxIrc
			// 
			this.textBoxIrc.Location = new System.Drawing.Point(8, 120);
			this.textBoxIrc.Name = "textBoxIrc";
			this.textBoxIrc.Size = new System.Drawing.Size(496, 20);
			this.textBoxIrc.TabIndex = 4;
			this.textBoxIrc.Text = "/msg #channel your text";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(536, 406);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.groupBox1);
			this.Name = "Form1";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Send Message / EnumWindows example";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.groupBox1.ResumeLayout(false);
			this.groupBox2.ResumeLayout(false);
			this.groupBox4.ResumeLayout(false);
			this.groupBox3.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		#region Callback functions for listing windows
		private bool displayWindowInfo(int hWnd, int lParam)
		{
			StringBuilder windowName = new StringBuilder(255);
			StringBuilder className  = new StringBuilder(255);

			GetWindowText(hWnd, windowName, 255);
			RealGetWindowClass(hWnd,className,255);

			string name = windowName.ToString();
			string classn = className.ToString();

			this._windowText += "Window " +hWnd+ " \"" +name+ "\" ";
			this._windowText += classn;
			this._windowText += "\r\n";

			return true;
		}

		private bool displayTrillianWindows(int hWnd, int lParam)
		{
			StringBuilder windowName = new StringBuilder(255);
			StringBuilder className  = new StringBuilder(255);

			GetWindowText(hWnd, windowName, 255);
			RealGetWindowClass(hWnd,className,255);
			Console.WriteLine(windowName.ToString());
			if ( windowName.ToString().IndexOf("- Console") != -1 && className.ToString().IndexOf("icoIRC") != -1 )
			{
				comboBoxTrillian.Items.Add(new ComboBoxItem(windowName.ToString(),hWnd));
			}

			return true;
		}

		private bool displayMircWindows(int hWnd, int lParam)
		{
			StringBuilder windowName = new StringBuilder(255);
			StringBuilder className  = new StringBuilder(255);

			GetWindowText(hWnd, windowName, 255);
			RealGetWindowClass(hWnd,className,255);
			
			if ( className.ToString().IndexOf("mIRC_Status") != -1 )
			{
				comboBoxMirc.Items.Add(new ComboBoxItem(windowName.ToString(),hWnd));
			}

			return true;
		}
		#endregion

		#region Sendmessage clicks
		private void buttonTrillian_Click(object sender, System.EventArgs e)
		{
			// Trillian
			if ( comboBoxTrillian.SelectedItem != null )
			{
				int hWndTrillian,hWndTrillianMessage,hWndTrillianMessage2;

				ComboBoxItem comboBoxItem =  (ComboBoxItem) comboBoxTrillian.SelectedItem;
				
				hWndTrillian= (int) comboBoxItem.Data;
				MessageBox.Show(hWndTrillian + "");

				if ( hWndTrillian != 0 )
				{
					// Find message window
					hWndTrillianMessage = FindWindowEx(hWndTrillian,0,"trillian display",null);
					// Find next one, the input box
					hWndTrillianMessage2 = FindWindowEx(hWndTrillian,hWndTrillianMessage,"trillian display",null);
					
					// Split message up into characters
					for (int i=0;i <= textBoxIrc.Text.Length -1;i++)
					{
						SendMessage(hWndTrillianMessage2,WM_CHAR,(char) textBoxIrc.Text[i],null);
					}
					// Send carriage return
					SendMessage(hWndTrillianMessage2,WM_CHAR,13,null);
				}
			}
		}

		private void buttonMirc_Click(object sender, System.EventArgs e)
		{
			// Mirc
			if ( comboBoxMirc.SelectedItem != null )
			{
				int hWndMirc;

				ComboBoxItem comboBoxItem =  (ComboBoxItem) comboBoxMirc.SelectedItem;
				
				hWndMirc = (int) comboBoxItem.Data;
				MessageBox.Show(hWndMirc + "");

				if ( hWndMirc != 0 )
				{
					int hWndMircEdit;

					// Find Edit inside the channel window
					hWndMircEdit = FindWindowEx(hWndMirc,0,"Edit",null);

					SendMessage(hWndMircEdit,WM_SETTEXT,0,textBoxIrc.Text);
					SendMessage(hWndMircEdit,WM_CHAR,13,null);
				}
			}
		}
		#endregion
		
		#region Form load, refresh/enum windows button clicks
		private void Form1_Load(object sender, System.EventArgs e)
		{
			getTrillian();
			getMirc();
		}

		private void buttonWindows_Click(object sender, System.EventArgs e)
		{
			this.textBoxWindows.Text = "";
			this._windowText = "";

			EnumWindowsCallback EnumWCB = new EnumWindowsCallback(displayWindowInfo);
			EnumWindows(EnumWCB ,0);

			this.textBoxWindows.Text = this._windowText;
		}

		private void buttonRefresh_Click(object sender, System.EventArgs e)
		{
			getTrillian();
			getMirc();
		}
		#endregion

		#region Get all trillian, mirc windows
		private void getTrillian()
		{
			bool trillianRunning = false;
			comboBoxTrillian.Items.Clear();

			// Get all processes
			Process[] processes = Process.GetProcesses();
			for (int i=0;i <= processes.Length -1;i++)
			{
				if (processes[i].ProcessName.IndexOf("trillian") != -1)
				{
					trillianRunning = true;
				}
			}

			if ( trillianRunning )
			{
				// Get all trillian IRC windows

				EnumWindowsCallback EnumWCB = new EnumWindowsCallback(displayTrillianWindows);
				EnumWindows(EnumWCB ,0);

				if ( comboBoxTrillian.Items.Count > 0 )
				{
					buttonTrillian.Enabled = true;
					comboBoxTrillian.SelectedIndex = 0;
				}
				else
				{
					// No status window
					buttonTrillian.Enabled = false;
					comboBoxTrillian.Text = "No Trillian IRC status windows found";
				}
				
			}
			else
			{
				// None found
				buttonTrillian.Enabled = false;
				comboBoxTrillian.Text = "Trillian not running";
			}
		}

		private void getMirc()
		{
			bool mircRunning = false;
			comboBoxMirc.Items.Clear();

			// Get all processes
			Process[] processes = Process.GetProcesses();
			for (int i=0;i <= processes.Length -1;i++)
			{
				if (processes[i].ProcessName.IndexOf("mirc") != -1)
				{
					mircRunning = true;
				}
			}

			if ( mircRunning )
			{
				int hWndMirc,hWndMircMdi;

				// Find MDI client parent
				hWndMirc = FindWindowEx(0,0,"mirc",null);

				// Find MDI client parent
				hWndMircMdi = FindWindowEx(hWndMirc,0,"MDIClient",null);
					
				// Get all mIRC channel windows
				EnumWindowsCallback EnumWCB = new EnumWindowsCallback(displayMircWindows);
				EnumChildWindows(hWndMircMdi,EnumWCB ,0);

				if ( comboBoxMirc.Items.Count > 0 )
				{
					buttonMirc.Enabled = true;
					comboBoxMirc.SelectedIndex = 0;
				}
				else
				{
					// No status window
					buttonMirc.Enabled = false;
					comboBoxMirc.Text = "No mIRC status windows found";
				}
				
			}
			else
			{
				// None found
				buttonMirc.Enabled = false;
				comboBoxMirc.Text = "mIRC not running";
			}
		}
		#endregion

		#region ComboBoxItem class
		/// <summary>
		/// Used to keep the hwnd in the combobox item
		/// </summary>
		internal class ComboBoxItem
		{
			private string text;
			private object data;

			public ComboBoxItem(string textStr)
			{
				text = textStr;
				data = null;
			}

			public ComboBoxItem(string textStr, object dataObj)
			{
				text = textStr;
				data = dataObj;
			}

			public string Text
			{
				get
				{
					return text;
				}
				set
				{
					text = value;
				}
			}
			public object Data
			{
				get
				{
					return data;
				}
				set
				{
					data = value;
				}
			}

			public override string ToString()
			{
				return text;
			}		
		}
		#endregion
	}
}
