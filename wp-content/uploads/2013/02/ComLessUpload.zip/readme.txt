ComLessUpload ASP Class
Version 1.00

� C.Small  2000-2001
Bugs + info: sloppycode@sloppycode.net
Website: www.sloppycode.net

Contents
========

1. Introduction
2. Installation
3. Documentation
4. Example usage

1. Introduction
---------------
Dataproducer, available for php,java servlets and asp is used to seperate the presentation layer from the data layer in web applications. With it you can specify single and multiple row tags inside a html template, which are then replaced with data that you specify. Please note this is the first version of the class and features little error handling. More features and error handling will appear in the next version.

2. Installation
---------------
No installation details needed - just include the file using

<!-- #include file="<path>clsComLessUpload.asp" -->

or

<!-- #include virtual="<path>clsComLessUpload.asp" -->

3. Documentation
---------------
See the manual.html file that comes with this package.

4. Example Usage
---------------
Example usage can be found in the example.asp file that comes with this package.