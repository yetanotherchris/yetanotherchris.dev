using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Threading;
using Sloppycode.net;

namespace RssReaderApp
{
	/// <summary>
	/// A quick application to test the RssReader class's functionality.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		#region Form Components
		private System.Windows.Forms.RichTextBox richTextBoxTemplate;
		private System.Windows.Forms.RichTextBox richTextBoxItemPrefix;
		private System.Windows.Forms.Button buttonOK;
		private System.Windows.Forms.ComboBox comboBox1;
		private System.Windows.Forms.CheckBox checkBoxRdf;
		private System.Windows.Forms.StatusBar statusBar1;
		private System.ComponentModel.Container components = null;
		#endregion

		#region Members
		private int itemsFound = 0;
		#endregion

		#region Constructor,dispose,main
		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		/// <summary>
		/// The main entry point for the applications.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}
		#endregion

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.buttonOK = new System.Windows.Forms.Button();
			this.richTextBoxTemplate = new System.Windows.Forms.RichTextBox();
			this.richTextBoxItemPrefix = new System.Windows.Forms.RichTextBox();
			this.comboBox1 = new System.Windows.Forms.ComboBox();
			this.checkBoxRdf = new System.Windows.Forms.CheckBox();
			this.statusBar1 = new System.Windows.Forms.StatusBar();
			this.SuspendLayout();
			// 
			// buttonOK
			// 
			this.buttonOK.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonOK.Location = new System.Drawing.Point(344, 4);
			this.buttonOK.Name = "buttonOK";
			this.buttonOK.TabIndex = 0;
			this.buttonOK.Text = "Get";
			this.buttonOK.Click += new System.EventHandler(this.buttonGet_Click);
			// 
			// richTextBoxTemplate
			// 
			this.richTextBoxTemplate.Location = new System.Drawing.Point(8, 80);
			this.richTextBoxTemplate.Name = "richTextBoxTemplate";
			this.richTextBoxTemplate.Size = new System.Drawing.Size(344, 104);
			this.richTextBoxTemplate.TabIndex = 1;
			this.richTextBoxTemplate.Text = @"<!DOCTYPE HTML PUBLIC ""-//W3C//DTD HTML 4.01 Transitional//EN"">
<html>
<head>
<title>RSS feed</title>
<meta http-equiv=""Content-Type"" content=""text/html; charset=iso-8859-1"">
<style>
.channelTitle {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 10pt;
	font-weight: bold;
	color: #FFFFFF;
}
.channelDescription {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 7pt;
	color: #003366;
}
.itemTitle {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 9pt;
	text-decoration:none;
	background-color: #F6F6F6;
	color: #000000;
	font-weight: bold;
}
.itemTitle:hover { color:#003366; }
.itemDescription {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 9px;
}
</style>
</head>

<body>
<table width=""500"" border=""0"" align=""center"" cellpadding=""1"" cellspacing=""0"" bgcolor=""#003399"">
	<tr><td>
		<table width=""500"" border=""0"" cellpadding=""5"" cellspacing=""0"" bgcolor=""#FFFFFF"">
        	<tr><td bgcolor=""#4F4F4F""><a href=""%Link%"" target=""_blank"" class=""channelTitle"">%Title%</a></td>
        	</tr>
        	<tr><td class=""channelDescription"">%Description%</td>
        	</tr>
        	</table>
	</td>
	</tr>
</table>
<br>
<br>
<table width=""500"" border=""0"" align=""center"" cellpadding=""1"" cellspacing=""0"" bgcolor=""#A3A3A3"">
<tr>
	<td>
		<table width=""500"" border=""0"" cellpadding=""5"" cellspacing=""0"" bgcolor=""#FFFFFF"">
		%Items%
		</table>
	</td>
</tr>
</table>
</body>
</html>";
			// 
			// richTextBoxItemPrefix
			// 
			this.richTextBoxItemPrefix.Location = new System.Drawing.Point(8, 192);
			this.richTextBoxItemPrefix.Name = "richTextBoxItemPrefix";
			this.richTextBoxItemPrefix.Size = new System.Drawing.Size(336, 96);
			this.richTextBoxItemPrefix.TabIndex = 2;
			this.richTextBoxItemPrefix.Text = "\t\t<tr>\n\t\t\t<td class=\"itemTitle\"><a href=\"%Link%\" target=\"_blank\" class=\"itemTitle" +
				"\">%Title%</a></td>\n\t\t</tr>\n\t\t<tr>\n\t\t\t<td class=\"itemDescription\">%Description%</" +
				"td>\n\t\t</tr>";
			// 
			// comboBox1
			// 
			this.comboBox1.Items.AddRange(new object[] {
														   "http://www.securityfocus.com/rss/news.xml",
														   "http://rss.news.yahoo.com/rss/tech",
														   "http://rss.news.yahoo.com/rss/oddlyenough",
														   "http://rssnewsapps.ziffdavis.com/msw.xml",
														   "http://www.theregister.co.uk/tonys/slashdot.rdf",
														   "http://slashdot.org/slashdot.rdf",
														   "http://partners.userland.com/nytRss/technology.xml"});
			this.comboBox1.Location = new System.Drawing.Point(8, 5);
			this.comboBox1.Name = "comboBox1";
			this.comboBox1.Size = new System.Drawing.Size(280, 21);
			this.comboBox1.TabIndex = 3;
			this.comboBox1.Text = "comboBox1";
			this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
			// 
			// checkBoxRdf
			// 
			this.checkBoxRdf.Location = new System.Drawing.Point(296, 8);
			this.checkBoxRdf.Name = "checkBoxRdf";
			this.checkBoxRdf.Size = new System.Drawing.Size(45, 16);
			this.checkBoxRdf.TabIndex = 4;
			this.checkBoxRdf.Text = "RDF";
			// 
			// statusBar1
			// 
			this.statusBar1.Location = new System.Drawing.Point(0, 38);
			this.statusBar1.Name = "statusBar1";
			this.statusBar1.Size = new System.Drawing.Size(424, 16);
			this.statusBar1.TabIndex = 5;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(424, 54);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.statusBar1,
																		  this.checkBoxRdf,
																		  this.comboBox1,
																		  this.richTextBoxItemPrefix,
																		  this.richTextBoxTemplate,
																		  this.buttonOK});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "Form1";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "RSS Test app";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		#region Form events
		private void Form1_Load(object sender, System.EventArgs e)
		{
			this.comboBox1.SelectedIndex = 0;
		}

		private void comboBox1_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if ( this.comboBox1.SelectedIndex == 4 || this.comboBox1.SelectedIndex == 5 )
			{
				this.checkBoxRdf.Checked = true;
			}
			else
			{
				this.checkBoxRdf.Checked = false;
			}
		}

		private void buttonGet_Click(object sender, System.EventArgs e)
		{
			this.itemsFound = 0;
			if ( this.comboBox1.Text != "" )
			{
				this.Cursor = Cursors.WaitCursor;
				Thread thread = new Thread(new ThreadStart(readRss));
				thread.Start();
				this.Cursor = Cursors.Default;
			}
		}
		#endregion

		#region The method that does the work
		private void readRss()
		{
			RssReader rssReader = new RssReader();
			rssReader.RdfMode = this.checkBoxRdf.Checked;
			rssReader.FeedLoaded += new EventHandler(rssReader_FeedLoaded);
			rssReader.ItemAdded  += new EventHandler(rssReader_ItemAdded);
			rssReader.Error      += new RssReaderErrorEventHandler(rssReader_Error);

			RssFeed feed = rssReader.Retrieve(this.comboBox1.Text);
			
			if ( feed.ErrorMessage == null || feed.ErrorMessage == "" )
			{
				string html = RssReader.CreateHtml(feed,this.richTextBoxTemplate.Text,this.richTextBoxItemPrefix.Text,"",5);

				StreamWriter streamWriter = File.CreateText("c:\\rss.html");
				streamWriter.Write(html);
				streamWriter.Close();

				System.Diagnostics.Process.Start("c:\\rss.html");
			}
		}
		#endregion
		
		#region Feed event handlers
		private void rssReader_FeedLoaded(object sender, System.EventArgs e)
		{
			this.statusBar1.Text = "RSS feed loaded succesfully.";
		}

		private void rssReader_ItemAdded(object sender, System.EventArgs e)
		{
			this.itemsFound++;
			this.statusBar1.Text = this.itemsFound +" items found.";
		}

		private void rssReader_Error(object sender, RssReaderErrorEventArgs e)
		{
			this.statusBar1.Text = "Error occured: "+e.Message;
		}
		#endregion
	}
}
