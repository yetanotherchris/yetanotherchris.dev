using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
using System.Text;

public partial class PostcodeToMap : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

	protected void ButtonGrab_Click(object sender, EventArgs e)
	{
		//
		// Get a list of postcodes from the page
		//
		PostcodeParser parser = new PostcodeParser();
		List<string> postcodes = parser.GetPostcodes( this.TextBoxUrl.Text, (PostcodeRegexType) this.DropDownListType.SelectedIndex, this.TextBoxCustom.Text );

		// Look the postcodes up
		GoogleMapsGeoLookup lookup = new GoogleMapsGeoLookup();
		List<GeoResponse> list = lookup.LookupPostcodes(postcodes,this.GetCountry());

		//
		// Check for any errors and display them.
		// 
		if ( !string.IsNullOrEmpty( parser.Errors ) )
		{
			this.PanelMap.Visible = false;
			this.LabelErrors.Visible = true;
			this.LabelErrors.Text = parser.Errors.Replace("\n","<br />") + "<br />";
		}
		else if ( !string.IsNullOrEmpty( lookup.Errors ) )
		{
			this.PanelMap.Visible = false;
			this.LabelErrors.Visible = true;
			this.LabelErrors.Text = lookup.Errors.Replace( "\n", "<br />" ) + "<br />";
		}
		else
		{
			this.PanelMap.Visible = true;

			// Build the javascript
			StringBuilder builder = new StringBuilder();
			GeoResponse lastResponse = new GeoResponse();

			builder.AppendLine( "<script type='text/javascript'>" );
			builder.AppendLine( "function init()" );
			builder.AppendLine( "{" );
			builder.AppendLine( "var map = new GMap2(document.getElementById('map_canvas'));" );
			builder.AppendLine( "map.enableScrollWheelZoom();" );
			builder.AppendLine( "map.setCenter( new GLatLng( {LAT},{LONG}), 13 );" );
			builder.AppendLine( "map.addControl(new GSmallMapControl());" );
			builder.AppendLine( "map.addControl(new GMapTypeControl());" );
			builder.AppendLine( "" );

			foreach ( GeoResponse response in list )
			{
				if ( response.Status == 200 )
				{
					//
					// Make a marker for each postcode
					//
					string f = "var point = new GLatLng({0},{1});\n";
					f += "var options = {{ title: '{2}' }};\n";
					f += "map.addOverlay(new GMarker(point,options));\n\n";

					f = string.Format( f, response.Longitude, response.Latitude, response.Postcode );
					builder.AppendLine( f );

					lastResponse = response;
				}
			}

			// Make the map center at the last position, or it doesn't initialise properly
			builder.Replace( "{LAT}", lastResponse.Longitude );
			builder.Replace( "{LONG}", lastResponse.Latitude );

			builder.AppendLine( "}" );
			builder.AppendLine( "</script>" );

			this.LiteralScript.Text = builder.ToString();
		}
	}

	private string GetCountry()
	{
		switch ( this.DropDownListType.SelectedValue )
		{
			case "UK":
				return "UK";
			case "US":
				return "US";
			case "Custom":
				return this.TextBoxCountry.Text;
		}

		return "UK";
	}


	protected void DropDownListType_SelectedIndexChanged(object sender, EventArgs e)
	{
		if ( this.DropDownListType.SelectedValue == "Custom" )
		{
			this.PanelCustom.Visible = true;
		}
		else
		{
			this.PanelCustom.Visible = false;
		}
	}
}
