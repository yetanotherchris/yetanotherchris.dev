using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml;
using System.Collections.Generic;
using System.Text;

/// <summary>
/// Google maps Geo (KML) lookup.
/// </summary>
public class GoogleMapsGeoLookup
{
	/// <summary>
	/// Any errors in the operation are collected in the Errors property. To simplify
	/// things, no boolean (which could be passed in by reference) is returned from
	/// GetPostcodes.
	/// </summary>
	public string Errors
	{
		get { return _errors; }
		set { _errors = value; }
	}

	private string _errors;

	// The geocode lookup url
	private const string _googleUrl = "http://maps.google.com/maps/geo?q={0},{1}&output=xml&key=YOUR-GOOGLE-MAPS-KEY";

	/// <summary>
	/// Looks up all provided postcodes and returns a list of Latitude/Longitude coordinates
	/// in the form of a list of <see cref="GeoResponse">GeoResponses</see>.
	/// </summary>
	/// <param name="postcodes"></param>
	/// <param name="country"></param>
	/// <returns></returns>
	public List<GeoResponse> LookupPostcodes(List<string> postcodes,string country)
	{
		if ( postcodes == null )
			throw new NullReferenceException( "postcodes is null" );

		List<GeoResponse> responses = new List<GeoResponse>();

		//
		// Limit to 10 searches, or we'll appear to have hung (this is for the web 
		// example only - you can change this to a foreach).
		//
		int count = postcodes.Count ;
		if ( count > 10 )
			count = 10;

		for ( int i = 0 ; i < count ; i++ )
		{
			responses.Add( this.LookupPostcode( postcodes[i], country ) );
		}

		return responses;
	}

	/// <summary>
	/// Gets the XML file back from google for the postcode with lat/long.
	/// </summary>
	/// <param name="postcode"></param>
	/// <param name="country"></param>
	/// <returns></returns>
	private GeoResponse LookupPostcode(string postcode,string country)
	{
		
		GeoResponse response = new GeoResponse();
		response.Postcode = postcode;

		try
		{
			if ( !string.IsNullOrEmpty( postcode ) )
			{
				// Load from the URL
				XmlDocument document = new XmlDocument();
				string request = string.Format( _googleUrl, postcode, country );

				// Namespace for the KML node
				XmlNamespaceManager manager = new XmlNamespaceManager( document.NameTable );
				manager.AddNamespace( "g", "http://earth.google.com/kml/2.0" );

				document.Load( request );

				// Grab the status, check for 200
				XmlNode node = document.SelectSingleNode( "//g:code", manager );
				if ( node != null && node.InnerText == "200" )
				{
					response.Status = 200;
					node = document.SelectSingleNode( "//g:coordinates", manager );

					// There might be problems here with multiple placemarks or points which will
					// need their own separate error catching
					if ( node != null )
					{
						string[] latlong = this.GetLatLong( node.InnerText );
						response.Latitude = latlong[0];
						response.Longitude = latlong[1];
					}
					else
					{
						response.Status = 600;
					}
				}
				else
				{
					response.Status = 600;
				}
			}
			else
			{
				response.Status = 600;
			}

		}
		catch ( XmlException )
		{
			this.Errors += "A XML related error occured getting the KML for the Geocode lookup. Check you have entered a country for custom searches.";
		}
		catch ( Exception )
		{
			this.Errors += "A general occured getting the KML for the Geocode lookup.";
		}
		return response;
	}

	/// <summary>
	/// Retrieves the longitude and latitude from point node.
	/// </summary>
	/// <param name="point"></param>
	/// <returns></returns>
	private string[] GetLatLong(string point)
	{
		string[] result = new string[2];

		if ( !string.IsNullOrEmpty( point ) || point.IndexOf( "," ) > -1 )
		{
			string[] items = point.Split( ',' );
			if ( items.Length > 0 )
			{
				result[0] = items[0];
				result[1] = items[1];
			}
		}

		return result;
	}
}
