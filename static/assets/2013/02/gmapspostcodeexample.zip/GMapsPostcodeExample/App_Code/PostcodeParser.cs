using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
using System.Net;
using System.Text.RegularExpressions;
using System.Text;
using System.IO;
using System.Security;
using System.Collections;

/// <summary>
/// Summary description for PostcodeParser
/// </summary>
public class PostcodeParser
{
	/// <summary>
	/// Any errors in the operation are collected in the Errors property. To simplify
	/// things, no boolean (which could be passed in by reference) is returned from
	/// GetPostcodes.
	/// </summary>
	public string Errors
	{
		get { return _errors; }
		set { _errors = value; }
	}

	private string _errors;

	// The two built in ones. The US postcode regex looks for space before it which is far from fullproof.
	private static Regex UKPostcodeRegex = new Regex( @"([A-PR-UWYZ0-9][A-HK-Y0-9][AEHMNPRTVXY0-9]?[ABEHMNPRVWXY0-9]? {1,2}[0-9][ABD-HJLN-UW-Z]{2}|GIR 0AA)", RegexOptions.Multiline | RegexOptions.Compiled );
	private static Regex USPostcodeRegex = new Regex( @"(?:\s+)(\d{5})", RegexOptions.Multiline | RegexOptions.Compiled );

	/// <summary>
	/// Gets a list of postcodes from the page with the given regextype or custom regular expression.
	/// </summary>
	/// <param name="url"></param>
	/// <param name="regexType"></param>
	/// <param name="customRegex"></param>
	/// <returns></returns>
	public List<string> GetPostcodes(string url,PostcodeRegexType regexType,string customRegex)
	{
		List<string> list = new List<string>();

		if ( url == null )
		{
			this.Errors += "Please enter a valid url.";
			return list;
		}

		try
		{
			//
			// Create the request, tell the website we're IE6.
			//
			HttpWebRequest r = (HttpWebRequest) WebRequest.Create( url );
			r.UserAgent = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)";

			//
			// Example of using Cookies
			//
			//CookieContainer cookies = new CookieContainer();
			//cookies.Add( new Cookie( "LastBrowseCookie", "http%3A%2F%2Fwww.argos.co.uk%2Fwebapp%2Fwcs%2Fstores%2Fservlet%2FStoreCatalogDisplay%3FjspStoreDir%3Dargos%26params%3DAR276%26referredURL%3Dhttp%3A%2F%2Fwww.argos.co.uk%2Fstatic%2FHome.htm%26cmpid%3DAR276%26uid%3D7039573405%26langId%3D-1%26referrer%3DAR276%26mid%3D700034656%26storeId%3D10001", "/", ".argos.co.uk" ) );
			//r.CookieContainer = cookies;

			//
			// Get back the response, use the UK regex by default.
			//
			WebResponse response = r.GetResponse();
			StreamReader rd = new StreamReader( response.GetResponseStream() );
			string content = rd.ReadToEnd();

			Regex regex = UKPostcodeRegex;

			switch ( regexType )
			{
				case PostcodeRegexType.US:
					regex = USPostcodeRegex;
					break;
				case PostcodeRegexType.Custom:
					regex = new Regex( customRegex, RegexOptions.Multiline );
					break;
			}

			//
			// Add each postcode to the list to return.
			//
			foreach ( Match match in regex.Matches( content ) )
			{
				string s = match.Groups[1].Value;

				// Filter out the same postcode
				if ( !list.Contains(s) )
					list.Add( s );
			}
		}
		catch ( UriFormatException )
		{
			this.Errors += "The url was in an incorrect format.";
		}
		catch ( SecurityException )
		{
			this.Errors += "There was a security error when getting the URL.";
		}
		catch ( Exception )
		{
			this.Errors += "A general error occured.";
		}

		return list;
	}
}

/// <summary>
/// The type of regex to use for postcode finding.
/// </summary>
public enum PostcodeRegexType
{
	UK,
	US,
	Custom
}
