using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Small class to respresent a response from the Google maps Geo lookup service.
/// </summary>
public class GeoResponse
{
	/// <summary>
	/// A status code of 600 (fail) or 200 (success).
	/// </summary>
	public int Status
	{
		get { return _status; }
		set { _status = value; }
	}

	/// <summary>
	/// The latitude of the zip/postcode.
	/// </summary>
	public string Latitude
	{
		get { return _latitude; }
		set { _latitude = value; }
	}

	/// <summary>
	/// The longitude of the zip/postcode.
	/// </summary>
	public string Longitude
	{
		get { return _longitude; }
		set { _longitude = value; }
	}

	/// <summary>
	/// The postcode or zipcode.
	/// </summary>
	public string Postcode
	{
		get { return _postcode; }
		set { _postcode = value; }
	}

	private string _postcode;
	private string _longitude;
	private string _latitude;
	private int _status;
}
