ie = (navigator.appName.indexOf("Microsoft")!=-1);
ns = (navigator.appName.indexOf("Netscape") != -1);

ns4= (ns && navigator.appVersion.indexOf("5") == -1);
ns6= (ns && navigator.appVersion.indexOf("5") != -1);
ns6X = 0;
ns6Y = 0;

function changeColor(wcolour) {
	if (ie){
		document.all["pickcolour"].style.backgroundColor = '#' + wcolour;
		document.all["colorbox"].style.visibility = 'hidden';
	}
	if (ns4){
		document.layers["pickcolour"].bgColor = '#' + wcolour;
		document.layers["colorbox"].visibility = false;
	}
	if (ns6){
		document.getElementById("pickcolour").style.backgroundColor = '#' + wcolour;
		document.getElementById("colorbox").style.visibility = 'hidden';
	}
}

function showColor(posX,posY){
	if (ie){
		e = window.event;
		with (document.all["colorbox"]){
			style.left = e.clientX;
			style.top  = e.clientY;
			style.visibility = 'visible';
		}
	}
	if (ns4){
		with(document.layers["colorbox"]){
			top = posY +18;
			left = posX +17;
			visibility = true;
		}
	}
	if (ns6){
		with(document.getElementById("colorbox").style){
			top = ns6Y;
			left = ns6X;
			visibility = 'visible';
		}
	}

}

function ns6Get(e){
	ns6X = e.layerX;
	ns6Y = e.layerY;
	showColor(null,null);
}


// init function for NS6
function initColourPicker() {
	if (ns6){
  	cpicker = document.getElementById("pickcolour");
  	cpicker.addEventListener("click", ns6Get, false);
	}
}

function showBWPicker()
{
	a = new Array();
	a['0'] = "0";
	a['1'] = "1";
	a['2'] = "2";
	a['3'] = "3";
	a['4'] = "4";
	a['5'] = "5";
	a['6'] = "6";
	a['7'] = "7";
	a['8'] = "8";
	a['9'] = "9";
	a['10'] = "a";
	a['11'] = "b";
	a['12'] = "c";
	a['13'] = "d";
	a['14'] = "e";
	a['15'] = "f";
	
	for (i=0; i <= 15;i++)
	{
		if (i >0){
		document.write( "</tr>\n<tr>\n");
		}
		for (n=0;n <= 15;n++)
		{
			colour =  a[i]+a[n];
			colour += colour + colour;
			document.write("<td bgcolor=\"#"+colour+"\" onMouseOver=\"status = '#"+colour+"';return true\" width=\"7\" class=\"text\"><a href=\"#\" onClick=\"changeColor('"+colour+"')\"><img src=\"pixel.gif\" width=\"7\" height=\"7\" name=\"a"+i+n+"\" border=\"0\"></td>\n");			
		}
		
	}
}

function showColourPicker()
{
	c = new Array();
	
	c[1] = "FF";
	c[2] = "CC";
	c[3] = "99";
	c[4] = "66";
	c[5] = "33";
	c[6] = "00";
	d = 0;
	
	for (i=1;i <=6;i++)
	{
		if (i >1)
		{
			document.write( "</tr>\n<tr>\n");
		}

		for (m=1;m <=6;m++){		
			for (n=1;n <=6;n++)
			{	
				d++;
				colour = c[i] + c[m] + c[n];
				document.write("<td bgcolor=\"#"+colour+"\" width=7 class=\"text\"><a href=\"#\" onClick=\"changeColor('"+colour+"')\"><img src=\"pixel.gif\" width=7 height=7 name=\"a"+d+"\" border=0></td>\n");
			}
		}	
	}
}