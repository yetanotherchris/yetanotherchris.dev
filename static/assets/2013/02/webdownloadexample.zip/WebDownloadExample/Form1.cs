using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Net;
using System.IO;
using System.Threading;

namespace WebDownloadExample
{
	public class Form1 : System.Windows.Forms.Form
	{
		#region Components / private fields
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.ProgressBar progressBar1;
		private System.Windows.Forms.TextBox textBox1;
		private System.ComponentModel.IContainer components;

		private int sizeInK = 0;
		private byte[] arrBuffer;
		WebResponse webResponse;
		#endregion

		#region Constructor, dispose, main
		public Form1()
		{
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}
		#endregion

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.button1 = new System.Windows.Forms.Button();
			this.progressBar1 = new System.Windows.Forms.ProgressBar();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(206, 48);
			this.button1.Name = "button1";
			this.button1.TabIndex = 1;
			this.button1.Text = "button1";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// progressBar1
			// 
			this.progressBar1.Location = new System.Drawing.Point(8, 16);
			this.progressBar1.Name = "progressBar1";
			this.progressBar1.Size = new System.Drawing.Size(272, 23);
			this.progressBar1.TabIndex = 2;
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(8, 49);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(160, 20);
			this.textBox1.TabIndex = 3;
			this.textBox1.Text = "Amount downloaded here";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 78);
			this.Controls.Add(this.textBox1);
			this.Controls.Add(this.progressBar1);
			this.Controls.Add(this.button1);
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);

		}
		#endregion

		#region Button event handler
		private void button1_Click(object sender, System.EventArgs e)
		{
			/* Method 1
			WebClient webClient = new WebClient();	
			webClient.DownloadFile("http://newsimg.bbc.co.uk/media/images/38653000/jpg/_38653867_nuclear_n_korea2_100.jpg","c:\\test.jpg");
			*/

			/* Method 2
			WebClient webClient = new WebClient();	
			Stream strm = webClient.OpenRead("http://www.csharpfriends.com");
			StreamReader sr = new StreamReader(strm);
			string line;
			do
			{
				line = sr.ReadLine();
				if ( line != null )
				{
					listBox1.Items.Add(line);
				}
			}
			while (line !=null);
			strm.Close();
			*/

			// Initialize the WebRequest.
			WebRequest myRequest = WebRequest.Create("http://www.rarlab.com/rar/wrar340.exe");
			
			// Return the response. 
			webResponse = myRequest.GetResponse();

			sizeInK = (int) webResponse.ContentLength / 1024;
			progressBar1.Minimum = 0;
			progressBar1.Maximum = sizeInK;
			progressBar1.Value   = 0;

			Thread thread;
			thread = new Thread(new ThreadStart( threadEntry ));
			
			
			arrBuffer = new byte[0];
			thread.Start();
		}
		#endregion

		#region Thread entry point + save to disk
		void threadEntry()
		{
			int bytesTotal = 0;
			using( BinaryReader binaryReader = new BinaryReader(webResponse.GetResponseStream()) )
			{
				byte[] arrScratch = null;
				int bytesRetrieved = 0;

				while( (arrScratch = binaryReader.ReadBytes(4096)).Length > 0)
				{

					if (arrBuffer.Length == 0)
					{
						arrBuffer = arrScratch;
					}
					else
					{
						// Create temp array, size of main array, and scratch array
						byte[] arrTemp = new byte[arrBuffer.Length + arrScratch.Length];

						// Copy the main array to the temp one
						Array.Copy(arrBuffer, arrTemp, arrBuffer.Length);

						// Copy the scratch array to the end of temp array
						Array.Copy(arrScratch, 0, arrTemp, arrBuffer.Length,arrScratch.Length);

						// Make the main array the temp array, with the new
						// x amount of bytes
						arrBuffer = arrTemp;

						// Update progress bar etc.
						bytesRetrieved = arrScratch.Length / 1024;
						bytesTotal = arrBuffer.Length / 1024;

                        this.BeginInvoke( new progressbarUpdate( this.updateProgressBar ), new object[] { bytesTotal } );
                        this.BeginInvoke( new textboxUpdate( this.updateTextbox ), new object[] { bytesTotal + "/" + sizeInK + "k" } );	
					}
					
				}
			}
			saveToDisk();
		}

        delegate void textboxUpdate(string txt);
        delegate void progressbarUpdate(int val);

        void updateTextbox(string txt)
        {
            this.textBox1.Text = txt;
        }

        void updateProgressBar(int val)
        {
            progressBar1.Value = val;
        }

		void saveToDisk()
		{
			// Save to disk
			FileStream fileStream = new FileStream("C:\\wrar340.exe",FileMode.CreateNew);
			BinaryWriter binaryWriter = new BinaryWriter(fileStream);
			for (int i=0;i < arrBuffer.Length;i++)
			{
				binaryWriter.Write(arrBuffer[i]);
			}
			binaryWriter.Close();
			fileStream.Close();

			// Close the response to free resources.
			webResponse.Close();
		}
		#endregion
	}

}
