using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;

namespace ImageConverter
{
	public class ImageConverter : System.Windows.Forms.Form
	{
		#region Components
		private System.Windows.Forms.OpenFileDialog openFileDialog1;
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Button buttonConvert;
		private System.Windows.Forms.GroupBox groupBoxPreview;
		private System.Windows.Forms.GroupBox groupBoxOutput;
		private System.Windows.Forms.RadioButton radioButtonJpeg;
		private System.Windows.Forms.RadioButton radioButtonBmp;
		private System.Windows.Forms.RadioButton radioButtonGif;
		private System.Windows.Forms.RadioButton radioButtonTif;
		private System.Windows.Forms.Button buttonChooseImage;
		private System.Windows.Forms.Button buttonClose;

		private System.Windows.Forms.Label labelImageFormat;
		private System.Windows.Forms.RadioButton radioButtonIcon;
		private System.Windows.Forms.RadioButton radioButtonPng;
		private System.Windows.Forms.RadioButton radioButtonWmf;
		#endregion
		
		#region Private fields
		// jpeg,bmp,gif,tif,icon,png,wmf (also exif,emf)
		private ImageFormat convertToFormat = ImageFormat.Jpeg;
		private Bitmap bmp;
		#endregion

		#region Constructor,dispose,main
		public ImageConverter()
		{
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new ImageConverter());
		}
		#endregion

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.buttonConvert = new System.Windows.Forms.Button();
			this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			this.groupBoxPreview = new System.Windows.Forms.GroupBox();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.groupBoxOutput = new System.Windows.Forms.GroupBox();
			this.radioButtonTif = new System.Windows.Forms.RadioButton();
			this.radioButtonGif = new System.Windows.Forms.RadioButton();
			this.radioButtonBmp = new System.Windows.Forms.RadioButton();
			this.radioButtonJpeg = new System.Windows.Forms.RadioButton();
			this.buttonChooseImage = new System.Windows.Forms.Button();
			this.buttonClose = new System.Windows.Forms.Button();
			this.radioButtonIcon = new System.Windows.Forms.RadioButton();
			this.radioButtonPng = new System.Windows.Forms.RadioButton();
			this.radioButtonWmf = new System.Windows.Forms.RadioButton();
			this.labelImageFormat = new System.Windows.Forms.Label();
			this.groupBoxPreview.SuspendLayout();
			this.groupBoxOutput.SuspendLayout();
			this.SuspendLayout();
			// 
			// buttonConvert
			// 
			this.buttonConvert.Enabled = false;
			this.buttonConvert.Location = new System.Drawing.Point(320, 288);
			this.buttonConvert.Name = "buttonConvert";
			this.buttonConvert.TabIndex = 0;
			this.buttonConvert.Text = "Convert";
			this.buttonConvert.Click += new System.EventHandler(this.buttonConvert_Click);
			// 
			// openFileDialog1
			// 
			this.openFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog1_FileOk);
			// 
			// groupBoxPreview
			// 
			this.groupBoxPreview.Controls.AddRange(new System.Windows.Forms.Control[] {
																						  this.pictureBox1});
			this.groupBoxPreview.Location = new System.Drawing.Point(128, 55);
			this.groupBoxPreview.Name = "groupBoxPreview";
			this.groupBoxPreview.Size = new System.Drawing.Size(352, 224);
			this.groupBoxPreview.TabIndex = 2;
			this.groupBoxPreview.TabStop = false;
			this.groupBoxPreview.Text = " Preview ";
			// 
			// pictureBox1
			// 
			this.pictureBox1.Location = new System.Drawing.Point(13, 20);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(330, 190);
			this.pictureBox1.TabIndex = 2;
			this.pictureBox1.TabStop = false;
			// 
			// groupBoxOutput
			// 
			this.groupBoxOutput.Controls.AddRange(new System.Windows.Forms.Control[] {
																						 this.radioButtonWmf,
																						 this.radioButtonPng,
																						 this.radioButtonIcon,
																						 this.radioButtonTif,
																						 this.radioButtonGif,
																						 this.radioButtonBmp,
																						 this.radioButtonJpeg});
			this.groupBoxOutput.Location = new System.Drawing.Point(16, 55);
			this.groupBoxOutput.Name = "groupBoxOutput";
			this.groupBoxOutput.Size = new System.Drawing.Size(96, 224);
			this.groupBoxOutput.TabIndex = 3;
			this.groupBoxOutput.TabStop = false;
			this.groupBoxOutput.Text = "Output format";
			// 
			// radioButtonTif
			// 
			this.radioButtonTif.Location = new System.Drawing.Point(13, 98);
			this.radioButtonTif.Name = "radioButtonTif";
			this.radioButtonTif.Size = new System.Drawing.Size(56, 24);
			this.radioButtonTif.TabIndex = 3;
			this.radioButtonTif.Text = "TIF";
			this.radioButtonTif.CheckedChanged += new System.EventHandler(this.radioButtonTif_CheckedChanged);
			// 
			// radioButtonGif
			// 
			this.radioButtonGif.Location = new System.Drawing.Point(13, 72);
			this.radioButtonGif.Name = "radioButtonGif";
			this.radioButtonGif.Size = new System.Drawing.Size(56, 24);
			this.radioButtonGif.TabIndex = 2;
			this.radioButtonGif.Text = "GIF";
			this.radioButtonGif.CheckedChanged += new System.EventHandler(this.radioButtonGif_CheckedChanged);
			// 
			// radioButtonBmp
			// 
			this.radioButtonBmp.Location = new System.Drawing.Point(13, 48);
			this.radioButtonBmp.Name = "radioButtonBmp";
			this.radioButtonBmp.Size = new System.Drawing.Size(56, 24);
			this.radioButtonBmp.TabIndex = 1;
			this.radioButtonBmp.Text = "BMP";
			this.radioButtonBmp.CheckedChanged += new System.EventHandler(this.radioButtonBmp_CheckedChanged);
			// 
			// radioButtonJpeg
			// 
			this.radioButtonJpeg.Checked = true;
			this.radioButtonJpeg.Location = new System.Drawing.Point(13, 26);
			this.radioButtonJpeg.Name = "radioButtonJpeg";
			this.radioButtonJpeg.Size = new System.Drawing.Size(56, 24);
			this.radioButtonJpeg.TabIndex = 0;
			this.radioButtonJpeg.TabStop = true;
			this.radioButtonJpeg.Text = "JPEG";
			this.radioButtonJpeg.CheckedChanged += new System.EventHandler(this.radioButtonJpeg_CheckedChanged);
			// 
			// buttonChooseImage
			// 
			this.buttonChooseImage.Location = new System.Drawing.Point(16, 16);
			this.buttonChooseImage.Name = "buttonChooseImage";
			this.buttonChooseImage.Size = new System.Drawing.Size(160, 23);
			this.buttonChooseImage.TabIndex = 4;
			this.buttonChooseImage.Text = "Browse image to convert...";
			this.buttonChooseImage.Click += new System.EventHandler(this.buttonChooseImage_Click);
			// 
			// buttonClose
			// 
			this.buttonClose.Location = new System.Drawing.Point(404, 288);
			this.buttonClose.Name = "buttonClose";
			this.buttonClose.TabIndex = 5;
			this.buttonClose.Text = "Close";
			this.buttonClose.Click += new System.EventHandler(this.buttonClose_Click);
			// 
			// radioButtonIcon
			// 
			this.radioButtonIcon.Location = new System.Drawing.Point(13, 125);
			this.radioButtonIcon.Name = "radioButtonIcon";
			this.radioButtonIcon.Size = new System.Drawing.Size(56, 24);
			this.radioButtonIcon.TabIndex = 4;
			this.radioButtonIcon.Text = "Icon";
			this.radioButtonIcon.CheckedChanged += new System.EventHandler(this.radioButtonIcon_CheckedChanged);
			// 
			// radioButtonPng
			// 
			this.radioButtonPng.Location = new System.Drawing.Point(13, 152);
			this.radioButtonPng.Name = "radioButtonPng";
			this.radioButtonPng.Size = new System.Drawing.Size(56, 24);
			this.radioButtonPng.TabIndex = 5;
			this.radioButtonPng.Text = "PNG";
			this.radioButtonPng.CheckedChanged += new System.EventHandler(this.radioButtonPng_CheckedChanged);
			// 
			// radioButtonWmf
			// 
			this.radioButtonWmf.Location = new System.Drawing.Point(13, 184);
			this.radioButtonWmf.Name = "radioButtonWmf";
			this.radioButtonWmf.Size = new System.Drawing.Size(56, 24);
			this.radioButtonWmf.TabIndex = 6;
			this.radioButtonWmf.Text = "WMF";
			this.radioButtonWmf.CheckedChanged += new System.EventHandler(this.radioButtonWmf_CheckedChanged);
			// 
			// labelImageFormat
			// 
			this.labelImageFormat.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.labelImageFormat.Location = new System.Drawing.Point(3, 322);
			this.labelImageFormat.Name = "labelImageFormat";
			this.labelImageFormat.Size = new System.Drawing.Size(477, 16);
			this.labelImageFormat.TabIndex = 6;
			// 
			// ImageConverter
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.AutoScroll = true;
			this.ClientSize = new System.Drawing.Size(488, 342);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.labelImageFormat,
																		  this.buttonClose,
																		  this.buttonChooseImage,
																		  this.groupBoxOutput,
																		  this.groupBoxPreview,
																		  this.buttonConvert});
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Name = "ImageConverter";
			this.Text = "Image Converter";
			this.groupBoxPreview.ResumeLayout(false);
			this.groupBoxOutput.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		#region The rest!
		private void buttonConvert_Click(object sender, System.EventArgs e)
		{
			// If we have a file
			if ( openFileDialog1.FileName != "" )
			{
				// Convert to the specified format
				string filename = getFilenameFromImageFormat( openFileDialog1.FileName );

				try
				{
					// Using save method on small images is okay, this should
					// create a new, seperate, thread if the converter is
					// going to deal with larger images, to stop the app
					// freezing.
					bmp.Save(filename,convertToFormat);
					labelImageFormat.Text = "Saved " + filename;
				}
				catch ( Exception err)
				{
					MessageBox.Show( err.Message );
				}
				finally
				{
					//
				}

			}
		}

		/// <summary>
		/// Find a filename for the new converted image to be saved as,
		/// and give it the appropriate extension.
		/// </summary>
		/// <param name="filename"></param>
		/// <returns></returns>
		private string getFilenameFromImageFormat( string filename )
		{
			filename = stripExtension(filename);

			switch ( convertToFormat.ToString() )
			{
				case "Jpeg":
					filename = findUseableFilename(filename,"jpg");
					break;
				case "Bmp":
					filename = findUseableFilename(filename,"bmp");
					break;
				case "Gif":
					filename = findUseableFilename(filename,"gif");
					break;
				case "Tiff":
					filename = findUseableFilename(filename,"tif");
					break;
				case "Icon":
					filename = findUseableFilename(filename,"ico");
					break;
				case "Png":
					filename = findUseableFilename(filename,"png");
					break;
				case "Wmf":
					filename = findUseableFilename(filename,"wmf");
					break;
			}

			return filename;
			
		}

		/// <summary>
		/// Attempts to find (sort of) unique filename for the new
		/// image format.
		/// </summary>
		/// <param name="filename"></param>
		/// <param name="extension"></param>
		/// <returns></returns>
		private string findUseableFilename( string filename, string extension )
		{
			if ( filename != "" && filename.Length > 0 )
			{
				filename = stripExtension( filename );

				// If the filename and "." and new image format
				// extension already exists, find a new name. This
				// way of doing it is clumsy way of coming up a unique name
				// and would require a better algorithm in a commercial
				// application.
				if ( File.Exists(filename + "." + extension) )
				{
					for (int i=1;i <= 2000;i++)
					{
						if ( !File.Exists(filename + i + "." + extension) )
						{
							filename = filename + i + "." + extension;
							break;
						}
					}
				}
				else
				{
					// Otherwise use existing name and new extension type
					filename = filename + "." + extension;
				}
			}
			return filename;
		}

		/// <summary>
		/// Removes the extension from the filename
		/// </summary>
		/// <param name="filename"></param>
		/// <returns></returns>
		private string stripExtension( string filename )
		{
			if ( File.Exists( filename ) )
			{
				FileInfo fileInfo = new FileInfo( filename );
				string extension = fileInfo.Extension;
				filename = filename.Replace( extension, "" );
			}

			return filename;
		}

		private void buttonChooseImage_Click(object sender, System.EventArgs e)
		{
			openFileDialog1.ShowDialog();
		}

		private void openFileDialog1_FileOk(object sender, System.ComponentModel.CancelEventArgs e)
		{
			if ( openFileDialog1.FileName != "" )
			{
				// Open the file chosen
				try
				{
					bmp = new Bitmap(openFileDialog1.FileName);
				}
				catch (Exception err)
				{
					MessageBox.Show(err.Message);
				}
				finally
				{
					//
				}

				// Make the convert button available
				buttonConvert.Enabled = true;

				// Bring up a thumbnail with the picture box.
				// This is fixed size, though you could stretch the
				// picture box width to the size of the bmp's width
				pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
				pictureBox1.Image = bmp;
			}
		}
		#endregion

		#region Checkbox change, close
		private void buttonClose_Click(object sender, System.EventArgs e)
		{
			Application.Exit();
		}

		private void radioButtonJpeg_CheckedChanged(object sender, System.EventArgs e)
		{
			convertToFormat = ImageFormat.Jpeg;
		}

		private void radioButtonBmp_CheckedChanged(object sender, System.EventArgs e)
		{
			convertToFormat = ImageFormat.Bmp;
		}

		private void radioButtonGif_CheckedChanged(object sender, System.EventArgs e)
		{
			convertToFormat = ImageFormat.Gif;
		}

		private void radioButtonTif_CheckedChanged(object sender, System.EventArgs e)
		{
			convertToFormat = ImageFormat.Tiff;
		}

		private void radioButtonIcon_CheckedChanged(object sender, System.EventArgs e)
		{
			convertToFormat = ImageFormat.Icon;
		}

		private void radioButtonPng_CheckedChanged(object sender, System.EventArgs e)
		{
			convertToFormat = ImageFormat.Png;
		}

		private void radioButtonWmf_CheckedChanged(object sender, System.EventArgs e)
		{
			convertToFormat = ImageFormat.Wmf;
		}
		#endregion
	}
}
