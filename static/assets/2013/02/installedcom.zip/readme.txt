Installed Coms Finder
Version 1.00

� C.Small  2000-2001
Bugs + info: sloppycode@sloppycode.net
Website: www.sloppycode.net

Contents
========

1. Introduction
2. Installation
3. Documentation
4. Example usage

1. Introduction
---------------
This simple Delphi example application is simple way of checking what COM servers are installed on the computer the application is running from. It uses registry settings to retrieve information about the classid, progid, location and names of the COMs installed, and is a good example of how to use the TRegistry class and the TListView class. The application could easily be extended to have custom code to uninstall and install COMs, and could in particular be a useful tool for ASP developers wanting to find out what ASP components they have installed, as well as developers all round. 

2. Installation
---------------
Just unzip the ZIP file to a folder and run regfind.exe or view the regfind.dpr Delphi package.

3. Documentation
---------------
See the manual.html file that comes with this package.

4. Example Usage
---------------
See the regfind.dpr Delphi package.