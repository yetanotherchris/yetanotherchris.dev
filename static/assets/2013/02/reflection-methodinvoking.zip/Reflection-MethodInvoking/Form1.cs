using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Runtime.Remoting;

namespace ReflectionInvokeMethod
{
	public class Form1 : System.Windows.Forms.Form
	{
		#region Components
		private System.Windows.Forms.OpenFileDialog openFileDialog1;
		private System.Windows.Forms.ListBox listBox2;
		private System.Windows.Forms.Button buttonCall;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.ListBox listBox1;
		private System.Windows.Forms.Button buttonBrowse;
		private System.Windows.Forms.Panel panel3;
		private System.Windows.Forms.Panel panel4;
		private System.Windows.Forms.PropertyGrid propertyGrid1;
		private System.ComponentModel.Container components = null;
		private Assembly assembly;
		#endregion

		#region Constructor, dispose, main
		public Form1()
		{
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}
		#endregion

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			this.buttonCall = new System.Windows.Forms.Button();
			this.listBox2 = new System.Windows.Forms.ListBox();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.panel1 = new System.Windows.Forms.Panel();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.listBox1 = new System.Windows.Forms.ListBox();
			this.panel2 = new System.Windows.Forms.Panel();
			this.panel4 = new System.Windows.Forms.Panel();
			this.buttonBrowse = new System.Windows.Forms.Button();
			this.panel3 = new System.Windows.Forms.Panel();
			this.propertyGrid1 = new System.Windows.Forms.PropertyGrid();
			this.groupBox2.SuspendLayout();
			this.panel1.SuspendLayout();
			this.groupBox1.SuspendLayout();
			this.panel2.SuspendLayout();
			this.panel4.SuspendLayout();
			this.panel3.SuspendLayout();
			this.SuspendLayout();
			// 
			// openFileDialog1
			// 
			this.openFileDialog1.Filter = " All files | *.*";
			this.openFileDialog1.InitialDirectory = "C:\\WINDOWS\\Microsoft.NET\\Framework\\v1.1.4322";
			// 
			// buttonCall
			// 
			this.buttonCall.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonCall.Location = new System.Drawing.Point(592, 8);
			this.buttonCall.Name = "buttonCall";
			this.buttonCall.TabIndex = 7;
			this.buttonCall.Text = "Call";
			this.buttonCall.Click += new System.EventHandler(this.buttonCall_Click);
			// 
			// listBox2
			// 
			this.listBox2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.listBox2.Location = new System.Drawing.Point(3, 16);
			this.listBox2.Name = "listBox2";
			this.listBox2.Size = new System.Drawing.Size(666, 108);
			this.listBox2.TabIndex = 5;
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.listBox2);
			this.groupBox2.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.groupBox2.Location = new System.Drawing.Point(0, 118);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(672, 128);
			this.groupBox2.TabIndex = 8;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Methods";
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.groupBox1);
			this.panel1.Controls.Add(this.groupBox2);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(672, 246);
			this.panel1.TabIndex = 9;
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.listBox1);
			this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBox1.Location = new System.Drawing.Point(0, 0);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(672, 118);
			this.groupBox1.TabIndex = 9;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Assembly members";
			// 
			// listBox1
			// 
			this.listBox1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.listBox1.Location = new System.Drawing.Point(3, 16);
			this.listBox1.Name = "listBox1";
			this.listBox1.Size = new System.Drawing.Size(666, 95);
			this.listBox1.TabIndex = 4;
			this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
			// 
			// panel2
			// 
			this.panel2.Controls.Add(this.panel4);
			this.panel2.Controls.Add(this.panel3);
			this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panel2.Location = new System.Drawing.Point(0, 246);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(672, 184);
			this.panel2.TabIndex = 10;
			// 
			// panel4
			// 
			this.panel4.Controls.Add(this.buttonBrowse);
			this.panel4.Controls.Add(this.buttonCall);
			this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panel4.Location = new System.Drawing.Point(0, 144);
			this.panel4.Name = "panel4";
			this.panel4.Size = new System.Drawing.Size(672, 40);
			this.panel4.TabIndex = 9;
			// 
			// buttonBrowse
			// 
			this.buttonBrowse.Location = new System.Drawing.Point(8, 9);
			this.buttonBrowse.Name = "buttonBrowse";
			this.buttonBrowse.TabIndex = 3;
			this.buttonBrowse.Text = "Browse...";
			this.buttonBrowse.Click += new System.EventHandler(this.buttonBrowse_Click);
			// 
			// panel3
			// 
			this.panel3.Controls.Add(this.propertyGrid1);
			this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel3.Location = new System.Drawing.Point(0, 0);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(672, 184);
			this.panel3.TabIndex = 8;
			// 
			// propertyGrid1
			// 
			this.propertyGrid1.CommandsVisibleIfAvailable = true;
			this.propertyGrid1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.propertyGrid1.LargeButtons = false;
			this.propertyGrid1.LineColor = System.Drawing.SystemColors.ScrollBar;
			this.propertyGrid1.Location = new System.Drawing.Point(0, 0);
			this.propertyGrid1.Name = "propertyGrid1";
			this.propertyGrid1.Size = new System.Drawing.Size(672, 184);
			this.propertyGrid1.TabIndex = 0;
			this.propertyGrid1.Text = "propertyGrid1";
			this.propertyGrid1.ViewBackColor = System.Drawing.SystemColors.Window;
			this.propertyGrid1.ViewForeColor = System.Drawing.SystemColors.WindowText;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(672, 430);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.panel2);
			this.Name = "Form1";
			this.Text = "Form1";
			this.groupBox2.ResumeLayout(false);
			this.panel1.ResumeLayout(false);
			this.groupBox1.ResumeLayout(false);
			this.panel2.ResumeLayout(false);
			this.panel4.ResumeLayout(false);
			this.panel3.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		#region All the rest
		private void listBox1_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if ( this.listBox1.SelectedItems.Count == 1 )
			{
				try
				{
					string name = (string) this.listBox1.SelectedItems[0];
					Type type = assembly.GetType(name,true,false);

					this.listBox2.Items.Clear();
					foreach (MethodInfo methodInfo in type.GetMethods())  
					{
						this.listBox2.Items.Add(methodInfo.Name);
					}
				}
				catch (TypeLoadException er)
				{
					MessageBox.Show(er.Message);
				}
				catch (ReflectionTypeLoadException er)
				{
					MessageBox.Show(er.Message);
				}
				catch (ArgumentException er)
				{
					MessageBox.Show(er.Message);
				}


			}
		}

		private void buttonBrowse_Click(object sender, System.EventArgs e)
		{
			if ( this.openFileDialog1.ShowDialog() == DialogResult.OK)
			{
				assembly = Assembly.LoadFrom(this.openFileDialog1.FileName); 
 
				Type [] assemblyTypes = assembly.GetTypes();  
				this.listBox1.Items.Clear();
				foreach (Type type in assemblyTypes)  
				{
					this.listBox1.Items.Add(type.FullName);
				}
			}	
		}

		private void buttonCall_Click(object sender, System.EventArgs e)
		{
			if ( this.listBox2.SelectedItems.Count == 1 )
			{
				
				string classname = (string) this.listBox1.SelectedItems[0];
				string methodname = (string) this.listBox2.SelectedItems[0];

				Type type = assembly.GetType(classname,true,false);
				MethodInfo methodInfo = type.GetMethod(methodname);

				object[] args = new object[methodInfo.GetParameters().Length];

				int i = 0;

				// Originally this was used for API call testing - this has been stripped out and looks fairly 
				// useless (which it will be to most .NET classes). As all of these API classes inherited from a
				// common interface, the constructor was known, and the output was what was being looked for.
				if ( methodInfo != null )
				{
					string argvalue = "";
					foreach ( ParameterInfo parameterInfo in methodInfo.GetParameters() )
					{
						argvalue = Microsoft.VisualBasic.Interaction.InputBox("Enter a value for " +parameterInfo.Name+ "(" +parameterInfo.ParameterType.ToString()+")","Argument","",this.Location.X,this.Location.Y);
						switch ( parameterInfo.ParameterType.Name )
						{
							case "Int32":
								args.SetValue(Convert.ToInt32(argvalue),i++);
								break;
							case "Boolean":
								args.SetValue(Boolean.Parse(argvalue),i++);
								break;
							case "String":
								args.SetValue(argvalue,i++);
								break;
							case "Byte":
								args.SetValue(Convert.ToByte(argvalue),i++);
								break;
						}
					}
				}

				object objectInstance = System.Activator.CreateInstance(type);

				this.listBox2.Items.Clear();
				foreach (MethodInfo methodInfoA in objectInstance.GetType().GetMethods())  
				{
					this.listBox2.Items.Add(methodInfoA.Name);
				}

				object result = methodInfo.Invoke(objectInstance,args);
				this.propertyGrid1.SelectedObject = result;
			}
		}
		#endregion
	}
}
