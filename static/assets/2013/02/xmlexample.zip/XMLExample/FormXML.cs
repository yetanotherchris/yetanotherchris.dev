using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Xml;

namespace XMLExample
{
	public class FormXML : System.Windows.Forms.Form
	{
		#region Components
		private System.Windows.Forms.TreeView treeView1;
		private System.Windows.Forms.Button buttonLoad;
		private System.Windows.Forms.Button buttonClose;
		private System.Windows.Forms.OpenFileDialog openFileDialog1;
		private System.Windows.Forms.ColumnHeader columnHeader1;
		private System.Windows.Forms.ColumnHeader columnHeader2;
		private System.Windows.Forms.GroupBox groupBoxAttributes;
		private System.Windows.Forms.GroupBox groupBoxNodeValue;
		private System.Windows.Forms.TextBox textBoxNodeValue;
		private System.Windows.Forms.ListView listViewAttributes;
		private System.ComponentModel.Container components = null;
		#endregion

		#region Constructor, dispose, main
		public FormXML()
		{
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new FormXML());
		}
		#endregion

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.treeView1 = new System.Windows.Forms.TreeView();
			this.buttonLoad = new System.Windows.Forms.Button();
			this.buttonClose = new System.Windows.Forms.Button();
			this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			this.listViewAttributes = new System.Windows.Forms.ListView();
			this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
			this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
			this.groupBoxAttributes = new System.Windows.Forms.GroupBox();
			this.groupBoxNodeValue = new System.Windows.Forms.GroupBox();
			this.textBoxNodeValue = new System.Windows.Forms.TextBox();
			this.groupBoxAttributes.SuspendLayout();
			this.groupBoxNodeValue.SuspendLayout();
			this.SuspendLayout();
			// 
			// treeView1
			// 
			this.treeView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.treeView1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.treeView1.ImageIndex = -1;
			this.treeView1.Location = new System.Drawing.Point(8, 8);
			this.treeView1.Name = "treeView1";
			this.treeView1.SelectedImageIndex = -1;
			this.treeView1.Size = new System.Drawing.Size(480, 200);
			this.treeView1.TabIndex = 0;
			this.treeView1.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView1_AfterSelect);
			// 
			// buttonLoad
			// 
			this.buttonLoad.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonLoad.Location = new System.Drawing.Point(412, 424);
			this.buttonLoad.Name = "buttonLoad";
			this.buttonLoad.TabIndex = 1;
			this.buttonLoad.Text = "Load File";
			this.buttonLoad.Click += new System.EventHandler(this.buttonLoad_Click);
			// 
			// buttonClose
			// 
			this.buttonClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonClose.Location = new System.Drawing.Point(331, 424);
			this.buttonClose.Name = "buttonClose";
			this.buttonClose.TabIndex = 2;
			this.buttonClose.Text = "Close";
			this.buttonClose.Click += new System.EventHandler(this.buttonClose_Click);
			// 
			// openFileDialog1
			// 
			this.openFileDialog1.FileName = "System.Windows.Forms.xml";
			this.openFileDialog1.Filter = "XML files (*.xml)|*.xml|All files (*.*) |*.*";
			this.openFileDialog1.InitialDirectory = "C:\\WINDOWS\\Microsoft.NET\\Framework\\v1.1.4322\\";
			// 
			// listViewAttributes
			// 
			this.listViewAttributes.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																								 this.columnHeader1,
																								 this.columnHeader2});
			this.listViewAttributes.Dock = System.Windows.Forms.DockStyle.Fill;
			this.listViewAttributes.Location = new System.Drawing.Point(3, 17);
			this.listViewAttributes.Name = "listViewAttributes";
			this.listViewAttributes.Size = new System.Drawing.Size(474, 100);
			this.listViewAttributes.TabIndex = 4;
			this.listViewAttributes.View = System.Windows.Forms.View.Details;
			// 
			// columnHeader1
			// 
			this.columnHeader1.Text = "Name";
			this.columnHeader1.Width = 172;
			// 
			// columnHeader2
			// 
			this.columnHeader2.Text = "Value";
			this.columnHeader2.Width = 298;
			// 
			// groupBoxAttributes
			// 
			this.groupBoxAttributes.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.groupBoxAttributes.Controls.Add(this.listViewAttributes);
			this.groupBoxAttributes.Location = new System.Drawing.Point(8, 296);
			this.groupBoxAttributes.Name = "groupBoxAttributes";
			this.groupBoxAttributes.Size = new System.Drawing.Size(480, 120);
			this.groupBoxAttributes.TabIndex = 5;
			this.groupBoxAttributes.TabStop = false;
			this.groupBoxAttributes.Text = "Attributes";
			// 
			// groupBoxNodeValue
			// 
			this.groupBoxNodeValue.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.groupBoxNodeValue.Controls.Add(this.textBoxNodeValue);
			this.groupBoxNodeValue.Location = new System.Drawing.Point(8, 216);
			this.groupBoxNodeValue.Name = "groupBoxNodeValue";
			this.groupBoxNodeValue.Size = new System.Drawing.Size(480, 72);
			this.groupBoxNodeValue.TabIndex = 6;
			this.groupBoxNodeValue.TabStop = false;
			this.groupBoxNodeValue.Text = "Node value";
			// 
			// textBoxNodeValue
			// 
			this.textBoxNodeValue.Dock = System.Windows.Forms.DockStyle.Fill;
			this.textBoxNodeValue.Location = new System.Drawing.Point(3, 17);
			this.textBoxNodeValue.Multiline = true;
			this.textBoxNodeValue.Name = "textBoxNodeValue";
			this.textBoxNodeValue.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.textBoxNodeValue.Size = new System.Drawing.Size(474, 52);
			this.textBoxNodeValue.TabIndex = 0;
			this.textBoxNodeValue.Text = "";
			// 
			// FormXML
			// 
			this.AcceptButton = this.buttonLoad;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.CancelButton = this.buttonClose;
			this.ClientSize = new System.Drawing.Size(496, 456);
			this.Controls.Add(this.treeView1);
			this.Controls.Add(this.groupBoxNodeValue);
			this.Controls.Add(this.groupBoxAttributes);
			this.Controls.Add(this.buttonClose);
			this.Controls.Add(this.buttonLoad);
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "FormXML";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "XML Example";
			this.groupBoxAttributes.ResumeLayout(false);
			this.groupBoxNodeValue.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		#region Close, Load button
		private void buttonClose_Click(object sender, System.EventArgs e)
		{
			Application.Exit();
		}

		private void buttonLoad_Click(object sender, System.EventArgs e)
		{
			if ( openFileDialog1.ShowDialog() == DialogResult.OK )
			{
				treeView1.Nodes.Clear();
				System.Xml.XmlDocument xmlDoc= new System.Xml.XmlDocument();
				
				try
				{
					this.Cursor = Cursors.WaitCursor;
					xmlDoc.Load(openFileDialog1.FileName);

					this.treeView1.BeginUpdate();

					// Go through all child nodes
					treeView1.Nodes.Add( openFileDialog1.FileName );
					iterateNodes( xmlDoc.ChildNodes,treeView1.Nodes[0] );

					this.treeView1.EndUpdate();
				}
				catch (XmlException err)
				{
					MessageBox.Show(err.Message);
				}
				finally
				{
					this.Cursor = Cursors.Default;
				}	
			}
		}
		#endregion

		#region Iterate nodes, after select
		private void iterateNodes(XmlNodeList childNodes,TreeNode treeNode)
		{
			// Go through all child nodes
			for (int i=0;i <= childNodes.Count -1;i++)
			{
				TreeNode newTreeNode;

				// Display node name, if an element
				if ( childNodes[i].ToString() == "System.Xml.XmlElement" )
				{
					newTreeNode = new TreeNode( childNodes[i].Name);// + " (" +childNodes[i].ToString() + ")");
					newTreeNode.Tag = childNodes[i];
					treeNode.Nodes.Add(	newTreeNode );		

					// If this node has children, go through them
					if ( childNodes[i].ChildNodes.Count > 0 )
					{
						iterateNodes(childNodes[i].ChildNodes,newTreeNode);
					}
				}
			}
		}

		private void treeView1_AfterSelect(object sender, System.Windows.Forms.TreeViewEventArgs e)
		{
			if ( treeView1.SelectedNode != null && treeView1.SelectedNode.Tag != null && treeView1.SelectedNode.Tag.ToString() == "System.Xml.XmlElement" )
			{
				XmlElement childNode = (XmlElement) e.Node.Tag;

				// Display the node value
				this.textBoxNodeValue.Text = childNode.InnerText;

				// Display attribute names and values for current node
				listViewAttributes.Items.Clear();
				XmlAttributeCollection attribCollection = childNode.Attributes;

				if ( attribCollection != null )
				{
					for (int j=0;j <= attribCollection.Count -1;j++)
					{
						ListViewItem lvi = this.listViewAttributes.Items.Add(attribCollection[j].Name);
						lvi.SubItems.Add( attribCollection[j].Value );
					}
				}

				
			}
		}
		#endregion
	}
}
