using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace TestApp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.ImageList imageList1;
		private Sloppycode.UI.TreeViewDragDrop treeViewDragDrop1;
		private System.Windows.Forms.StatusBar statusBar1;
		private System.ComponentModel.IContainer components;

		// Cursor from: http://www.raspage.com/pages/mainframe.html
		public Form1()
		{
			InitializeComponent();

			Cursor cursor = new Cursor(GetType(), "DragCursor.cur");
			this.treeViewDragDrop1.DragCursor = cursor;

			for (int i=0;i < 100;i++)
			{
				this.treeViewDragDrop1.Nodes.Add("node "+i);
			}
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.imageList1 = new System.Windows.Forms.ImageList(this.components);
			this.treeViewDragDrop1 = new Sloppycode.UI.TreeViewDragDrop();
			this.statusBar1 = new System.Windows.Forms.StatusBar();
			this.SuspendLayout();
			// 
			// imageList1
			// 
			this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
			this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
			this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// treeViewDragDrop1
			// 
			this.treeViewDragDrop1.AllowDrop = true;
			this.treeViewDragDrop1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.treeViewDragDrop1.DragCursor = System.Windows.Forms.Cursors.IBeam;
			this.treeViewDragDrop1.DragCursorType = Sloppycode.UI.DragCursorType.DragIcon;
			this.treeViewDragDrop1.DragImageIndex = 0;
			this.treeViewDragDrop1.DragImageList = this.imageList1;
			this.treeViewDragDrop1.DragMode = System.Windows.Forms.DragDropEffects.Move;
			this.treeViewDragDrop1.DragNodeFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.treeViewDragDrop1.DragNodeOpacity = 0.3;
			this.treeViewDragDrop1.DragOverNodeBackColor = System.Drawing.SystemColors.Highlight;
			this.treeViewDragDrop1.DragOverNodeForeColor = System.Drawing.SystemColors.HighlightText;
			this.treeViewDragDrop1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.treeViewDragDrop1.ImageList = this.imageList1;
			this.treeViewDragDrop1.Location = new System.Drawing.Point(0, 0);
			this.treeViewDragDrop1.Name = "treeViewDragDrop1";
			this.treeViewDragDrop1.Size = new System.Drawing.Size(472, 382);
			this.treeViewDragDrop1.TabIndex = 0;
			this.treeViewDragDrop1.DragStart += new Sloppycode.UI.DragItemEventHandler(this.treeViewDragDrop1_DragStart);
			this.treeViewDragDrop1.DragComplete += new Sloppycode.UI.DragCompleteEventHandler(this.treeViewDragDrop1_DragComplete);
			this.treeViewDragDrop1.DragCancel += new Sloppycode.UI.DragItemEventHandler(this.treeViewDragDrop1_DragCancel);
			// 
			// statusBar1
			// 
			this.statusBar1.Location = new System.Drawing.Point(0, 360);
			this.statusBar1.Name = "statusBar1";
			this.statusBar1.Size = new System.Drawing.Size(472, 22);
			this.statusBar1.TabIndex = 1;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(472, 382);
			this.Controls.Add(this.statusBar1);
			this.Controls.Add(this.treeViewDragDrop1);
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void treeViewDragDrop1_DragStart(object sender, Sloppycode.UI.DragItemEventArgs e)
		{
			// Example of stopping drag and drop based on the 
			// node being dragged.
			if ( e.Node.Text == "node 1" )
			{
				this.statusBar1.Text = "Blocked node 1 from being dragged.";
				this.treeViewDragDrop1.AllowDrop = false;
			}
			else
			{
				this.statusBar1.Text = "";
				this.treeViewDragDrop1.AllowDrop = true;
			}
		}

		private void treeViewDragDrop1_DragComplete(object sender, Sloppycode.UI.DragCompleteEventArgs e)
		{
			this.statusBar1.Text = "Dragged "+e.SourceNode.Text+" onto "+e.TargetNode.Text;
		}

		private void treeViewDragDrop1_DragCancel(object sender, Sloppycode.UI.DragItemEventArgs e)
		{
			this.statusBar1.Text = "Drag cancelled.";
		}
	}
}
