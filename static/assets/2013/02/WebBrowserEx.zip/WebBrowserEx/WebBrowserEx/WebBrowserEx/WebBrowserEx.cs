using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using mshtml;
using System.Runtime.InteropServices;
using System.Drawing.Design;
using System.Windows.Forms.Design;

namespace Sloppycode.Controls
{
	/// <summary>
	/// Provides enhanced functionality for the windows inbuilt web browser control.
	/// </summary>
	/// <remarks>Icon from http://www.virtualplastic.net/scrow/system.html</remarks>
	[ToolboxBitmap(typeof(WebBrowserEx))]
	public class WebBrowserEx : System.Windows.Forms.UserControl, IDocHostUIHandler, IOleClientSite
	{
		#region Custom properties
		/// <summary>
		/// Gets or set the CurrentDocument.
		/// </summary>
		[
		Browsable(false),
		DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden),
		Description("Gets the current HTML document")
		]
		public mshtml.IHTMLDocument2 CurrentDocument
		{
			get
			{
				try
				{
					mshtml.IHTMLDocument2 htm = (mshtml.IHTMLDocument2) this.axWebBrowser.Document;
					return htm;
				}
				catch
				{
					return null;
				}
			}
		}

		/// <summary>
		/// Gets or set the Context menu for the document.
		/// </summary>
		[
		Browsable(true),
		Description("Gets or set the ContextMenu. If this is null, the default IE context menu is used.")
		] 
		public override ContextMenu ContextMenu
		{
			get
			{
				return this._contextMenu;
			}
			set
			{
				this._contextMenu = value;
			}
		}

		/// <summary>
		/// Gets or set whether HTML document events are fired.
		/// </summary>
		[
		Browsable(true),
		Description("Gets or set whether HTML document events are fired.")
		]
		public bool EnableHtmlDocumentEventHandling
		{
			get
			{
				return this._enableHtmlDocumentEventHandling;
			}
			set
			{
				this._enableHtmlDocumentEventHandling = value;
			}
		}

		/// <summary>
		/// Gets or sets whether a 3D border is drawn for the web browser control. Changes to
		/// this property will not be reflected at design time.
		/// </summary>
		[
		Browsable(true),
		Description("Gets or sets whether a 3D border is drawn for the web browser control. Changes to this property will not be reflected at design time.")
		]
		public bool Border3D
		{
			get
			{
				return this._border3D;
			}
			set
			{
				this._border3D = value;

				// NB reverse order as the constant is a negative
				this.SetDocHostUiFlag(DOCHOSTUIFLAG.DOCHOSTUIFLAG_NO3DBORDER,!value);
			}
		}

		/// <summary>
		/// Gets or sets whether vertical and horizontal scrollbars display for the web browser control. Setting this to true
		/// will mean that scrollbars appear only when the HTML content does not fit the screen - the scrollbars are not forced.Changes to
		/// this property will not be reflected at design time.
		/// </summary>
		[
		Browsable(true),
		Description("Gets or sets whether vertical and horizontal scrollbars display for the web browser control. Setting this to true will mean that scrollbars appear only when the HTML content does not fit the screen - the scrollbars are not forced. Changes to this property will not be reflected at design time.")
		]
		public bool ScrollBarsVisible
		{
			get
			{
				return this._scrollBarsVisible;
			}
			set
			{
				this._scrollBarsVisible = value;

				// NB reverse order as the constant is a negative
				this.SetDocHostUiFlag(DOCHOSTUIFLAG.DOCHOSTUIFLAG_SCROLL_NO,!value);
			}
		}

		/// <summary>
		/// Gets or sets whether the form elements on a HTML page have the XP themed look (rounded buttons etc.)
		/// </summary>
		[
		Browsable(true),
		Description("Gets or sets whether the form elements on a HTML page have the XP themed look (rounded buttons etc.)")
		]
		public bool XPThemed
		{
			get
			{
				return this._xpThemed;
			}
			set
			{
				this._xpThemed = value;
				this.SetDocHostUiFlag(DOCHOSTUIFLAG.DOCHOSTUIFLAG_THEME,value);
			}
		}

		/// <summary>
		/// Gets or sets whether the scrollbar has a flat appearance.
		/// </summary>
		[
		Browsable(true),
		Description("Gets or sets whether the scrollbar has a flat appearance.")
		]
		public bool FlatScrollBar
		{
			get
			{
				return this._flatScrollBar;
			}
			set
			{
				this._flatScrollBar = value;
				this.SetDocHostUiFlag(DOCHOSTUIFLAG.DOCHOSTUIFLAG_FLAT_SCROLLBAR,value);
			}
		}

		/// <summary>
		/// 
		/// </summary>
		[
		Browsable(true),
		Description("")
		]
		public bool OpenInNewWindow
		{
			get
			{
				return this._openInNewWindow;
			}
			set
			{
				this._openInNewWindow = value;
			}
		}

		/// <summary>
		/// Gets or set the Options.
		/// </summary>
		[
		Browsable(true),
		Description("Gets or set the Options."),
		Editor( typeof(FlagsEditor), typeof(System.Drawing.Design.UITypeEditor) )
		]
		public BrowserOptions Options
		{
			get
			{
				return this._options;
			}
			set
			{
				this._options = value;
			}
		}

		/// <summary>
		/// Gets or set the Url.
		/// </summary>
		[
		Browsable(true),
		Description("Gets or set the Url.")
		]
		public string Url
		{
			get
			{
				return this._url;
			}
			set
			{
				this._url = value;

				if ( !this.DesignMode || this.DesignMode && ShowWebsiteInDesigner )
				{
					try 
					{
						Cursor.Current = Cursors.WaitCursor;

						if ( value == "" )
							value = "about:blank";

						this.Navigate(value);
					} 
					finally 
					{
						Cursor.Current = Cursors.Default;
					}
				}
			}
		}

		/// <summary>
		/// Determines whether the browser is visible or hidden.
		/// </summary>
		[
		Browsable(true),
		Description("Determines whether the browser is visible or hidden.")
		]
		public new bool Visible
		{
			get
			{
				return this.axWebBrowser.Visible;
			}
			set
			{
				this.axWebBrowser.Visible = value;
			}
		}

		/// <summary>
		/// Gets or the sets the ShowWebsiteInDesigner
		/// </summary>
		public bool ShowWebsiteInDesigner
		{
			get
			{
				return _showWebsiteInDesigner;
			}
			set
			{
				if ( value != _showWebsiteInDesigner )
				{
					_showWebsiteInDesigner = value;

					if ( !value )
					{
						// Once the url is set, it stills displays as a browser, not sure how to
						// set it back to its original state pre-url?
						object o = null;
						object n = "";
						this.axWebBrowser.Navigate2(ref n,ref o,ref o,ref o,ref o);
					}
					else
					{
						// Go get it
						this.Navigate(this.Url);
					}
				}
			}
		}

		/// <summary>
		/// Retrieves the name of the resource that Microsoft Internet Explorer is currently displaying.
		/// </summary>
		/// <remarks>
		/// If the resource is an HTML page on the World Wide Web, the name is the title of that page. If the resource is a 
		/// folder or file on the network or local computer, the name is the full path of the folder or file in 
		/// Universal Naming Convention (UNC) format.
		/// </remarks>
		[
		Browsable(false),
		DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden),
		]
		public string PageTitle
		{
			get
			{
				return this.axWebBrowser.LocationName;
			}
		}

		/// <summary>
		/// Whether to disable the CTRL+N keystroke in the browser, disabling the shortcut
		/// for a new window.
		/// </summary>
		[
		Browsable(true),
		Description("Whether to disable the CTRL+N keystroke in the browser, disabling the shortcut for a new window.")
		]
		public bool DisableCtrlN
		{
			get
			{
				return this._disableCtrlN;
			}
			set
			{
				this._disableCtrlN = value;
			}
		}

		/// <summary>
		/// Disables the backspace key (for navigation backwards).
		/// This is typically used when the browser displays text only, and no form data (as
		/// the backspace key will be unavailable for forms).
		/// </summary>
		/// <remarks>
		/// Navigating is still possible using the ALT+Left and ALT+Right keys, and the 
		/// 4th and 5th buttons on browser-enabled mice.
		/// </remarks>
		[
		Browsable(true),
		Description("Disables the navigation keys (backspace, ALT + Left, ALT + Right).")
		]
		public bool DisableBackSpace
		{
			get
			{
				return this._disableBackSpace;
			}
			set
			{
				this._disableBackSpace = value;
			}
		}

		/// <summary>
		/// Disables or enables the CTRL+P key combination, allowing or disallowing the shortcut key
		/// for printing in the browser.
		/// </summary>
		/// <remarks>
		/// 
		/// </remarks>
		[
		Browsable(true),
		Description("Disables or enables the CTRL+P key combination, allowing or disallowing the shortcut key for printing in the browser.")
		]
		public bool DisableCtrlP
		{
			get
			{
				return this._disableCtrlP;
			}
			set
			{
				this._disableCtrlP = value;
			}
		}

		/// <summary>
		/// Disables the CTRL+F shortcut, which displays the find dialog box.
		/// </summary>
		[
		Browsable(true),
		Description("Disables the CTRL+F shortcut, which displays the find dialog box.")
		]
		public bool DisableCtrlF
		{
			get
			{
				return this._disableCtrlF;
			}
			set
			{
				this._disableCtrlF = value;
			}
		}

		/// <summary>
		/// Disables the CTRL+O shortcut key, restricting the user from using the Open dialog.
		/// </summary>
		[
		Browsable(false),
		DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden),
		Description("Disables the CTRL+O shortcut key, restricting the user from using the Open dialog.")
		]
		public bool DisableCtrlO
		{
			get
			{
				return this._disableCtrlO;
			}
			set
			{
				this._disableCtrlO = value;
			}
		}
		#endregion

		#region Properties inherited from Control which are now hidden
		// These are hidden as they're misleading - setting them will not alter the browser
		// (e.g. setting the font)

		/// <summary>
		/// 
		/// </summary>
		[
		Browsable(false),
		]
		public new bool AllowDrop
		{
			get
			{
				return base.AllowDrop;
			}
			set
			{
				base.AllowDrop = value;
			}
		}

		/// <summary>
		/// 
		/// </summary>
		[
		Browsable(false),
		]
		public new Color BackColor
		{
			get
			{
				return base.BackColor;
			}
			set
			{
				base.BackColor = value;
			}
		}

		/// <summary>
		/// 
		/// </summary>
		[
		Browsable(false),
		]
		public new Image BackgroundImage
		{
			get
			{
				return base.BackgroundImage;
			}
			set
			{
				base.BackgroundImage = value;
			}
		}

		/// <summary>
		/// 
		/// </summary>
		[
		Browsable(false),
		]
		public new Cursor Cursor
		{
			get
			{
				return base.Cursor;
			}
			set
			{
				base.Cursor = value;
			}
		}

		/// <summary>
		/// 
		/// </summary>
		[
		Browsable(false),
		]
		public new bool Enabled
		{
			get
			{
				return base.Enabled;
			}
			set
			{
				base.Enabled = value;
			}
		}

		/// <summary>
		/// 
		/// </summary>
		[
		Browsable(false),
		]
		public new Font Font
		{
			get
			{
				return null;
			}
		}

		/// <summary>
		/// 
		/// </summary>
		[
		Browsable(false),
		]
		public new Color ForeColor
		{
			get
			{
				return Color.White;
			}
		}
		#endregion

		#region Exposed properties of AxWebBrowser
		/// <summary>
		/// Sets or retrieves whether the address bar of the visible or hidden. This will typically
		/// be used in conjunction with new windows being launched.
		/// </summary>
		[
		Browsable(true),
		Description("Sets or retrieves whether the address bar of is visible or hidden.")
		]
		public bool AddressBar
		{
			get
			{
				return this.axWebBrowser.AddressBar;
			}
			set
			{
				this.axWebBrowser.AddressBar = value;
			}
		}
	
		/// <summary>
		/// Gets or set the FullScreen.
		/// </summary>
		[
		Browsable(true),
		Description("Gets or set the FullScreen.")
		]
		public bool FullScreen
		{
			get
			{
				return this.axWebBrowser.FullScreen;
			}
			set
			{
				axWebBrowser.FullScreen = value;
			}
		}
	
		/// <summary>
		/// Gets or set the TheaterMode.
		/// </summary>
		[
		Browsable(true),
		Description("Gets or set the TheaterMode.")
		]
		public bool TheaterMode
		{
			get
			{
				return this.axWebBrowser.TheaterMode;
			}
			set
			{
				this.axWebBrowser.TheaterMode= value;
			}
		}
	
		/// <summary>
		/// Gets or set the Offline.
		/// </summary>
		[
		Browsable(true),
		Description("Gets or set the Offline.")
		]
		public bool Offline
		{
			get
			{
				return this.axWebBrowser.Offline;
			}
			set
			{
				this.axWebBrowser.Offline = value;
			}
		}
	
		/// <summary>
		/// Gets or set the RegisterAsBrowser.
		/// </summary>
		[
		Browsable(true),
		Description("Gets or set the RegisterAsBrowser.")
		]
		public bool RegisterAsBrowser
		{
			get
			{
				return this.axWebBrowser.RegisterAsBrowser;
			}
			set
			{
				this.axWebBrowser.RegisterAsBrowser = value;
			}
		}
	
		/// <summary>
		/// Gets or set the RegisterAsDropTarget.
		/// </summary>
		[
		Browsable(true),
		Description("Gets or set the RegisterAsDropTarget.")
		]
		public bool RegisterAsDropTarget
		{
			get
			{
				return this.axWebBrowser.RegisterAsDropTarget;
			}
			set
			{
				this.axWebBrowser.RegisterAsDropTarget = value;
			}
		}

		/// <summary>
		/// Gets or set the Silent.
		/// </summary>
		[
		Browsable(true),
		Description("Gets or set the Silent.")
		]
		public bool Silent
		{
			get
			{
				return this.axWebBrowser.Silent;
			}
			set
			{
				this.axWebBrowser.Silent = value;
			}
		}
		#endregion

		#region Private fields

		// Supporting the properties
		private bool _enableHtmlDocumentEventHandling;
		private ContextMenu _contextMenu;		
		private bool _border3D = false;
		private bool _scrollBarsVisible = false;
		private bool _flatScrollBar = false;
		private bool _xpThemed = false;
		private bool _openInNewWindow = false;
		private string _url;
		private BrowserOptions _options;
		private bool _showWebsiteInDesigner = false;

		private bool _disableCtrlO;
		private bool _disableCtrlF;
		private bool _disableCtrlP;
		private bool _disableBackSpace;
		private bool _disableCtrlN;

		// Others
		private bool _linkClicked = false; // stops stack overflow with OpenInNewWindow
		private DOCHOSTUIFLAG _flags;
		private Guid cmdGuid = new Guid("ED016940-BD5B-11CF-BA4E-00C04FD70816"); // used for search dialog/inet options
		private const int S_OK = 0;
		private const int S_FALSE = 1;

		/// <summary>
		/// The Active-X browser control that WebBrowserEx uses and configures.
		/// </summary>
		protected AxSHDocVw.AxWebBrowser axWebBrowser;
		#endregion

		#region Events from AxBrowser
		/// <summary>
		/// Fires before navigation occurs in the given object (on either a window or frameset element).
		/// </summary>
		/// <remarks>
		/// More information can be found <see href="http://msdn.microsoft.com/library/default.asp?url=/workshop/browser/webbrowser/reference/events/beforenavigate.asp">here</see>
		/// </remarks>
		[
		Browsable(true),
		Description("Fires before navigation occurs in the given object (on either a window or frameset element).")
		]
		public event AxSHDocVw.DWebBrowserEvents2_BeforeNavigate2EventHandler BeforeNavigate;

		/// <summary>
		/// Fires when a document has been completely loaded and initialized.
		/// </summary>
		/// <remarks>
		/// More information can be found <see href="http://msdn.microsoft.com/library/default.asp?url=/workshop/browser/webbrowser/reference/events/documentcomplete.asp">here</see>
		/// </remarks>
		[
		Browsable(true),
		Description("Fires when a document has been completely loaded and initialized.")
		]
		public event AxSHDocVw.DWebBrowserEvents2_DocumentCompleteEventHandler DocumentComplete;

		/// <summary>
		/// Fires when a navigation operation is beginning.
		/// </summary>
		/// <remarks>
		/// More information can be found <see href="http://msdn.microsoft.com/library/default.asp?url=/workshop/browser/webbrowser/reference/events/downloadbegin.asp">here</see>
		/// </remarks>
		[
		Browsable(true),
		Description("Fires when a navigation operation is beginning.")
		]
		public event EventHandler DownloadBegin;

		/// <summary>
		/// Fires when a navigation operation finishes, is halted, or fails.
		/// </summary>
		/// <remarks>
		/// More information can be found <see href="http://msdn.microsoft.com/library/default.asp?url=/workshop/browser/webbrowser/reference/events/downloadcomplete.asp">here</see>
		/// </remarks>
		[
		Browsable(true),
		Description("Fires when a navigation operation finishes, is halted, or fails.")
		]
		public event EventHandler DownloadComplete;

		/// <summary>
		/// Fires to indicate that a file download is about to occur. If a file download dialog is to be displayed, this event is fired prior to the display of the dialog.
		/// </summary>
		/// <remarks>
		/// More information can be found <see href="http://msdn.microsoft.com/library/default.asp?url=/workshop/browser/webbrowser/reference/events/filedownload.asp">here</see>
		/// </remarks>
		[
		Browsable(true),
		Description("Fires to indicate that a file download is about to occur. If a file download dialog is to be displayed, this event is fired prior to the display of the dialog.")
		]
		public event AxSHDocVw.DWebBrowserEvents2_FileDownloadEventHandler FileDownload;

		/// <summary>
		/// Fires after a navigation to a link is completed on either a window or frameSet element.
		/// </summary>
		/// <remarks>
		/// More information can be found <see href="http://msdn.microsoft.com/library/default.asp?url=/workshop/browser/webbrowser/reference/events/navigatecomplete2.asp">here</see>
		/// </remarks>
		[
		Browsable(true),
		Description("Fires after a navigation to a link is completed on either a window or frameSet element.")
		]
		public event AxSHDocVw.DWebBrowserEvents2_NavigateComplete2EventHandler NavigateComplete;

		/// <summary>
		/// Fires when an error occurs during navigation.
		/// </summary>
		/// <remarks>
		/// More information can be found <see href="http://msdn.microsoft.com/library/default.asp?url=/workshop/browser/webbrowser/reference/events/navigateerror.asp">here</see>
		/// </remarks>
		[
		Browsable(true),
		Description("Fires when an error occurs during navigation.")
		]
		public event AxSHDocVw.DWebBrowserEvents2_NavigateErrorEventHandler NavigateError;

		/// <summary>
		/// Fires when a new window is to be created.
		/// </summary>
		/// <remarks>
		/// More information can be found <see href="http://msdn.microsoft.com/library/default.asp?url=/workshop/browser/webbrowser/reference/events/newwindow2.asp">here</see>
		/// </remarks>
		[
		Browsable(true),
		Description("Fires when a new window is to be created.")
		]
		public event AxSHDocVw.DWebBrowserEvents2_NewWindow2EventHandler NewWindow;

		/// <summary>
		/// Fires when the FullScreen property is changed.
		/// </summary>
		/// <remarks>
		/// More information can be found <see href="http://msdn.microsoft.com/library/default.asp?url=/workshop/browser/webbrowser/reference/events/onfullscreen.asp">here</see>
		/// </remarks>
		[
		Browsable(true),
		Description("Fires when the FullScreen property is changed.")
		]
		public event AxSHDocVw.DWebBrowserEvents2_OnFullScreenEventHandler FullScreenChanged;

		/// <summary>
		/// Fires when the MenuBar property is changed.
		/// </summary>
		/// <remarks>
		/// More information can be found <see href="http://msdn.microsoft.com/library/default.asp?url=/workshop/browser/webbrowser/reference/events/onmenubar.asp">here</see>
		/// </remarks>
		[
		Browsable(true),
		Description("Fires when the MenuBar property is changed.")
		]
		public event AxSHDocVw.DWebBrowserEvents2_OnMenuBarEventHandler MenuBarChanged;

		/// <summary>
		/// Fires before the Microsoft Internet Explorer application quits.
		/// </summary>
		/// <remarks>
		/// More information can be found <see href="http://msdn.microsoft.com/library/default.asp?url=/workshop/browser/webbrowser/reference/events/onquit.asp">here</see>
		/// </remarks>
		[
		Browsable(true),
		Description("Fires before the Microsoft Internet Explorer application quits.")
		]
		public event EventHandler Quit;

		/// <summary>
		/// Fires when the StatusBar property is changed.
		/// </summary>
		/// <remarks>
		/// More information can be found <see href="http://msdn.microsoft.com/library/default.asp?url=/workshop/browser/webbrowser/reference/events/onstatusbar.asp">here</see>
		/// </remarks>
		[
		Browsable(true),
		Description("Fires when the StatusBar property is changed.")
		]
		public event AxSHDocVw.DWebBrowserEvents2_OnStatusBarEventHandler StatusBarChanged;

		/// <summary>
		/// Fires when the TheaterMode property is changed.
		/// </summary>
		/// <remarks>
		/// More information can be found <see href="http://msdn.microsoft.com/library/default.asp?url=/workshop/browser/webbrowser/reference/events/ontheatermode.asp">here</see>
		/// </remarks>
		[
		Browsable(true),
		Description("Fires when the TheaterMode property is changed.")
		]
		public event AxSHDocVw.DWebBrowserEvents2_OnTheaterModeEventHandler TheaterModeChanged;

		/// <summary>
		/// Fires when the ToolBar property is changed.
		/// </summary>
		/// <remarks>
		/// More information can be found <see href="http://msdn.microsoft.com/library/default.asp?url=/workshop/browser/webbrowser/reference/events/ontoolbar.asp">here</see>
		/// </remarks>
		[
		Browsable(true),
		Description("Fires when the ToolBar property is changed.")
		]
		public event AxSHDocVw.DWebBrowserEvents2_OnToolBarEventHandler ToolBarChanged;

		/// <summary>
		/// Fires when a print template has been instantiated.
		/// </summary>
		/// <remarks>
		/// More information can be found <see href="http://msdn.microsoft.com/workshop/browser/webbrowser/reference/events/printtemplateinstantiation.asp">here</see>
		/// </remarks>
		[
		Browsable(true),
		Description("Fires when a print template has been instantiated.")
		]
		public event AxSHDocVw.DWebBrowserEvents2_PrintTemplateInstantiationEventHandler PrintTemplateInstantiation;

		/// <summary>
		/// Fires when a print template has been destroyed.
		/// </summary>
		/// <remarks>
		/// More information can be found <see href="http://msdn.microsoft.com/workshop/browser/webbrowser/reference/events/printtemplateteardown.asp">here</see>
		/// </remarks>
		[
		Browsable(true),
		Description("Fires when a print template has been destroyed.")
		]
		public event AxSHDocVw.DWebBrowserEvents2_PrintTemplateTeardownEventHandler PrintTemplateTeardown;

		/// <summary>
		/// Fired when an event occurs that impacts privacy or when a user navigates away from a URL that has impacted privacy.
		/// </summary>
		/// <remarks>
		/// More information can be found <see href="http://msdn.microsoft.com/workshop/browser/webbrowser/reference/events/privacyimpactedstatechange.asp">here</see>
		/// </remarks>
		[
		Browsable(true),
		Description("Fired when an event occurs that impacts privacy or when a user navigates away from a URL that has impacted privacy.")
		]
		public event AxSHDocVw.DWebBrowserEvents2_PrivacyImpactedStateChangeEventHandler PrivacyImpactedStateChange;

		/// <summary>
		/// Fires when the progress of a download operation is updated on the object. 
		/// </summary>
		/// <remarks>
		/// More information can be found <see href="http://msdn.microsoft.com/library/default.asp?url=/workshop/browser/webbrowser/reference/events/progresschange.asp">here</see>
		/// </remarks>
		[
		Browsable(true),
		Description("Fires when the progress of a download operation is updated on the object. ")
		]
		public event AxSHDocVw.DWebBrowserEvents2_ProgressChangeEventHandler ProgressChange;

		/// <summary>
		/// Fires when the PutProperty method of the object changes the value of a property.
		/// </summary>
		/// <remarks>
		/// More information can be found <see href="http://msdn.microsoft.com/workshop/browser/webbrowser/reference/events/propertychange.asp">here</see>
		/// </remarks>
		[
		Browsable(true),
		Description("Fires when the PutProperty method of the object changes the value of a property.")
		]
		public event AxSHDocVw.DWebBrowserEvents2_PropertyChangeEventHandler PropertyChange;

		/// <summary>
		/// Fires when there is a change in encryption level.
		/// </summary>
		/// <remarks>
		/// More information can be found <see href="http://msdn.microsoft.com/library/default.asp?url=/workshop/browser/webbrowser/reference/events/setsecurelockicon.asp">here</see>
		/// </remarks>
		[
		Browsable(true),
		Description("Fires when there is a change in encryption level.")
		]
		public event AxSHDocVw.DWebBrowserEvents2_SetSecureLockIconEventHandler SetSecureLockIcon;

		/// <summary>
		/// Fires when the status bar text of the object has changed.
		/// </summary>
		/// <remarks>
		/// More information can be found <see href="http://msdn.microsoft.com/workshop/browser/webbrowser/reference/events/statustextchange.asp">here</see>
		/// </remarks>
		[
		Browsable(true),
		Description("Fires when the status bar text of the object has changed.")
		]
		public event AxSHDocVw.DWebBrowserEvents2_StatusTextChangeEventHandler StatusTextChange;

		/// <summary>
		/// Fires when the title of a document in the object becomes available or changes.
		/// </summary>
		/// <remarks>
		/// More information can be found <see href="http://msdn.microsoft.com/library/default.asp?url=/workshop/browser/webbrowser/reference/events/titlechange.asp">here</see>
		/// </remarks>
		[
		Browsable(true),
		Description("Fires when the title of a document in the object becomes available or changes.")
		]
		public event AxSHDocVw.DWebBrowserEvents2_TitleChangeEventHandler TitleChanged;

		/// <summary>
		/// Not currently implemented.
		/// </summary>
		/// <remarks>
		/// More information can be found <see href="http://msdn.microsoft.com/workshop/browser/webbrowser/reference/events/updatepagestatus.asp">here</see>
		/// </remarks>
		[
		Browsable(true),
		Description("Not currently implemented.")
		]
		public event AxSHDocVw.DWebBrowserEvents2_UpdatePageStatusEventHandler UpdatePageStatus;

		/// <summary>
		/// Fires when the window of the object is about to be closed by script.
		/// </summary>
		/// <remarks>
		/// More information can be found <see href="http://msdn.microsoft.com/workshop/browser/webbrowser/reference/events/windowclosing.asp">here</see>
		/// </remarks>
		[
		Browsable(true),
		Description("Fires when the window of the object is about to be closed by script.")
		]
		public event AxSHDocVw.DWebBrowserEvents2_WindowClosingEventHandler WindowClosing;

		/// <summary>
		/// Fires when the object changes its height.
		/// </summary>
		/// <remarks>
		/// More information can be found <see href="http://msdn.microsoft.com/library/default.asp?url=/workshop/browser/webbrowser/reference/events/windowsetheight.asp">here</see>
		/// </remarks>
		[
		Browsable(true),
		Description("Fires when the object changes its height.")
		]
		public event AxSHDocVw.DWebBrowserEvents2_WindowSetHeightEventHandler WindowSetHeight;

		/// <summary>
		/// Fires when the object changes its left position.
		/// </summary>
		/// <remarks>
		/// More information can be found <see href="http://msdn.microsoft.com/library/default.asp?url=/workshop/browser/webbrowser/reference/events/windowsetleft.asp">here</see>
		/// </remarks>
		[
		Browsable(true),
		Description("Fires when the object changes its left position.")
		]
		public event AxSHDocVw.DWebBrowserEvents2_WindowSetLeftEventHandler WindowSetLeft;

		/// <summary>
		/// Fires to indicate whether the host window should allow or disallow resizing of the object.
		/// </summary>
		/// <remarks>
		/// More information can be found <see href="http://msdn.microsoft.com/workshop/browser/webbrowser/reference/events/windowsetresizable.asp">here</see>
		/// </remarks>
		[
		Browsable(true),
		Description("Fires to indicate whether the host window should allow or disallow resizing of the object.")
		]
		public event AxSHDocVw.DWebBrowserEvents2_WindowSetResizableEventHandler WindowSetResizable;

		/// <summary>
		/// Fires when the object changes its top position.
		/// </summary>
		/// <remarks>
		/// More information can be found <see href="http://msdn.microsoft.com/workshop/browser/webbrowser/reference/events/windowsettop.asp">here</see>
		/// </remarks>
		[
		Browsable(true),
		Description("Fires when the object changes its top position.")
		]
		public event AxSHDocVw.DWebBrowserEvents2_WindowSetTopEventHandler WindowSetTop;

		/// <summary>
		/// Fires when the object changes its width.
		/// </summary>
		/// <remarks>
		/// More information can be found <see href="http://msdn.microsoft.com/workshop/browser/webbrowser/reference/events/windowsetwidth.asp">here</see>
		/// </remarks>
		[
		Browsable(true),
		Description("Fires when the object changes its width.")
		]
		public event AxSHDocVw.DWebBrowserEvents2_WindowSetWidthEventHandler WindowSetWidth;
		#endregion

		#region Html Document Events
		/// <summary>
		/// Occurs when a mouse button is clicked inside the HTML document.
		/// </summary>
		[Browsable(true)]
		public event WebBrowserExEventHandler HtmlDocumentClick;
	
		/// <summary>
		/// Occurs when a mouse button is clicked twice in succession inside the HTML document.
		/// </summary>
		[Browsable(true)]
		public event WebBrowserExEventHandler HtmlDocumentDoubleClick;
	
		/// <summary>
		/// Occurs when a key is pressed inside the HTML document.
		/// </summary>
		[Browsable(true)]
		public event WebBrowserExKeyEventHandler HtmlDocumentKeyDown;
	
		/// <summary>
		/// Occurs when a key is pressed inside the HTML document.
		/// </summary>
		[Browsable(true)]
		public event WebBrowserExKeyEventHandler HtmlDocumentKeyPress;
	
		/// <summary>
		/// Occurs when a key is released a key inside the HTML document.
		/// </summary>
		[Browsable(true)]
		public event WebBrowserExKeyEventHandler HtmlDocumentKeyUp;
	
		/// <summary>
		/// Occurs when the mouse pointer is over the HTML document and a mouse button is pressed.
		/// </summary>
		[Browsable(true)]
		public event WebBrowserExMouseEventHandler HtmlDocumentMouseDown;
	
		/// <summary>
		/// Occurs when the mouse pointer is moved inside the HTML document.
		/// </summary>
		[Browsable(true)]
		public event WebBrowserExMouseEventHandler HtmlDocumentMouseMove;
	
		/// <summary>
		/// Occurs when the user moves the mouse pointer out of the HTML document.
		/// </summary>
		[Browsable(true)]
		public event WebBrowserExMouseEventHandler HtmlDocumentMouseOut;
	
		/// <summary>
		/// Occurs when the user moves the mouse pointer into the HTML document.
		/// </summary>
		[Browsable(true)]
		public event WebBrowserExMouseEventHandler HtmlDocumentMouseOver;
	
		/// <summary>
		/// Occurs when the mouse pointer is over the HTML document and a mouse button is released.
		/// </summary>
		[Browsable(true)]
		public event WebBrowserExMouseEventHandler HtmlDocumentMouseUp;
		#endregion

		#region Components

		private System.ComponentModel.Container components = null;
		#endregion

		#region Constructor / dispose
		/// <summary>
		/// Creates a new instance WebBrowserEx.
		/// </summary>
		public WebBrowserEx()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();
			this._flags = 0;
			this._options = BrowserOptions.Images;
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}
		#endregion

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(WebBrowserEx));
			this.axWebBrowser = new AxSHDocVw.AxWebBrowser();
			((System.ComponentModel.ISupportInitialize)(this.axWebBrowser)).BeginInit();
			this.SuspendLayout();
			// 
			// axWebBrowser
			// 
			this.axWebBrowser.Dock = System.Windows.Forms.DockStyle.Fill;
			this.axWebBrowser.Enabled = true;
			this.axWebBrowser.Location = new System.Drawing.Point(0, 0);
			this.axWebBrowser.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axWebBrowser.OcxState")));
			this.axWebBrowser.Size = new System.Drawing.Size(150, 150);
			this.axWebBrowser.TabIndex = 0;
			this.axWebBrowser.OnTheaterMode += new AxSHDocVw.DWebBrowserEvents2_OnTheaterModeEventHandler(this.axWebBrowser_OnTheaterMode);
			this.axWebBrowser.StatusTextChange += new AxSHDocVw.DWebBrowserEvents2_StatusTextChangeEventHandler(this.axWebBrowser_StatusTextChange);
			this.axWebBrowser.PropertyChange += new AxSHDocVw.DWebBrowserEvents2_PropertyChangeEventHandler(this.axWebBrowser_PropertyChange);
			this.axWebBrowser.UpdatePageStatus += new AxSHDocVw.DWebBrowserEvents2_UpdatePageStatusEventHandler(this.axWebBrowser_UpdatePageStatus);
			this.axWebBrowser.WindowSetLeft += new AxSHDocVw.DWebBrowserEvents2_WindowSetLeftEventHandler(this.axWebBrowser_WindowSetLeft);
			this.axWebBrowser.WindowClosing += new AxSHDocVw.DWebBrowserEvents2_WindowClosingEventHandler(this.axWebBrowser_WindowClosing);
			this.axWebBrowser.SetSecureLockIcon += new AxSHDocVw.DWebBrowserEvents2_SetSecureLockIconEventHandler(this.axWebBrowser_SetSecureLockIcon);
			this.axWebBrowser.NavigateError += new AxSHDocVw.DWebBrowserEvents2_NavigateErrorEventHandler(this.axWebBrowser_NavigateError);
			this.axWebBrowser.WindowSetWidth += new AxSHDocVw.DWebBrowserEvents2_WindowSetWidthEventHandler(this.axWebBrowser_WindowSetWidth);
			this.axWebBrowser.OnFullScreen += new AxSHDocVw.DWebBrowserEvents2_OnFullScreenEventHandler(this.axWebBrowser_OnFullScreen);
			this.axWebBrowser.WindowSetTop += new AxSHDocVw.DWebBrowserEvents2_WindowSetTopEventHandler(this.axWebBrowser_WindowSetTop);
			this.axWebBrowser.OnQuit += new System.EventHandler(this.axWebBrowser_OnQuit);
			this.axWebBrowser.DownloadBegin += new System.EventHandler(this.axWebBrowser_DownloadBegin);
			this.axWebBrowser.WindowSetHeight += new AxSHDocVw.DWebBrowserEvents2_WindowSetHeightEventHandler(this.axWebBrowser_WindowSetHeight);
			this.axWebBrowser.WindowSetResizable += new AxSHDocVw.DWebBrowserEvents2_WindowSetResizableEventHandler(this.axWebBrowser_WindowSetResizable);
			this.axWebBrowser.PrivacyImpactedStateChange += new AxSHDocVw.DWebBrowserEvents2_PrivacyImpactedStateChangeEventHandler(this.axWebBrowser_PrivacyImpactedStateChange);
			this.axWebBrowser.OnToolBar += new AxSHDocVw.DWebBrowserEvents2_OnToolBarEventHandler(this.axWebBrowser_OnToolBar);
			this.axWebBrowser.OnStatusBar += new AxSHDocVw.DWebBrowserEvents2_OnStatusBarEventHandler(this.axWebBrowser_OnStatusBar);
			this.axWebBrowser.DownloadComplete += new System.EventHandler(this.axWebBrowser_DownloadComplete);
			this.axWebBrowser.TitleChange += new AxSHDocVw.DWebBrowserEvents2_TitleChangeEventHandler(this.axWebBrowser_TitleChange);
			this.axWebBrowser.NavigateComplete2 += new AxSHDocVw.DWebBrowserEvents2_NavigateComplete2EventHandler(this.axWebBrowser_NavigateComplete2);
			this.axWebBrowser.DocumentComplete += new AxSHDocVw.DWebBrowserEvents2_DocumentCompleteEventHandler(this.axWebBrowser1_DocumentComplete);
			this.axWebBrowser.ProgressChange += new AxSHDocVw.DWebBrowserEvents2_ProgressChangeEventHandler(this.axWebBrowser_ProgressChange);
			this.axWebBrowser.NewWindow2 += new AxSHDocVw.DWebBrowserEvents2_NewWindow2EventHandler(this.axWebBrowser1_NewWindow2);
			this.axWebBrowser.OnMenuBar += new AxSHDocVw.DWebBrowserEvents2_OnMenuBarEventHandler(this.axWebBrowser_OnMenuBar);
			this.axWebBrowser.PrintTemplateInstantiation += new AxSHDocVw.DWebBrowserEvents2_PrintTemplateInstantiationEventHandler(this.axWebBrowser_PrintTemplateInstantiation);
			this.axWebBrowser.BeforeNavigate2 += new AxSHDocVw.DWebBrowserEvents2_BeforeNavigate2EventHandler(this.axWebBrowser1_BeforeNavigate2);
			this.axWebBrowser.FileDownload += new AxSHDocVw.DWebBrowserEvents2_FileDownloadEventHandler(this.axWebBrowser_FileDownload);
			this.axWebBrowser.PrintTemplateTeardown += new AxSHDocVw.DWebBrowserEvents2_PrintTemplateTeardownEventHandler(this.axWebBrowser_PrintTemplateTeardown);
			// 
			// WebBrowserEx
			// 
			this.Controls.Add(this.axWebBrowser);
			this.Name = "WebBrowserEx";
			this.Load += new System.EventHandler(this.WebBrowserEx_Load);
			((System.ComponentModel.ISupportInitialize)(this.axWebBrowser)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		#region Navigate + overloads
		/// <summary>
		/// 
		/// </summary>
		/// <param name="url"></param>
		public void Navigate(string url)
		{
			this.Navigate(url,NavigateOptions.None,null,null,null);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="url"></param>
		/// <param name="options"></param>
		public void Navigate(string url,NavigateOptions options)
		{
			this.Navigate(url,options,null,null,null);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="url"></param>
		/// <param name="options"></param>
		/// <param name="targetFrame"></param>
		public void Navigate(string url,NavigateOptions options,string targetFrame)
		{
			this.Navigate(url,options,targetFrame,null,null);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="url"></param>
		/// <param name="options"></param>
		/// <param name="targetFrame"></param>
		/// <param name="postData"></param>
		/// <param name="headers"></param>
		public void Navigate(string url,NavigateOptions options,string targetFrame,string postData,string headers)
		{
			try 
			{
				if ( url == null || url == "" )
					return;

				this._linkClicked = false;
				Cursor.Current = Cursors.WaitCursor;

				object urlObj = url;
				object optionsObj = null;
			
				if ( (int) options > 0 )
					optionsObj = (int) options;

				object targetFrameObj = targetFrame;
				object postDataObj = postData;
				object headersObj = headers;

				this.axWebBrowser.Navigate2(ref urlObj,ref optionsObj,ref targetFrameObj,ref postDataObj,ref headersObj);
			} 
			finally 
			{
				Cursor.Current = Cursors.Default;
			}
		}
		#endregion

		#region Public methods
		/// <summary>
		/// Refreshes the currently loaded document.
		/// </summary>
		/// <param name="refreshType">The <see ref="RefreshType">RefreshType</see> for refreshing the document.</param>
		public void Refresh(RefreshType refreshType)
		{
			object val = (int) refreshType;
			this.axWebBrowser.Refresh2(ref val);
		}

		/// <summary>
		/// Stops any operation the browser is currently performing.
		/// </summary>
		public void Stop()
		{
			this.axWebBrowser.Stop();
		}

		/// <summary>
		/// Saves the document (requiring a previous SaveAs operation) to its current filename.
		/// </summary>
		public void Save()
		{
			this.ExecWB(SHDocVw.OLECMDID.OLECMDID_SAVE);
		}

		/// <summary>
		/// Displays the SaveAs dialog, with the filename specified in the textbox. Due to security restrictions,
		/// you can't do a SaveAs without a dialog box, even on low security settings.
		/// </summary>
		public void SaveAs()
		{
			this.ExecWB(SHDocVw.OLECMDID.OLECMDID_SAVEAS);
		}

		/// <summary>
		/// Displays the SaveAs dialog, with the filename specified in the textbox. Due to security restrictions,
		/// you can't do a SaveAs without a dialog box, even on low security settings.
		/// </summary>
		/// <param name="filename">The filename to initial display in the dialog box.</param>
		public void SaveAs(string filename)
		{
			object o = null;
			this.ExecWB(SHDocVw.OLECMDID.OLECMDID_SAVEAS,SHDocVw.OLECMDEXECOPT.OLECMDEXECOPT_DONTPROMPTUSER,filename,o);
		}

		/// <summary>
		/// Displays the Open dialog, for opening a new document in the browser window.
		/// </summary>
		public void Open()
		{
			this.ExecWB(SHDocVw.OLECMDID.OLECMDID_OPEN);
		}

		/// <summary>
		/// Displays the print preview dialog box.
		/// </summary>
		public void PrintPreview()
		{
			this.ExecWB(SHDocVw.OLECMDID.OLECMDID_PRINTPREVIEW);
		}

		/// <summary>
		/// Displays the properties of the current resource (HTML page, image etc.) in a new dialog.
		/// </summary>
		public void ShowPageProperties()
		{
			this.ExecWB(SHDocVw.OLECMDID.OLECMDID_PROPERTIES);
		}

		/// <summary>
		/// Prints the current  document
		/// </summary>
		/// <param name="showPrinterSettings"></param>
		public void Print(bool showPrinterSettings)
		{
			SHDocVw.OLECMDEXECOPT promptOpt = SHDocVw.OLECMDEXECOPT.OLECMDEXECOPT_PROMPTUSER;

			if ( !showPrinterSettings )
				promptOpt =	SHDocVw.OLECMDEXECOPT.OLECMDEXECOPT_DONTPROMPTUSER;

			this.ExecWB(SHDocVw.OLECMDID.OLECMDID_PRINT,promptOpt);	
		}

		/// <summary>
		/// Displays the find dialog.
		/// </summary>
		public void Find()
		{
			// ExecWB's with other CMDIDs might need this method to work - the ones
			// I tried like selectall did nothing

			// From http://support.microsoft.com/?kbid=329014
			IOleCommandTarget cmdt;
			Object o = new object();
			try
			{
				cmdt = (IOleCommandTarget) this.CurrentDocument;
				cmdt.Exec(ref cmdGuid, (uint)MiscCommandTarget.Find,
					(uint)SHDocVw.OLECMDEXECOPT.OLECMDEXECOPT_DODEFAULT, ref o, ref o);
			}
			catch(Exception e)
			{
				System.Windows.Forms.MessageBox.Show(e.Message);
			}
		}

		/// <summary>
		/// Displays the system-wide internet options dialog (found in the system control panel).
		/// </summary>
		public void ShowInternetOptions()
		{
			// Credit to http://support.microsoft.com/?kbid=329014
			IOleCommandTarget cmdt;
			Object o = new object();
			try
			{
				cmdt = (IOleCommandTarget) this.CurrentDocument;
				cmdt.Exec(ref cmdGuid, (uint)MiscCommandTarget.Options,
					(uint)SHDocVw.OLECMDEXECOPT.OLECMDEXECOPT_DODEFAULT, ref o, ref o);
			}
			catch
			{
				// NOTE: Because of the way that this CMDID is handled in Internet Explorer,
				// this catch block will always fire, even though the dialog box
				// and its operations completed successfully. You can suppress this
				// error without causing any damage to your host.
			}
		}

		/// <summary>
		/// Displays the HTML source for the current document, with the default viewer.
		/// </summary>
		public void ViewSource()
		{
			// Credit to http://support.microsoft.com/?kbid=329014
			IOleCommandTarget cmdt;
			Object o = new object();
			try
			{
				cmdt = (IOleCommandTarget) this.CurrentDocument;
				cmdt.Exec(ref cmdGuid, (uint)MiscCommandTarget.ViewSource,
					(uint)SHDocVw.OLECMDEXECOPT.OLECMDEXECOPT_DODEFAULT, ref o, ref o);
			}
			catch(Exception e)
			{
				System.Windows.Forms.MessageBox.Show(e.Message);
			}
		}

		/// <summary>
		/// Executes a command on the web browser OLE object.
		/// </summary>
		/// <param name="cmd">The <see ref="SHDocVw.OLECMDID">SHDocVw.OLECMDID</see> to excute.</param>
		public virtual void ExecWB(SHDocVw.OLECMDID cmd)
		{
			// ExecWB's first parameter in the msdn docs:
			// http://msdn.microsoft.com/library/default.asp?url=/workshop/browser/webbrowser/reference/methods/execwb.asp
			// points you to a load of IDM_ constants. None of these
			// work, and ExecWB is an IOleCommandTarget interface implementation, so we'll stick
			// with the OLECMDID constants. This might be the docs being out of date or me being thick, but
			// the OLECMID constants work.

			object o = null;
			this.ExecWB(cmd,SHDocVw.OLECMDEXECOPT.OLECMDEXECOPT_DODEFAULT,o,o);
		}

		/// <summary>
		/// Executes a command on the web browser OLE object.
		/// </summary>
		/// <param name="cmd">The <see ref="SHDocVw.OLECMDID">SHDocVw.OLECMDID</see> to excute.</param>
		/// <param name="opt">The <see ref="SHDocVw.OLECMDEXECOPT">SHDocVw.OLECMDEXECOPT</see> options.</param>
		public virtual void ExecWB(SHDocVw.OLECMDID cmd,SHDocVw.OLECMDEXECOPT opt)
		{
			object o = null;
			this.ExecWB(cmd,opt,o,o);
		}

		/// <summary>
		/// Executes a command on the web browser OLE object.
		/// </summary>
		/// <param name="cmd">The <see ref="SHDocVw.OLECMDID">SHDocVw.OLECMDID</see> to excute.</param>
		/// <param name="opt">The <see ref="SHDocVw.OLECMDEXECOPT">SHDocVw.OLECMDEXECOPT</see> options.</param>
		/// <param name="paramA">The first parameter for the command.</param>
		/// <param name="paramB">The second parameter for the command.</param>
		public virtual void ExecWB(SHDocVw.OLECMDID cmd,SHDocVw.OLECMDEXECOPT opt,object paramA,object paramB)
		{
			try
			{
				if ( !this.QueryOleClientStatus(cmd) )
					return;

				this.axWebBrowser.ExecWB(cmd, opt, ref paramA, ref paramB);
			}
			catch {	}	
		}

		/// <summary>
		/// Queries the ole object (the browser) with the given command.
		/// </summary>
		/// <param name="cmd"></param>
		/// <returns></returns>
		protected bool QueryOleClientStatus(SHDocVw.OLECMDID cmd)
		{
			int response = (int) this.axWebBrowser.QueryStatusWB(cmd);
			return (response & (int) SHDocVw.OLECMDF.OLECMDF_ENABLED) != 0 ? true : false;
		}

		/// <summary>
		/// Navigates the browser to the default homepage, which is set in the internet options
		/// control panel applet.
		/// </summary>
		public void GoHome()
		{
			this.axWebBrowser.GoHome();
		}

		/// <summary>
		/// Navigates the browser to the previous resource that was visited.
		/// </summary>
		public void GoBack()
		{
			this.axWebBrowser.GoBack();
		}

		/// <summary>
		/// Navigates the browser to the next resource that was visited.
		/// </summary>
		public void GoForward()
		{
			this.axWebBrowser.GoForward();
		}

		/// <summary>
		/// Navigates the browser to the default search engine, which is a Windows registry setting
		/// </summary>
		public void GoSearch()
		{
			this.axWebBrowser.GoSearch();

		}
		#endregion

		#region Private methods
		private void SetDocHostUiFlag(DOCHOSTUIFLAG flag,bool add)
		{
			if ( !this.DesignMode )
			{
				try
				{
					if ( add )
						this._flags |= flag;
					else
						this._flags &= ~flag;

					// A cached refresh seems to be the only way to force the browser to update, redrawing does nothing.
					object refresh = RefreshType.IfExpired;
					this.axWebBrowser.Refresh2(ref refresh);
				}
				catch {}
			}
		}

		/// <summary>
		/// 
		/// </summary>
		private void SetOleSite()
		{
			object obj = this.axWebBrowser.GetOcx();
			IOleObject oc = obj as IOleObject;
			oc.SetClientSite(this);
		}
		#endregion

		#region Protected methods
		/// <summary>
		/// Called when the DocumentComplete event is fired.
		/// </summary>
		protected virtual void OnDocumentComplete( AxSHDocVw.DWebBrowserEvents2_DocumentCompleteEvent e)
		{

		}

		/// <summary>
		/// Called when the BeforeNavigate event is fired.
		/// </summary>
		protected virtual void OnBeforeNavigate( AxSHDocVw.DWebBrowserEvents2_BeforeNavigate2Event e )
		{

		}

		/// <summary>
		/// Called when the DownloadBegin event is fired.
		/// </summary>
		protected virtual void OnDownloadBegin( System.EventArgs e )
		{

		}

		/// <summary>
		/// Called when the FileDownload event is fired.
		/// </summary>
		protected virtual void OnFileDownload( AxSHDocVw.DWebBrowserEvents2_FileDownloadEvent e )
		{

		}

		/// <summary>
		/// Called when the BeforeNavigate event is fired.
		/// </summary>
		protected virtual void OnBeforeNavigate( System.EventArgs e )
		{

		}

		/// <summary>
		/// Called when the NavigateComplete event is fired.
		/// </summary>
		protected virtual void OnNavigateComplete( AxSHDocVw.DWebBrowserEvents2_NavigateComplete2Event e )
		{

		}

		/// <summary>
		/// Called when the NavigateError event is fired.
		/// </summary>
		protected virtual void OnNavigateError( AxSHDocVw.DWebBrowserEvents2_NavigateErrorEvent e )
		{

		}

		/// <summary>
		/// Called when the FullScreenChanged event is fired.
		/// </summary>
		protected virtual void OnFullScreenChanged( AxSHDocVw.DWebBrowserEvents2_OnFullScreenEvent e )
		{

		}

		/// <summary>
		/// Called when the MenuBarChanged event is fired.
		/// </summary>
		protected virtual void OnMenuBarChanged( AxSHDocVw.DWebBrowserEvents2_OnMenuBarEvent e )
		{

		}

		/// <summary>
		/// Called when the NewWindow event is fired.
		/// </summary>
		protected virtual void OnNewWindow( AxSHDocVw.DWebBrowserEvents2_NewWindow2Event e )
		{

		}

		/// <summary>
		/// Called when the Quit( event is fired.
		/// </summary>
		protected virtual void OnQuit( System.EventArgs e )
		{

		}

		/// <summary>
		/// Called when the StatusBarChanged event is fired.
		/// </summary>
		protected virtual void OnStatusBarChanged( AxSHDocVw.DWebBrowserEvents2_OnStatusBarEvent e )
		{

		}

		/// <summary>
		/// Called when the TheaterModeChanged event is fired.
		/// </summary>
		protected virtual void OnTheaterModeChanged( AxSHDocVw.DWebBrowserEvents2_OnTheaterModeEvent e )
		{

		}

		/// <summary>
		/// Called when the ToolBarChanged event is fired.
		/// </summary>
		protected virtual void OnToolBarChanged( AxSHDocVw.DWebBrowserEvents2_OnToolBarEvent e )
		{

		}

		/// <summary>
		/// Called when the PrintTemplateInstantiation event is fired.
		/// </summary>
		protected virtual void OnPrintTemplateInstantiation( AxSHDocVw.DWebBrowserEvents2_PrintTemplateInstantiationEvent e )
		{

		}

		/// <summary>
		/// Called when the PrintTemplateTeardown event is fired.
		/// </summary>
		protected virtual void OnPrintTemplateTeardown( AxSHDocVw.DWebBrowserEvents2_PrintTemplateTeardownEvent e)
		{

		}

		/// <summary>
		/// Called when the PrivacyImpactedStateChange event is fired.
		/// </summary>
		protected virtual void OnPrivacyImpactedStateChange( AxSHDocVw.DWebBrowserEvents2_PrivacyImpactedStateChangeEvent e )
		{

		}

		/// <summary>
		/// Called when the ProgressChange event is fired.
		/// </summary>
		protected virtual void OnProgressChange( AxSHDocVw.DWebBrowserEvents2_ProgressChangeEvent e )
		{

		}

		/// <summary>
		/// Called when the PropertyChange event is fired.
		/// </summary>
		protected virtual void OnPropertyChange( AxSHDocVw.DWebBrowserEvents2_PropertyChangeEvent e )
		{

		}

		/// <summary>
		/// Called when the SetSecureLockIcon event is fired.
		/// </summary>
		protected virtual void OnSetSecureLockIcon( AxSHDocVw.DWebBrowserEvents2_SetSecureLockIconEvent e )
		{

		}

		/// <summary>
		/// Called when the StatusTextChange event is fired.
		/// </summary>
		protected virtual void OnStatusTextChange( AxSHDocVw.DWebBrowserEvents2_StatusTextChangeEvent e )
		{

		}

		/// <summary>
		/// Called when the TitleChanged event is fired.
		/// </summary>
		protected virtual void OnTitleChanged( AxSHDocVw.DWebBrowserEvents2_TitleChangeEvent e )
		{

		}

		/// <summary>
		/// Called when the UpdatePageStatus event is fired.
		/// </summary>
		protected virtual void OnUpdatePageStatus( AxSHDocVw.DWebBrowserEvents2_UpdatePageStatusEvent e )
		{

		}

		/// <summary>
		/// Called when the WindowClosing event is fired.
		/// </summary>
		protected virtual void OnWindowClosing( AxSHDocVw.DWebBrowserEvents2_WindowClosingEvent e )
		{

		}

		/// <summary>
		/// Called when the WindowSetHeight event is fired.
		/// </summary>
		protected virtual void OnWindowSetHeight( AxSHDocVw.DWebBrowserEvents2_WindowSetHeightEvent e )
		{

		}

		/// <summary>
		/// Called when the WindowSetLeft event is fired.
		/// </summary>
		protected virtual void OnWindowSetLeft( AxSHDocVw.DWebBrowserEvents2_WindowSetLeftEvent e )
		{

		}

		/// <summary>
		/// Called when the WindowSetResizable event is fired.
		/// </summary>
		protected virtual void OnWindowSetResizable( AxSHDocVw.DWebBrowserEvents2_WindowSetResizableEvent e )
		{

		}

		/// <summary>
		/// Called when the WindowSetTop event is fired.
		/// </summary>
		protected virtual void OnWindowSetTop( AxSHDocVw.DWebBrowserEvents2_WindowSetTopEvent e )
		{

		}

		/// <summary>
		/// Called when the WindowSetWidth event is fired.
		/// </summary>
		protected virtual void OnWindowSetWidth( AxSHDocVw.DWebBrowserEvents2_WindowSetWidthEvent e )
		{

		}
		#endregion

		#region Html Document Event handlers
		private bool htmlEvent_onclick(IHTMLEventObj e)
		{
			e.returnValue = true;
			WebBrowserExEventArgs ea = new WebBrowserExEventArgs(e);
			this.OnHtmlDocumentClick(ea);

			if ( this.HtmlDocumentClick != null )			
				this.HtmlDocumentClick(this,ea);

			return false;
		}

		private bool htmlEvent_ondblclick(IHTMLEventObj e)
		{
			WebBrowserExEventArgs ea = new WebBrowserExEventArgs(e);
			this.OnHtmlDocumentDoubleClick(ea);

			if ( this.HtmlDocumentDoubleClick != null )			
				this.HtmlDocumentDoubleClick(this,ea);

			return false;
		}

		private void htmlEvent_onkeydown(IHTMLEventObj e)
		{
			e.returnValue = false;
			WebBrowserExKeyEventArgs ea = new WebBrowserExKeyEventArgs((Keys) e.keyCode,e);
			this.OnHtmlDocumentKeyDown(ea);

			if ( this.HtmlDocumentKeyDown != null )				
				this.HtmlDocumentKeyDown(this,ea);
		}

		private bool htmlEvent_onkeypress(IHTMLEventObj e)
		{
			e.returnValue = false;
			WebBrowserExKeyEventArgs ea = new WebBrowserExKeyEventArgs((Keys) e.keyCode,e);
			this.OnHtmlDocumentKeyPress(ea);

			if ( this.HtmlDocumentKeyPress != null )			
				this.HtmlDocumentKeyPress(this,ea);

			return false;
		}

		private void htmlEvent_onkeyup(IHTMLEventObj e)
		{
			e.returnValue = false;
			WebBrowserExKeyEventArgs ea = new WebBrowserExKeyEventArgs((Keys) e.keyCode,e);
			this.OnHtmlDocumentKeyUp(ea);

			if ( this.HtmlDocumentKeyUp != null )				
				this.HtmlDocumentKeyUp(this,ea);
		}

		private void htmlEvent_onmousedown(IHTMLEventObj e)
		{
			e.returnValue = true;
			WebBrowserExMouseEventArgs ea = new WebBrowserExMouseEventArgs(HtmlButtonToMouseButtons(e.button),1,e.x,e.y,0,e);
			this.OnHtmlDocumentMouseDown(ea);

			if ( this.HtmlDocumentMouseDown != null )
				this.HtmlDocumentMouseDown(this,ea);
		}

		private void htmlEvent_onmousemove(IHTMLEventObj e)
		{
			WebBrowserExMouseEventArgs ea = new WebBrowserExMouseEventArgs(HtmlButtonToMouseButtons(e.button),1,e.x,e.y,0,e);
			this.OnHtmlDocumentMouseMove(ea);

			if ( this.HtmlDocumentMouseMove != null )
				this.HtmlDocumentMouseMove(this,ea);
		}

		private void htmlEvent_onmouseover(IHTMLEventObj e)
		{
			WebBrowserExMouseEventArgs ea = new WebBrowserExMouseEventArgs(HtmlButtonToMouseButtons(e.button),1,e.x,e.y,0,e);
			this.OnHtmlDocumentMouseOver(ea);

			if ( this.HtmlDocumentMouseOver != null )
				this.HtmlDocumentMouseOver(this,ea);
		}

		private void htmlEvent_onmouseout(IHTMLEventObj e)
		{
			WebBrowserExMouseEventArgs ea = new WebBrowserExMouseEventArgs(HtmlButtonToMouseButtons(e.button),1,e.x,e.y,0,e);
			this.OnHtmlDocumentMouseOut(ea);

			if ( this.HtmlDocumentMouseOut != null )
				this.HtmlDocumentMouseOut(this,ea);
		}

		private void htmlEvent_onmouseup(IHTMLEventObj e)
		{
			e.returnValue = true;
			WebBrowserExMouseEventArgs ea = new WebBrowserExMouseEventArgs(HtmlButtonToMouseButtons(e.button),1,e.x,e.y,0,e);
			this.OnHtmlDocumentMouseUp(ea);

			if ( this.HtmlDocumentMouseUp != null )
				this.HtmlDocumentMouseUp(this,ea);
		}

		private MouseButtons HtmlButtonToMouseButtons(int i)
		{
			switch ( i )
			{
				case 0:
					return MouseButtons.Left;
				case 1:
					return MouseButtons.Middle;
				case 2:
					return MouseButtons.Right;
				default:
					return MouseButtons.Left;
			}
		}
	
		#endregion

		#region Html Document methods for event handling in derived classes
		/// <summary>
		/// Called when the HtmlDocumentClick event is fired.
		/// </summary>
		protected virtual void OnHtmlDocumentClick(WebBrowserExEventArgs e)
		{
		}

		/// <summary>
		/// Called when the HtmlDocumentDoubleClick event is fired.
		/// </summary>
		protected virtual void OnHtmlDocumentDoubleClick(WebBrowserExEventArgs e)
		{
		}

		/// <summary>
		/// Called when the HtmlDocumentKeyDown event is fired.
		/// </summary>
		protected virtual void OnHtmlDocumentKeyDown(WebBrowserExKeyEventArgs e)
		{
		}

		/// <summary>
		/// Called when the HtmlDocumentKeyPress event is fired.
		/// </summary>
		protected virtual void OnHtmlDocumentKeyPress(WebBrowserExKeyEventArgs e)
		{
		}

		/// <summary>
		/// Called when the HtmlDocumentKeyUp event is fired.
		/// </summary>
		protected virtual void OnHtmlDocumentKeyUp(WebBrowserExKeyEventArgs e)
		{
		}

		/// <summary>
		/// Called when the HtmlDocumentMouseDown event is fired.
		/// </summary>
		protected virtual void OnHtmlDocumentMouseDown(WebBrowserExMouseEventArgs e)
		{
		}

		/// <summary>
		/// Called when the HtmlDocumentMouseMove event is fired.
		/// </summary>
		protected virtual void OnHtmlDocumentMouseMove(WebBrowserExMouseEventArgs e)
		{
		}

		/// <summary>
		/// Called when the HtmlDocumentMouseOut event is fired.
		/// </summary>
		protected virtual void OnHtmlDocumentMouseOut(WebBrowserExMouseEventArgs e)
		{
		}

		/// <summary>
		/// Called when the HtmlDocumentMouseOver event is fired.
		/// </summary>
		protected virtual void OnHtmlDocumentMouseOver(WebBrowserExMouseEventArgs e)
		{
		}

		/// <summary>
		/// Called when the HtmlDocumentMouseUp event is fired.
		/// </summary>
		protected virtual void OnHtmlDocumentMouseUp(WebBrowserExMouseEventArgs e)
		{
		}
		#endregion	

		#region IOleClientSite Members

		/// <summary>
		/// Used to configure the BrowserOptions for the browser.
		/// </summary>
		/// <returns>
		/// The BrowserOptions options.
		/// </returns>
		[DispId(-5512)]
		public virtual int IDispatch_Invoke_Handler()
		{
			// Not part of IOleClientSite, put it here though
			return (int) this._options;
		}

		int IOleClientSite.SaveObject()
		{
			return 0;
		}

		int IOleClientSite.GetMoniker(uint dwAssign, uint dwWhichMoniker, out Object ppmk)
		{
			ppmk = null;
			return 0;
		}

		int IOleClientSite.GetContainer(out IOleContainer ppContainer)
		{
			ppContainer = null;
			return 0;
		}

		int IOleClientSite.ShowObject()
		{
			return 0;
		}

		int IOleClientSite.OnShowWindow(int fShow)
		{
			return 0;
		}

		int IOleClientSite.RequestNewObjectLayout()
		{
			return 0;
		}

		#endregion

		#region IDocHostUIHandler Members
		uint IDocHostUIHandler.ShowContextMenu(uint dwID, ref tagPOINT ppt, object pcmdtReserved, object pdispReserved)
		{
			if ( this.ContextMenu != null )
			{
				Point point = new Point(ppt.x, ppt.y);
				point = PointToClient(point); 

				this.ContextMenu.Show(this, point);
				throw new COMException("", S_OK);
			}
			else
			{
				throw new COMException("", S_FALSE);
			}
		}

		void IDocHostUIHandler.GetHostInfo(ref DOCHOSTUIINFO pInfo)
		{
			pInfo.dwFlags = (uint) _flags;
		}

		void IDocHostUIHandler.ShowUI(uint dwID, ref object pActiveObject, ref object pCommandTarget, ref object pFrame, ref object pDoc)
		{
			// TODO:  Add WebBrowserEx.ShowUI implementation
		}

		void IDocHostUIHandler.HideUI()
		{
			// TODO:  Add WebBrowserEx.HideUI implementation
		}

		void IDocHostUIHandler.UpdateUI()
		{
			// TODO:  Add WebBrowserEx.UpdateUI implementation
		}

		void IDocHostUIHandler.EnableModeless(int fEnable)
		{
			// TODO:  Add WebBrowserEx.EnableModeless implementation
		}

		void IDocHostUIHandler.OnDocWindowActivate(int fActivate)
		{
			// TODO:  Add WebBrowserEx.OnDocWindowActivate implementation
		}

		void IDocHostUIHandler.OnFrameWindowActivate(int fActivate)
		{
			// TODO:  Add WebBrowserEx.OnFrameWindowActivate implementation
		}

		void IDocHostUIHandler.ResizeBorder(ref tagRECT prcBorder, int pUIWindow, int fRameWindow)
		{
			// TODO:  Add WebBrowserEx.ResizeBorder implementation
		}

		uint IDocHostUIHandler.TranslateAccelerator(ref tagMSG lpMsg, ref Guid pguidCmdGroup, uint nCmdID)
		{
			return this.OnTranslateAccelerator(ref lpMsg,ref pguidCmdGroup,nCmdID);
		}

		void IDocHostUIHandler.GetOptionKeyPath(ref string pchKey, uint dw)
		{
			// TODO:  Add WebBrowserEx.GetOptionKeyPath implementation
		}

		object IDocHostUIHandler.GetDropTarget(ref object pDropTarget)
		{
			// TODO:  Add WebBrowserEx.GetDropTarget implementation
			return null;
		}

		int IDocHostUIHandler.GetExternal(out object ppDispatch)
		{
			ppDispatch = null;
			return 0;
		}

		uint IDocHostUIHandler.TranslateUrl(uint dwTranslate, string pchURLIn, ref string ppchURLOut)
		{
			return OnTranslateUrl(dwTranslate,pchURLIn,ref ppchURLOut);
		}

		IDataObject IDocHostUIHandler.FilterDataObject(IDataObject pDO)
		{
			// TODO:  Add WebBrowserEx.FilterDataObject implementation
			return null;
		}

		#endregion

		#region Exposed virtual functions for IDocHostUIHandler methods
		/// <summary>
		/// Enables tranformation of URLs being navigated to.
		/// </summary>
		/// <param name="dwTranslate">Bit flags that specify how the URL string is to be translated.</param>
		/// <param name="urlIn">The url the user is attempting to navigate to.</param>
		/// <param name="urlOut">The url that the user is navigated to.</param>
		/// <returns>Returns S_FALSE (0) if the URL was translated.</returns>
		/// <remarks>
		/// Refrence: <see href="http://msdn.microsoft.com/library/default.asp?url=/library/en-us/shellcc/platform/shell/reference/functions/translateurl.asp">msdn</see>
		/// <example>
		/// <code>
		/// // Prevent navigating to banned sites.
		/// if (URLIn.IndexOf("filthserver.com") > -1 )
		///		URLOut = "http://intranet/banned-site.html";
		/// else
		///		URLOut = URLIn;
		///	
		///	return 1; // S_FALSE indicates you've translated the url.
		/// </code>
		/// </example>
		/// </remarks>
		protected virtual uint OnTranslateUrl(uint dwTranslate, string urlIn, ref string urlOut)
		{
			urlOut = urlIn; 
			return S_FALSE;
		}

		/// <summary>
		/// Processes accelerator keys for menu commands. The various Disablexx properties are processed here.
		/// </summary>
		/// <param name="lpMsg"></param>
		/// <param name="pguidCmdGroup"></param>
		/// <param name="nCmdID"></param>
		/// <returns>Throw a new COMException with S_OK (0) if the key was processed, S_FALSE (1) otherwise.</returns>
		/// <remarks>
		/// Reference: <see href="http://msdn.microsoft.com/library/default.asp?url=/library/en-us/winui/winui/windowsuserinterface/userinput/keyboardaccelerators/keyboardacceleratorreference/keyboardacceleratorfunctions/translateaccelerator.asp">MSDN</see>
		/// </remarks>
		protected virtual uint OnTranslateAccelerator(ref tagMSG lpMsg, ref Guid pguidCmdGroup, uint nCmdID)
		{
			// Most of this method is thanks to http://www.codeproject.com/books/0764549146_8.asp
			// Throw S_OK if we've handled the key, S_FALSE otherwise, inside a ComException
			int WM_KEYDOWN = 0x0100;

			if (lpMsg.message != WM_KEYDOWN)
				throw new COMException("", S_FALSE);

			lpMsg.wParam &= 0xFF; // get the virtual keycode
		
			// Navigate keys: backspace
			if ( this.DisableBackSpace && lpMsg.wParam ==  8 )
				throw new COMException("", S_OK);

			// Navigate keys: ALT ( Translator doesn't catch this, or Shift+mouse click)
			//if ( this.DisableNavigateKeys && (Control.ModifierKeys & Keys.Alt) == Keys.Alt &&
			//	lpMsg.wParam ==  37 || lpMsg.wParam ==  39 )
			//	throw new COMException("", S_FALSE);

			// CTRL+F : Find
			if ( this.DisableCtrlF && (Control.ModifierKeys & Keys.Control) == Keys.Control && lpMsg.wParam == (int) 'F' )
				throw new COMException("", S_OK);

			// CTRL+N : New window
			if ( this.DisableCtrlN && (Control.ModifierKeys & Keys.Control) == Keys.Control && lpMsg.wParam == (int) 'N' )
				throw new COMException("", S_OK);

			// CTRL+O : (Redundent?)
			if ( this.DisableCtrlO && (Control.ModifierKeys & Keys.Control) == Keys.Control && lpMsg.wParam == (int) 'O' )
				throw new COMException("", S_OK);

			// CTRL+P : Print
			if ( this.DisableCtrlP && (Control.ModifierKeys & Keys.Control) == Keys.Control && lpMsg.wParam == (int) 'P' )
				throw new COMException("", S_OK);

			// Default: allow it
			throw new COMException("", S_FALSE);
		}
		#endregion

		#region Load, document complete (IDocUIHandler wireup and mshtml wireup)
		private void WebBrowserEx_Load(object sender, System.EventArgs e)
		{
			if ( !this.DesignMode )
				this.SetOleSite(); // the OLE/COM settings dont show in designmode
		}

		private void axWebBrowser1_DocumentComplete(object sender, AxSHDocVw.DWebBrowserEvents2_DocumentCompleteEvent e)
		{
			IHTMLDocument2 hDoc = (IHTMLDocument2)this.axWebBrowser.Document;

			if ( hDoc != null )
				((ICustomDoc) hDoc).SetUIHandler((IDocHostUIHandler) this);

			if ( this.EnableHtmlDocumentEventHandling )
			{
				// Experimental
				mshtml.HTMLDocument doc = (mshtml.HTMLDocument)this.axWebBrowser.Document;

				// Wire up to HTML document events. There are a few bugs with these
				mshtml.HTMLDocumentEvents2_Event htmlEvent;
				htmlEvent = (mshtml.HTMLDocumentEvents2_Event) doc;

				htmlEvent.onclick		+= new HTMLDocumentEvents2_onclickEventHandler(htmlEvent_onclick);
				htmlEvent.ondblclick	+= new HTMLDocumentEvents2_ondblclickEventHandler(htmlEvent_ondblclick);
				htmlEvent.onkeydown		+= new HTMLDocumentEvents2_onkeydownEventHandler(htmlEvent_onkeydown);
				htmlEvent.onkeypress	+= new HTMLDocumentEvents2_onkeypressEventHandler(htmlEvent_onkeypress);
				htmlEvent.onkeyup		+= new HTMLDocumentEvents2_onkeyupEventHandler(htmlEvent_onkeyup);
				htmlEvent.onmousedown	+= new HTMLDocumentEvents2_onmousedownEventHandler(htmlEvent_onmousedown);
				htmlEvent.onmousemove	+= new HTMLDocumentEvents2_onmousemoveEventHandler(htmlEvent_onmousemove);
				htmlEvent.onmouseout	+= new HTMLDocumentEvents2_onmouseoutEventHandler(htmlEvent_onmouseout);
				htmlEvent.onmouseover	+= new HTMLDocumentEvents2_onmouseoverEventHandler(htmlEvent_onmouseover);
				htmlEvent.onmouseup		+= new HTMLDocumentEvents2_onmouseupEventHandler(htmlEvent_onmouseup);
			}

			// For derived classes
			this.OnDocumentComplete(e);
		
			// Wire up the event
			if ( this.DocumentComplete != null )
				this.DocumentComplete(this,e);
		}
		#endregion

		#region AxWebBrowser event handling
		private void axWebBrowser1_BeforeNavigate2(object sender, AxSHDocVw.DWebBrowserEvents2_BeforeNavigate2Event e)
		{
			// If the document's loaded, and openinnewwindow is set, trap all link clicks
			// and open them in a new window
			if ( this.OpenInNewWindow && this._linkClicked)
			{
				e.cancel = true;
				this.Navigate(e.uRL.ToString(),NavigateOptions.OpenInNewWindow);
			}
		
			// Wire up the event
			if ( this.BeforeNavigate != null )
				this.BeforeNavigate(this,e);

			this._linkClicked = true;

			// For derived classes
			this.OnBeforeNavigate(e);
		}

		private void axWebBrowser_DownloadBegin(object sender, System.EventArgs e)
		{
			if ( this.DownloadBegin != null )
				this.DownloadBegin(this,e);
		}

		private void axWebBrowser_DownloadComplete(object sender, System.EventArgs e)
		{
			if ( this.DownloadComplete != null )
				this.DownloadComplete(this,e);	
		}

		private void axWebBrowser_FileDownload(object sender, AxSHDocVw.DWebBrowserEvents2_FileDownloadEvent e)
		{
			if ( this.FileDownload != null )
				this.FileDownload(this,e);
		}

		private void axWebBrowser_NavigateComplete2(object sender, AxSHDocVw.DWebBrowserEvents2_NavigateComplete2Event e)
		{
			// For derived classes
			this.OnNavigateComplete(e);
		
			// Wire the event
			if ( this.NavigateComplete != null )
				this.NavigateComplete(this,e);
		}

		private void axWebBrowser_NavigateError(object sender, AxSHDocVw.DWebBrowserEvents2_NavigateErrorEvent e)
		{
			// For derived classes
			this.OnNavigateError(e);
		
			// Wire up the event
			if ( this.NavigateError != null )
				this.NavigateError(this,e);
		}

		private void axWebBrowser_OnFullScreen(object sender, AxSHDocVw.DWebBrowserEvents2_OnFullScreenEvent e)
		{
			// For derived classes
			this.OnFullScreenChanged(e);
		
			// Wire up the event
			if ( this.FullScreenChanged != null )
				this.FullScreenChanged(this,e);
		}

		private void axWebBrowser_OnMenuBar(object sender, AxSHDocVw.DWebBrowserEvents2_OnMenuBarEvent e)
		{
			// For derived classes
			this.OnMenuBarChanged(e);
		
			// Wire up the event
			if ( this.MenuBarChanged != null )
				this.MenuBarChanged(this,e);
		}

		private void axWebBrowser1_NewWindow2(object sender, AxSHDocVw.DWebBrowserEvents2_NewWindow2Event e)
		{
			// This one is for pre SP2 XP and others

			// For derived classes
			this.OnNewWindow(e);
		
			// Wire up the event
			if ( this.NewWindow != null )
				this.NewWindow(this,e);
		}

		private void axWebBrowser_OnQuit(object sender, System.EventArgs e)
		{
			// For derived classes
			this.OnQuit(e);
		
			// Wire up the event
			if ( this.Quit != null )
				this.Quit(this,e);
		}

		private void axWebBrowser_OnStatusBar(object sender, AxSHDocVw.DWebBrowserEvents2_OnStatusBarEvent e)
		{
			// For derived classes
			this.OnStatusBarChanged(e);
		
			// Wire up the event
			if ( this.StatusBarChanged != null )
				this.StatusBarChanged(this,e);
		}

		private void axWebBrowser_OnTheaterMode(object sender, AxSHDocVw.DWebBrowserEvents2_OnTheaterModeEvent e)
		{
			// For derived classes
			this.OnTheaterModeChanged(e);
		
			// Wire up the event
			if ( this.TheaterModeChanged != null )
				this.TheaterModeChanged(this,e);
		}

		private void axWebBrowser_OnToolBar(object sender, AxSHDocVw.DWebBrowserEvents2_OnToolBarEvent e)
		{
			// For derived classes
			this.OnToolBarChanged(e);
		
			// Wire up the event
			if ( this.ToolBarChanged != null )
				this.ToolBarChanged(this,e);
		}

		private void axWebBrowser_PrintTemplateInstantiation(object sender, AxSHDocVw.DWebBrowserEvents2_PrintTemplateInstantiationEvent e)
		{
			// For derived classes
			this.OnPrintTemplateInstantiation(e);
		
			// Wire up the event
			if ( this.PrintTemplateInstantiation != null )
				this.PrintTemplateInstantiation(this,e);
		}

		private void axWebBrowser_PrintTemplateTeardown(object sender, AxSHDocVw.DWebBrowserEvents2_PrintTemplateTeardownEvent e)
		{
			// For derived classes
			this.OnPrintTemplateTeardown(e);
		
			// Wire up the event
			if ( this.PrintTemplateTeardown != null )
				this.PrintTemplateTeardown(this,e);
		}

		private void axWebBrowser_PrivacyImpactedStateChange(object sender, AxSHDocVw.DWebBrowserEvents2_PrivacyImpactedStateChangeEvent e)
		{
			// For derived classes
			this.OnPrivacyImpactedStateChange(e);
		
			// Wire up the event
			if ( this.PrivacyImpactedStateChange != null )
				this.PrivacyImpactedStateChange(this,e);
		}

		private void axWebBrowser_ProgressChange(object sender, AxSHDocVw.DWebBrowserEvents2_ProgressChangeEvent e)
		{
			// For derived classes
			this.OnProgressChange(e);
		
			// Wire up the event
			if ( this.ProgressChange != null )
				this.ProgressChange(this,e);
		}

		private void axWebBrowser_PropertyChange(object sender, AxSHDocVw.DWebBrowserEvents2_PropertyChangeEvent e)
		{
			// For derived classes
			this.OnPropertyChange(e);
		
			// Wire up the event
			if ( this.PropertyChange != null )
				this.PropertyChange(this,e);
		}

		private void axWebBrowser_SetSecureLockIcon(object sender, AxSHDocVw.DWebBrowserEvents2_SetSecureLockIconEvent e)
		{
			// For derived classes
			this.OnSetSecureLockIcon(e);
		
			// Wire up the event
			if ( this.SetSecureLockIcon != null )
				this.SetSecureLockIcon(this,e);
		}

		private void axWebBrowser_StatusTextChange(object sender, AxSHDocVw.DWebBrowserEvents2_StatusTextChangeEvent e)
		{
			// For derived classes
			this.OnStatusTextChange(e);
		
			// Wire up the event
			if ( this.StatusTextChange != null )
				this.StatusTextChange(this,e);
		}

		private void axWebBrowser_TitleChange(object sender, AxSHDocVw.DWebBrowserEvents2_TitleChangeEvent e)
		{
			// For derived classes
			this.OnTitleChanged(e);
		
			// Wire up the event
			if ( this.TitleChanged != null )
				this.TitleChanged(this,e);
		}

		private void axWebBrowser_UpdatePageStatus(object sender, AxSHDocVw.DWebBrowserEvents2_UpdatePageStatusEvent e)
		{
			// For derived classes
			this.OnUpdatePageStatus(e);
		
			// Wire up the event
			if ( this.UpdatePageStatus != null )
				this.UpdatePageStatus(this,e);
		}

		private void axWebBrowser_WindowClosing(object sender, AxSHDocVw.DWebBrowserEvents2_WindowClosingEvent e)
		{
			// For derived classes
			this.OnWindowClosing(e);
		
			// Wire up the event
			if ( this.WindowClosing != null )
				this.WindowClosing(this,e);
		}

		private void axWebBrowser_WindowSetHeight(object sender, AxSHDocVw.DWebBrowserEvents2_WindowSetHeightEvent e)
		{
			// For derived classes
			this.OnWindowSetHeight(e);
		
			// Wire up the event
			if ( this.WindowSetHeight != null )
				this.WindowSetHeight(this,e);
		}

		private void axWebBrowser_WindowSetLeft(object sender, AxSHDocVw.DWebBrowserEvents2_WindowSetLeftEvent e)
		{
			// For derived classes
			this.OnWindowSetLeft(e);
		
			// Wire up the event
			if ( this.WindowSetLeft != null )
				this.WindowSetLeft(this,e);
		}

		private void axWebBrowser_WindowSetResizable(object sender, AxSHDocVw.DWebBrowserEvents2_WindowSetResizableEvent e)
		{
			// For derived classes
			this.OnWindowSetResizable(e);
		
			// Wire up the event
			if ( this.WindowSetResizable != null )
				this.WindowSetResizable(this,e);
		}

		private void axWebBrowser_WindowSetTop(object sender, AxSHDocVw.DWebBrowserEvents2_WindowSetTopEvent e)
		{
			// For derived classes
			this.OnWindowSetTop(e);
		
			// Wire up the event
			if ( this.WindowSetTop != null )
				this.WindowSetTop(this,e);
		}

		private void axWebBrowser_WindowSetWidth(object sender, AxSHDocVw.DWebBrowserEvents2_WindowSetWidthEvent e)
		{
			// For derived classes
			this.OnWindowSetWidth(e);
		
			// Wire up the event
			if ( this.WindowSetWidth != null )
				this.WindowSetWidth(this,e);
		}
		#endregion
	}

	#region BrowserOptions,NavigateOptions,RefreshType enums
	/// <summary>
	/// Specifies browser display and download options.
	/// </summary>
	/// <remarks>
	/// Reference: <see href="http://msdn.microsoft.com/library/default.asp?url=/workshop/browser/overview/Overview.asp">MSDN</see>
	/// </remarks>
	[
	Flags(),
	Editor( typeof(FlagsEditor), typeof(System.Drawing.Design.UITypeEditor) )
	]
	public enum BrowserOptions : uint
	{
		/// <summary>
		/// No flags are set.
		/// </summary>
		None				= 0,
		/// <summary>
		/// The browser will operate in offline mode. Equivalent to DLCTL_FORCEOFFLINE.
		/// </summary>
		AlwaysOffline		= 0x10000000,
		/// <summary>
		/// The browser will play background sounds. Equivalent to DLCTL_BGSOUNDS.
		/// </summary>
		BackgroundSounds	= 0x00000040,
		/// <summary>
		/// Specifies that the browser will not run Active-X controls. Use this setting
		/// to disable Flash movies. Equivalent to DLCTL_NO_RUNACTIVEXCTLS.
		/// </summary>
		DontRunActiveX		= 0x00000200,
		/// <summary>
		///  Specifies that the browser should fetch the content from the server. If the server's
		///  content is the same as the cache, the cache is used.Equivalent to DLCTL_RESYNCHRONIZE.
		/// </summary>
		IgnoreCache			= 0x00002000,
		/// <summary>
		///  The browser will force the request from the server, and ignore the proxy, even if the
		///  proxy indicates the content is up to date.Equivalent to DLCTL_PRAGMA_NO_CACHE.
		/// </summary>
		IgnoreProxy			= 0x00004000,
		/// <summary>
		///  Specifies that the browser should download and display images. This is set by default.
		///  Equivalent to DLCTL_DLIMAGES.
		/// </summary>
		Images				= 0x00000010,
		/// <summary>
		///  Disables downloading and installing of Active-X controls.Equivalent to DLCTL_NO_DLACTIVEXCTLS.
		/// </summary>
		NoActiveXDownload	= 0x00000400,
		/// <summary>
		///  Disables web behaviours.Equivalent to DLCTL_NO_BEHAVIORS.
		/// </summary>
		NoBehaviours		= 0x00008000,
		/// <summary>
		///  The browser suppresses any HTML charset specified.Equivalent to DLCTL_NO_METACHARSET.
		/// </summary>
		NoCharSets			= 0x00010000,
		/// <summary>
		///  Indicates the browser will ignore client pulls.Equivalent to DLCTL_NO_CLIENTPULL.
		/// </summary>
		NoClientPull		= 0x20000000,
		/// <summary>
		///  The browser will not download or display Java applets.Equivalent to DLCTL_NO_JAVA.
		/// </summary>
		NoJava				= 0x00000100,
		/// <summary>
		///  The browser will download framesets and parse them, but will not download the frames
		///  contained inside those framesets.Equivalent to DLCTL_NO_FRAMEDOWNLOAD.
		/// </summary>
		NoFrameDownload		= 0x00080000,
		/// <summary>
		///  The browser will not execute any scripts.Equivalent to DLCTL_NO_SCRIPTS.
		/// </summary>
		NoScripts			= 0x00000080,
		/// <summary>
		///  If the browser cannot detect any internet connection, this causes it to default to
		///  offline mode.Equivalent to DLCTL_OFFLINEIFNOTCONNECTED.
		/// </summary>
		OfflineIfNotConnected = 0x80000000,
		/// <summary>
		///  Specifies that UTF8 should be used.Equivalent to DLCTL_URL_ENCODING_ENABLE_UTF8.
		/// </summary>
		UTF8				= 0x00040000,
		/// <summary>
		///  The browser will download and display video media.Equivalent to DLCTL_VIDEOS.
		/// </summary>
		Videos				= 0x00000020	
	}


	/// <summary>
	/// Used to specify options for navigating to Urls.
	/// </summary>
	/// <remarks>
	/// Reference: <see href="http://msdn.microsoft.com/workshop/browser/webbrowser/reference/enums/browsernavconstants.asp">MSDN</see>
	/// </remarks>
	[Flags()]
	public enum NavigateOptions :uint
	{
		/// <summary>
		/// The Url will open in the same window, with no other options.
		/// </summary>
		None = 0,
		/// <summary>
		/// The Url will launch in a new browser window.
		/// </summary>
		OpenInNewWindow = 0x1,
		/// <summary>
		/// The Url is not stored in the default IE history list.
		/// </summary>
		NoHistory = 0x2,
		/// <summary>
		/// Not supported.
		/// </summary>
		NoReadFromCache = 0x4,
		/// <summary>
		/// Not supported.
		/// </summary>
		NoWriteToCache = 0x8,
		/// <summary>
		/// If the browser cannot find the Url, then setting this option will set the browser
		/// to default to searching for the Url using its default search engine.
		/// </summary>
		AllowAutosearch = 0x10,
		/// <summary>
		/// Causes the current Explorer Bar to navigate to the given item, if possible. 
		/// </summary>
		BrowserBar = 0x20,
		/// <summary>
		/// If the navigation fails when a hyperlink is being followed, this constant specifies that the resource should then be bound to the moniker using the BINDF_HYPERLINK flag.
		/// </summary>
		Hyperlink = 0x40
	}

	/// <summary>
	/// Specifies the type of refresh that is performed when a page is refreshed.
	/// </summary>
	public enum RefreshType
	{
		/// <summary>
		/// Refresh that does not include sending the HTTP "pragma:nocache" header to the server.
		/// </summary>
		Normal = 0,
		/// <summary>
		/// Refresh that occurs if the page has expired.
		/// </summary>
		IfExpired = 1,
		/// <summary>
		/// Refresh that includes sending a "pragma:nocache" header to the server (HTTP URLs only).
		/// </summary>
		Completely = 3
	}
	#endregion

	#region OLE / COM interfaces and types

	#region Doc enums + structs
	internal enum DOCHOSTUITYPE
	{
		DOCHOSTUITYPE_BROWSE = 0,
		DOCHOSTUITYPE_AUTHOR = 1
	}


	internal enum DOCHOSTUIDBLCLK
	{
		DOCHOSTUIDBLCLK_DEFAULT = 0,
		DOCHOSTUIDBLCLK_SHOWPROPERTIES = 1,
		DOCHOSTUIDBLCLK_SHOWCODE = 2
	}

	[Flags()]
	internal enum DOCHOSTUIFLAG
	{
		DOCHOSTUIFLAG_DIALOG = 0x00000001,
		DOCHOSTUIFLAG_DISABLE_HELP_MENU = 0x00000002,
		DOCHOSTUIFLAG_NO3DBORDER = 0x00000004,
		DOCHOSTUIFLAG_SCROLL_NO = 0x00000008,
		DOCHOSTUIFLAG_DISABLE_SCRIPT_INACTIVE = 0x00000010,
		DOCHOSTUIFLAG_OPENNEWWIN = 0x00000020,
		DOCHOSTUIFLAG_DISABLE_OFFSCREEN = 0x00000040,
		DOCHOSTUIFLAG_FLAT_SCROLLBAR = 0x00000080,
		DOCHOSTUIFLAG_DIV_BLOCKDEFAULT = 0x00000100,
		DOCHOSTUIFLAG_ACTIVATE_CLIENTHIT_ONLY = 0x00000200,
		DOCHOSTUIFLAG_OVERRIDEBEHAVIORFACTORY = 0x00000400,
		DOCHOSTUIFLAG_CODEPAGELINKEDFONTS = 0x00000800,
		DOCHOSTUIFLAG_URL_ENCODING_DISABLE_UTF8 = 0x00001000,
		DOCHOSTUIFLAG_URL_ENCODING_ENABLE_UTF8 = 0x00002000,
		DOCHOSTUIFLAG_ENABLE_FORMS_AUTOCOMPLETE = 0x00004000,
		DOCHOSTUIFLAG_ENABLE_INPLACE_NAVIGATION = 0x00010000,
		DOCHOSTUIFLAG_IME_ENABLE_RECONVERSION = 0x00020000,
		DOCHOSTUIFLAG_THEME = 0x00040000,
		DOCHOSTUIFLAG_NOTHEME = 0x00080000,
		DOCHOSTUIFLAG_NOPICS = 0x00100000,
		DOCHOSTUIFLAG_NO3DOUTERBORDER = 0x00200000,
		DOCHOSTUIFLAG_DELEGATESIDOFDISPATCH = 0x00400000
	}


	[ StructLayout( LayoutKind.Sequential )]
	internal struct DOCHOSTUIINFO
	{
		public uint cbSize;
		public uint dwFlags;
		public uint dwDoubleClick;
		[MarshalAs(UnmanagedType.BStr)] public string pchHostCss;
		[MarshalAs(UnmanagedType.BStr)] public string pchHostNS;
	}
	#endregion

	#region RECT, tagMSG, refresh
	/// <summary>
	/// Contains message information from a thread's message queue. 
	/// </summary>
	/// <remarks>See <see href="http://msdn.microsoft.com/library/default.asp?url=/library/en-us/winui/winui/windowsuserinterface/windowing/messagesandmessagequeues/messagesandmessagequeuesreference/messageandmessagequeuestructures/msg.asp">MSDN</see></remarks>
	[StructLayout( LayoutKind.Sequential )]
	public struct tagMSG
	{
		public IntPtr hwnd;
		public uint message;
		public uint wParam;
		public int lParam;
		public uint time;
		public tagPOINT pt;
	}

	[StructLayout(LayoutKind.Sequential)]
	internal struct RECT
	{
		public int left;
		public int top;
		public int right;
		public int bottom;
	}
	#endregion

	#region For find/inet options
	[StructLayout(LayoutKind.Sequential)]
	internal struct OLECMDTEXT
	{
		public uint cmdtextf;
		public uint cwActual;
		public uint cwBuf;
		[MarshalAs(UnmanagedType.ByValTStr,SizeConst=100)]public char rgwz;
	}

	[StructLayout(LayoutKind.Sequential)]
	internal struct OLECMD
	{
		public uint cmdID;
		public uint cmdf;
	}

	// Interop definition for IOleCommandTarget.
	[ComImport]
	[Guid("b722bccb-4e68-101b-a2bc-00aa00404770")]
	[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
	internal interface IOleCommandTarget
	{
		//IMPORTANT: The order of the methods is critical here. You
		//perform early binding in most cases, so the order of the methods
		//here MUST match the order of their vtable layout (which is determined
		//by their layout in IDL). The interop calls key off the vtable ordering,
		//not the symbolic names. Therefore, if you switched these method declarations
		//and tried to call the Exec method on an IOleCommandTarget interface from your
		//application, it would translate into a call to the QueryStatus method instead.
		void QueryStatus(ref Guid pguidCmdGroup, UInt32 cCmds,
			[MarshalAs(UnmanagedType.LPArray, SizeParamIndex=1)] OLECMD[] prgCmds, ref OLECMDTEXT CmdText);
		void Exec(ref Guid pguidCmdGroup, uint nCmdId, uint nCmdExecOpt, ref object pvaIn, ref object pvaOut);
	}

	internal enum MiscCommandTarget
	{
		Find = 1,
		ViewSource,
		Options
	}
	#endregion

	#region Interfaces
	[ComImport()]
	[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
	[GuidAttribute("bd3f23c0-d43e-11cf-893b-00aa00bdce1a")]
	internal interface IDocHostUIHandler
	{
		[PreserveSig]
		uint ShowContextMenu(uint dwID, ref tagPOINT ppt,
			[MarshalAs(UnmanagedType.IUnknown)]  object pcmdtReserved,
			[MarshalAs(UnmanagedType.IDispatch)] object pdispReserved);


		void GetHostInfo(ref DOCHOSTUIINFO pInfo);
		void ShowUI(uint dwID, ref object pActiveObject, ref object pCommandTarget, ref object pFrame, ref object pDoc);
		void HideUI();
		void UpdateUI();
		void EnableModeless(int fEnable);
		void OnDocWindowActivate(int fActivate);
		void OnFrameWindowActivate(int fActivate);
		void ResizeBorder(ref tagRECT prcBorder, int pUIWindow, int fRameWindow);


		[PreserveSig]
		uint TranslateAccelerator(ref tagMSG lpMsg, ref Guid pguidCmdGroup, uint nCmdID);


		void GetOptionKeyPath([MarshalAs(UnmanagedType.BStr)] ref string pchKey, uint dw);
		object GetDropTarget(ref object pDropTarget);


		[PreserveSig]
		int GetExternal([MarshalAs(UnmanagedType.IDispatch)] out object ppDispatch);


		[PreserveSig]
		uint TranslateUrl(uint dwTranslate, 
			[MarshalAs(UnmanagedType.BStr)] string pchURLIn,
			[MarshalAs(UnmanagedType.BStr)] ref string ppchURLOut);


		IDataObject FilterDataObject(IDataObject pDO);
	}

	[ComVisible(true), Guid("00000118-0000-0000-C000-000000000046"),
	InterfaceTypeAttribute(ComInterfaceType.InterfaceIsIUnknown)]
	internal interface IOleClientSite
	{
		[return: MarshalAs(UnmanagedType.I4)][PreserveSig]
		int SaveObject();
		[return: MarshalAs(UnmanagedType.I4)][PreserveSig]
		int GetMoniker([In, MarshalAs(UnmanagedType.U4)] uint dwAssign, 
			[In,MarshalAs(UnmanagedType.U4)] uint dwWhichMoniker, 
			[Out,MarshalAs(UnmanagedType.Interface)] out Object ppmk);
		[return: MarshalAs(UnmanagedType.I4)][PreserveSig]
		int GetContainer([Out] out IOleContainer ppContainer);
		[return: MarshalAs(UnmanagedType.I4)][PreserveSig]
		int ShowObject();
		[return: MarshalAs(UnmanagedType.I4)][PreserveSig]
		int OnShowWindow([In, MarshalAs(UnmanagedType.I4)] int fShow);
		[return: MarshalAs(UnmanagedType.I4)][PreserveSig]
		int RequestNewObjectLayout();
	}

	[ComVisible(true), Guid("0000011B-0000-0000-C000-000000000046"),
	InterfaceTypeAttribute(ComInterfaceType.InterfaceIsIUnknown)]
	internal interface IOleContainer
	{
		[return: MarshalAs(UnmanagedType.I4)][PreserveSig]
		int ParseDisplayName([In, MarshalAs(UnmanagedType.Interface)] Object pbc,
			[In, MarshalAs(UnmanagedType.LPWStr)] String pszDisplayName, [Out,
			MarshalAs(UnmanagedType.LPArray)] int[] pchEaten, [Out,
			MarshalAs(UnmanagedType.LPArray)] Object[] ppmkOut);
		[return: MarshalAs(UnmanagedType.I4)][PreserveSig]
		int EnumObjects([In, MarshalAs(UnmanagedType.U4)] uint grfFlags, [Out,
			MarshalAs(UnmanagedType.LPArray)] Object[] ppenum);
		[return: MarshalAs(UnmanagedType.I4)][PreserveSig]
		int LockContainer([In, MarshalAs(UnmanagedType.Bool)] Boolean fLock);
	}

	[ComVisible(true), ComImport(),
	Guid("00000112-0000-0000-C000-000000000046"),
	InterfaceTypeAttribute(ComInterfaceType.InterfaceIsIUnknown)]
	internal interface IOleObject
	{
		[return: MarshalAs(UnmanagedType.I4)][PreserveSig]
		int SetClientSite([In, MarshalAs(UnmanagedType.Interface)] IOleClientSite
			pClientSite);
		[return: MarshalAs(UnmanagedType.I4)][PreserveSig]
		int GetClientSite([Out, MarshalAs(UnmanagedType.Interface)] out IOleClientSite site);
		[return: MarshalAs(UnmanagedType.I4)][PreserveSig]
		int SetHostNames([In, MarshalAs(UnmanagedType.LPWStr)] String
			szContainerApp, [In, MarshalAs(UnmanagedType.LPWStr)] String
			szContainerObj);
		[return: MarshalAs(UnmanagedType.I4)][PreserveSig]
		int Close([In,MarshalAs(UnmanagedType.U4)] uint dwSaveOption);
		[return: MarshalAs(UnmanagedType.I4)][PreserveSig]
		int SetMoniker([In, MarshalAs(UnmanagedType.U4)] uint dwWhichMoniker, [In,
			MarshalAs(UnmanagedType.Interface)] Object pmk);
		[return: MarshalAs(UnmanagedType.I4)][PreserveSig]
		int GetMoniker([In, MarshalAs(UnmanagedType.U4)] uint dwAssign, [In,
			MarshalAs(UnmanagedType.U4)] uint dwWhichMoniker,[Out,MarshalAs(UnmanagedType.Interface)] out Object moniker);
		[return: MarshalAs(UnmanagedType.I4)][PreserveSig]
		int InitFromData([In, MarshalAs(UnmanagedType.Interface)] Object
			pDataObject, [In, MarshalAs(UnmanagedType.Bool)] Boolean fCreation, [In,
			MarshalAs(UnmanagedType.U4)] uint dwReserved);
		int GetClipboardData([In, MarshalAs(UnmanagedType.U4)] uint dwReserved, out
			Object data);
		[return: MarshalAs(UnmanagedType.I4)][PreserveSig]
		int DoVerb([In, MarshalAs(UnmanagedType.I4)] int iVerb, [In] IntPtr lpmsg,
			[In, MarshalAs(UnmanagedType.Interface)] IOleClientSite pActiveSite, [In,
			MarshalAs(UnmanagedType.I4)] int lindex, [In] IntPtr hwndParent, [In] RECT
			lprcPosRect);
		[return: MarshalAs(UnmanagedType.I4)][PreserveSig]
		int EnumVerbs(out Object e); // IEnumOLEVERB
		[return: MarshalAs(UnmanagedType.I4)][PreserveSig]
		int OleUpdate();
		[return: MarshalAs(UnmanagedType.I4)][PreserveSig]
		int IsUpToDate();
		[return: MarshalAs(UnmanagedType.I4)][PreserveSig]
		int GetUserClassID([In, Out] ref Guid pClsid);
		[return: MarshalAs(UnmanagedType.I4)][PreserveSig]
		int GetUserType([In, MarshalAs(UnmanagedType.U4)] uint dwFormOfType, [Out,
			MarshalAs(UnmanagedType.LPWStr)] out String userType);
		[return: MarshalAs(UnmanagedType.I4)][PreserveSig]
		int SetExtent([In, MarshalAs(UnmanagedType.U4)] uint dwDrawAspect, [In]
			Object pSizel); // tagSIZEL
		[return: MarshalAs(UnmanagedType.I4)][PreserveSig]
		int GetExtent([In, MarshalAs(UnmanagedType.U4)] uint dwDrawAspect, [Out]
			Object pSizel); // tagSIZEL
		[return: MarshalAs(UnmanagedType.I4)][PreserveSig]
		int Advise([In, MarshalAs(UnmanagedType.Interface)] IAdviseSink pAdvSink, out
			int cookie);
		[return: MarshalAs(UnmanagedType.I4)][PreserveSig]
		int Unadvise([In, MarshalAs(UnmanagedType.U4)] int dwConnection);
		[return: MarshalAs(UnmanagedType.I4)][PreserveSig]
		int EnumAdvise(out Object e);
		[return: MarshalAs(UnmanagedType.I4)][PreserveSig]
		int GetMiscStatus([In, MarshalAs(UnmanagedType.U4)] uint dwAspect, out int
			misc);
		[return: MarshalAs(UnmanagedType.I4)][PreserveSig]
		int SetColorScheme([In] Object pLogpal); // tagLOGPALETTE
	}

	[ComImport(), InterfaceType(ComInterfaceType.InterfaceIsIUnknown),
	GuidAttribute("3050f3f0-98b5-11cf-bb82-00aa00bdce0b")]
	internal interface ICustomDoc
	{
		[PreserveSig]
		void SetUIHandler(IDocHostUIHandler pUIHandler);
	}

	[ComVisible(true), Guid("0000010f-0000-0000-C000-000000000046"),
	InterfaceTypeAttribute(ComInterfaceType.InterfaceIsIUnknown)]
	internal interface IAdviseSink
	{
		void OnDataChange(
			[In] object pFormatetc,
			[In] object pStgmed
			);
		void OnViewChange(
			[In,MarshalAs(UnmanagedType.U4)] int dwAspect,
			[In,MarshalAs(UnmanagedType.I4)] int lindex
			);
		void OnRename(
			[In, MarshalAs(UnmanagedType.Interface)] UCOMIMoniker pmk 
			);
		void OnSave();
		void OnClose();
	}
	#endregion

	#endregion

	#region EventHandlers
	/// <summary>
	/// Represents the method that will handle general WebBrowserEx events.
	/// </summary>
	public delegate void WebBrowserExEventHandler(object sender,WebBrowserExEventArgs e);

	/// <summary>
	/// Represents the method that will handle WebBrowserEx MouseDown events.
	/// </summary>
	public delegate void WebBrowserExMouseEventHandler(object sender,WebBrowserExMouseEventArgs e);

	/// <summary>
	/// Represents the method that will handle WebBrowserEx key events.
	/// </summary>
	public delegate void WebBrowserExKeyEventHandler(object sender,WebBrowserExKeyEventArgs e);
	#endregion

	#region EventArgs
	/// <summary>
	/// Provides data for the various web browser events.
	/// </summary>
	public class WebBrowserExEventArgs
	{
		/// <summary>
		/// Creates a new instance of WebBrowserExEventArgs.
		/// </summary>
		/// <param name="htmlEventObj">The original object passed to the event by the browser control.</param>
		public WebBrowserExEventArgs(IHTMLEventObj htmlEventObj)
		{
			this.HtmlEventObj = htmlEventObj;
		}

		/// <summary>
		/// Gets or set the original object passed to the event by the browser control.
		/// </summary>
		public mshtml.IHTMLEventObj HtmlEventObj
		{
			get
			{
				return this._htmlEventObj;
			}
			set
			{
				this._htmlEventObj = value;
			}
		}
	
		private mshtml.IHTMLEventObj _htmlEventObj;	
	}

	/// <summary>
	/// Provides data for handling HTML document key events.
	/// </summary>
	public class WebBrowserExKeyEventArgs : KeyEventArgs
	{
		/// <summary>
		/// Creates a new instance of WebBrowserExKeyEventArgs.
		/// </summary>
		public WebBrowserExKeyEventArgs(Keys keyData) : base(keyData)
		{

		}

		/// <summary>
		/// Creates a new instance of WebBrowserExKeyEventArgs.
		/// </summary>
		public WebBrowserExKeyEventArgs(Keys keyData,IHTMLEventObj htmlEventObj) : base(keyData)
		{
			this.HtmlEventObj = htmlEventObj;
		}

		/// <summary>
		/// Gets or set the original object passed to the event by the browser control.
		/// </summary>
		public mshtml.IHTMLEventObj HtmlEventObj
		{
			get
			{
				return this._htmlEventObj;
			}
			set
			{
				this._htmlEventObj = value;
			}
		}
	
		private mshtml.IHTMLEventObj _htmlEventObj;	
	}

	/// <summary>
	/// Provides data for HTML document key events.
	/// </summary>
	public class WebBrowserExMouseEventArgs : MouseEventArgs
	{
		/// <summary>
		/// Creates a new instance of WebBrowserExMouseEventArgs.
		/// </summary>
		public WebBrowserExMouseEventArgs(MouseButtons button,int clicks,int x,int y,int delta) : base(button,clicks,x,y,delta)
		{

		}

		/// <summary>
		/// Creates a new instance of WebBrowserExMouseEventArgs.
		/// </summary>
		public WebBrowserExMouseEventArgs(MouseButtons button,int clicks,int x,int y,int delta,IHTMLEventObj htmlEventObj) : base(button,clicks,x,y,delta)
		{
			this.HtmlEventObj = htmlEventObj;
		}

		/// <summary>
		/// Gets or set the original object passed to the event by the browser control.
		/// </summary>
		public mshtml.IHTMLEventObj HtmlEventObj
		{
			get
			{
				return this._htmlEventObj;
			}
			set
			{
				this._htmlEventObj = value;
			}
		}
	
		private mshtml.IHTMLEventObj _htmlEventObj;	
	}
	#endregion

	#region Flags UITypeEditor
	/// <summary>
	/// Implements a custom type editor for selecting an enumeration from in a list.
	/// From http://www.codeproject.com/cs/miscctrl/flagseditor.asp
	/// </summary>
	public class FlagsEditor : UITypeEditor
	{
		/// <summary>
		/// Internal class used for storing custom data in listviewitems
		/// </summary>
		internal class clbItem
		{
			/// <summary>
			/// Creates a new instance of the <c>clbItem</c>
			/// </summary>
			/// <param name="str">The string to display in the <c>ToString</c> method. 
			/// It will contains the name of the flag</param>
			/// <param name="value">The integer value of the flag</param>
			/// <param name="tooltip">The tooltip to display in the <see cref="CheckedListBox"/></param>
			public clbItem(string str, uint value, string tooltip)
			{
				this.str = str;
				this.value = value;
				this.tooltip = tooltip;
			}

			private string str;

			private uint value;
			/// <summary>
			/// Gets the int value for this item
			/// </summary>
			public uint Value
			{
				get{return value;}
			}

			private string tooltip;

			/// <summary>
			/// Gets the tooltip for this item
			/// </summary>
			public string Tooltip
			{
				get{return tooltip;}
			}

			/// <summary>
			/// Gets the name of this item
			/// </summary>
			/// <returns>The name passed in the constructor</returns>
			public override string ToString()
			{
				return str;
			}
		}

		private IWindowsFormsEditorService edSvc = null;
		private CheckedListBox clb;
		private ToolTip tooltipControl;

		/// <summary>
		/// Overrides the method used to provide basic behaviour for selecting editor.
		/// Shows our custom control for editing the value.
		/// </summary>
		/// <param name="context">The context of the editing control</param>
		/// <param name="provider">A valid service provider</param>
		/// <param name="value">The current value of the object to edit</param>
		/// <returns>The new value of the object</returns>
		public override object EditValue(ITypeDescriptorContext context, IServiceProvider provider, object value) 
		{
			if (context != null
				&& context.Instance != null
				&& provider != null) 
			{

				edSvc = (IWindowsFormsEditorService)provider.GetService(typeof(IWindowsFormsEditorService));

				if (edSvc != null) 
				{					
					// Create a CheckedListBox and populate it with all the enum values
					clb = new CheckedListBox();
					clb.BorderStyle = BorderStyle.FixedSingle;
					clb.CheckOnClick = true;
					clb.MouseDown += new MouseEventHandler(this.OnMouseDown);
					clb.MouseMove += new MouseEventHandler(this.OnMouseMoved);

					tooltipControl = new ToolTip();
					tooltipControl.ShowAlways = true;

					foreach(string name in Enum.GetNames(context.PropertyDescriptor.PropertyType))
					{
						// Get the enum value
						object enumVal = Enum.Parse(context.PropertyDescriptor.PropertyType, name);
						// Get the int value 
						uint intVal = (uint) Convert.ChangeType(enumVal, typeof(uint));
					
						// Get the description attribute for this field
						System.Reflection.FieldInfo fi = context.PropertyDescriptor.PropertyType.GetField(name);
						DescriptionAttribute[] attrs = (DescriptionAttribute[]) fi.GetCustomAttributes(typeof(DescriptionAttribute), false);

						// Store the the description
						string tooltip = attrs.Length > 0 ? attrs[0].Description : string.Empty;

						// Get the int value of the current enum value (the one being edited)
						uint intEdited = (uint) Convert.ChangeType(value, typeof(uint));

						// Creates a clbItem that stores the name, the int value and the tooltip
						clbItem item = new clbItem(enumVal.ToString(), intVal, tooltip);

						// Get the checkstate from the value being edited
						bool checkedItem = (intEdited & intVal) > 0;

						// Add the item with the right check state
						clb.Items.Add(item,checkedItem);
					}					

					// Show our CheckedListbox as a DropDownControl. 
					// This methods returns only when the dropdowncontrol is closed
					edSvc.DropDownControl(clb);

					// Get the sum of all checked flags
					uint result = 0;
					foreach(clbItem obj in clb.CheckedItems)
					{
						result += obj.Value;
					}
				
					// return the right enum value corresponding to the result
					return Enum.ToObject(context.PropertyDescriptor.PropertyType, result);
				}
			}

			return value;
		}

		/// <summary>
		/// Shows a dropdown icon in the property editor
		/// </summary>
		/// <param name="context">The context of the editing control</param>
		/// <returns>Returns <c>UITypeEditorEditStyle.DropDown</c></returns>
		public override UITypeEditorEditStyle GetEditStyle(ITypeDescriptorContext context) 
		{
			return UITypeEditorEditStyle.DropDown;			
		}

		private bool handleLostfocus = false;

		/// <summary>
		/// When got the focus, handle the lost focus event.
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void OnMouseDown(object sender, MouseEventArgs e) 
		{
			if(!handleLostfocus && clb.ClientRectangle.Contains(clb.PointToClient(new Point(e.X, e.Y))))
			{
				clb.LostFocus += new EventHandler(this.ValueChanged);
				handleLostfocus = true;
			}
		}

		/// <summary>
		/// Occurs when the mouse is moved over the checkedlistbox. 
		/// Sets the tooltip of the item under the pointer
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void OnMouseMoved(object sender, MouseEventArgs e) 
		{			
			int index = clb.IndexFromPoint(e.X, e.Y);
			if(index >= 0)
				tooltipControl.SetToolTip(clb, ((clbItem) clb.Items[index]).Tooltip);
		}

		/// <summary>
		/// Close the dropdowncontrol when the user has selected a value
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void ValueChanged(object sender, EventArgs e) 
		{
			if (edSvc != null) 
			{
				edSvc.CloseDropDown();
			}
		}
	}
	#endregion
}
