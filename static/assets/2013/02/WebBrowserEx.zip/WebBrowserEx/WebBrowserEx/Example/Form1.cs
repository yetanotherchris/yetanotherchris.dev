using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Diagnostics;
using System.Runtime.InteropServices;
using Sloppycode.Controls;

namespace WebBrowserExExample
{

	public class MainForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.CheckBox checkBoxScrollbars;
		private System.Windows.Forms.CheckBox checkBoxXPThemed;
		private System.Windows.Forms.CheckBox checkBox3DBorder;
		private System.Windows.Forms.StatusBar statusBar1;
		private System.Windows.Forms.TextBox textBoxAddress;
		private System.Windows.Forms.Button buttonPrint;
		private System.Windows.Forms.Button buttonSaveAs;
		private System.Windows.Forms.Button buttonWriteHtml;
		private System.Windows.Forms.ContextMenu contextMenu1;
		private System.Windows.Forms.MenuItem menuItem1;
		private Sloppycode.Controls.WebBrowserEx webBrowserEx1;
		private System.Windows.Forms.Button buttonPageProperties;
		private System.Windows.Forms.Button buttonFind;
		private System.Windows.Forms.Button buttonPrintPreview;
		private System.Windows.Forms.Button buttonGo;
		private System.Windows.Forms.CheckBox checkBoxContextMenu;
		private System.Windows.Forms.CheckBox checkBoxHtmlEvents;
		private System.Windows.Forms.Button buttonViewSource;
		private System.Windows.Forms.Panel panelTop;
		private System.Windows.Forms.Panel panelLeft;
		private System.ComponentModel.IContainer components = null;
    
		public MainForm()
		{
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		[STAThread]
		static void Main() 
		{
			Application.EnableVisualStyles();
			Application.Run(new MainForm());
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.panelTop = new System.Windows.Forms.Panel();
			this.buttonGo = new System.Windows.Forms.Button();
			this.textBoxAddress = new System.Windows.Forms.TextBox();
			this.panelLeft = new System.Windows.Forms.Panel();
			this.buttonViewSource = new System.Windows.Forms.Button();
			this.checkBoxHtmlEvents = new System.Windows.Forms.CheckBox();
			this.checkBoxContextMenu = new System.Windows.Forms.CheckBox();
			this.buttonPageProperties = new System.Windows.Forms.Button();
			this.buttonFind = new System.Windows.Forms.Button();
			this.buttonPrintPreview = new System.Windows.Forms.Button();
			this.buttonPrint = new System.Windows.Forms.Button();
			this.buttonSaveAs = new System.Windows.Forms.Button();
			this.buttonWriteHtml = new System.Windows.Forms.Button();
			this.checkBox3DBorder = new System.Windows.Forms.CheckBox();
			this.checkBoxXPThemed = new System.Windows.Forms.CheckBox();
			this.checkBoxScrollbars = new System.Windows.Forms.CheckBox();
			this.statusBar1 = new System.Windows.Forms.StatusBar();
			this.contextMenu1 = new System.Windows.Forms.ContextMenu();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.webBrowserEx1 = new Sloppycode.Controls.WebBrowserEx();
			this.panelTop.SuspendLayout();
			this.panelLeft.SuspendLayout();
			this.SuspendLayout();
			// 
			// panelTop
			// 
			this.panelTop.Controls.Add(this.buttonGo);
			this.panelTop.Controls.Add(this.textBoxAddress);
			this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
			this.panelTop.Location = new System.Drawing.Point(0, 0);
			this.panelTop.Name = "panelTop";
			this.panelTop.Size = new System.Drawing.Size(728, 28);
			this.panelTop.TabIndex = 1;
			// 
			// buttonGo
			// 
			this.buttonGo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonGo.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonGo.Location = new System.Drawing.Point(678, 2);
			this.buttonGo.Name = "buttonGo";
			this.buttonGo.Size = new System.Drawing.Size(42, 23);
			this.buttonGo.TabIndex = 3;
			this.buttonGo.Text = "go";
			this.buttonGo.Click += new System.EventHandler(this.buttonGo_Click);
			// 
			// textBoxAddress
			// 
			this.textBoxAddress.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.textBoxAddress.Location = new System.Drawing.Point(8, 3);
			this.textBoxAddress.Name = "textBoxAddress";
			this.textBoxAddress.Size = new System.Drawing.Size(656, 20);
			this.textBoxAddress.TabIndex = 2;
			this.textBoxAddress.Text = "http://www.sloppycode.net/sloppycode";
			this.textBoxAddress.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxAddress_KeyDown);
			// 
			// panelLeft
			// 
			this.panelLeft.Controls.Add(this.buttonViewSource);
			this.panelLeft.Controls.Add(this.checkBoxHtmlEvents);
			this.panelLeft.Controls.Add(this.checkBoxContextMenu);
			this.panelLeft.Controls.Add(this.buttonPageProperties);
			this.panelLeft.Controls.Add(this.buttonFind);
			this.panelLeft.Controls.Add(this.buttonPrintPreview);
			this.panelLeft.Controls.Add(this.buttonPrint);
			this.panelLeft.Controls.Add(this.buttonSaveAs);
			this.panelLeft.Controls.Add(this.buttonWriteHtml);
			this.panelLeft.Controls.Add(this.checkBox3DBorder);
			this.panelLeft.Controls.Add(this.checkBoxXPThemed);
			this.panelLeft.Controls.Add(this.checkBoxScrollbars);
			this.panelLeft.Dock = System.Windows.Forms.DockStyle.Left;
			this.panelLeft.Location = new System.Drawing.Point(0, 28);
			this.panelLeft.Name = "panelLeft";
			this.panelLeft.Size = new System.Drawing.Size(176, 388);
			this.panelLeft.TabIndex = 3;
			// 
			// buttonViewSource
			// 
			this.buttonViewSource.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonViewSource.Location = new System.Drawing.Point(8, 352);
			this.buttonViewSource.Name = "buttonViewSource";
			this.buttonViewSource.Size = new System.Drawing.Size(125, 23);
			this.buttonViewSource.TabIndex = 16;
			this.buttonViewSource.Text = "View source";
			this.buttonViewSource.Click += new System.EventHandler(this.buttonViewSource_Click);
			// 
			// checkBoxHtmlEvents
			// 
			this.checkBoxHtmlEvents.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.checkBoxHtmlEvents.Location = new System.Drawing.Point(8, 104);
			this.checkBoxHtmlEvents.Name = "checkBoxHtmlEvents";
			this.checkBoxHtmlEvents.Size = new System.Drawing.Size(152, 21);
			this.checkBoxHtmlEvents.TabIndex = 15;
			this.checkBoxHtmlEvents.Text = "Register HTML events";
			this.checkBoxHtmlEvents.CheckedChanged += new System.EventHandler(this.checkBoxHtmlEvents_CheckedChanged);
			// 
			// checkBoxContextMenu
			// 
			this.checkBoxContextMenu.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.checkBoxContextMenu.Location = new System.Drawing.Point(8, 80);
			this.checkBoxContextMenu.Name = "checkBoxContextMenu";
			this.checkBoxContextMenu.Size = new System.Drawing.Size(160, 24);
			this.checkBoxContextMenu.TabIndex = 13;
			this.checkBoxContextMenu.Text = "Use custom context menu";
			this.checkBoxContextMenu.CheckedChanged += new System.EventHandler(this.checkBoxContextMenu_CheckedChanged);
			// 
			// buttonPageProperties
			// 
			this.buttonPageProperties.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonPageProperties.Location = new System.Drawing.Point(8, 320);
			this.buttonPageProperties.Name = "buttonPageProperties";
			this.buttonPageProperties.Size = new System.Drawing.Size(125, 25);
			this.buttonPageProperties.TabIndex = 9;
			this.buttonPageProperties.Text = "Show page properties";
			this.buttonPageProperties.Click += new System.EventHandler(this.buttonPageProperties_Click);
			// 
			// buttonFind
			// 
			this.buttonFind.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonFind.Location = new System.Drawing.Point(8, 288);
			this.buttonFind.Name = "buttonFind";
			this.buttonFind.Size = new System.Drawing.Size(125, 25);
			this.buttonFind.TabIndex = 8;
			this.buttonFind.Text = "Find";
			this.buttonFind.Click += new System.EventHandler(this.buttonFind_Click);
			// 
			// buttonPrintPreview
			// 
			this.buttonPrintPreview.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonPrintPreview.Location = new System.Drawing.Point(8, 256);
			this.buttonPrintPreview.Name = "buttonPrintPreview";
			this.buttonPrintPreview.Size = new System.Drawing.Size(125, 25);
			this.buttonPrintPreview.TabIndex = 7;
			this.buttonPrintPreview.Text = "Print preview";
			this.buttonPrintPreview.Click += new System.EventHandler(this.buttonPrintPreview_Click);
			// 
			// buttonPrint
			// 
			this.buttonPrint.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonPrint.Location = new System.Drawing.Point(8, 224);
			this.buttonPrint.Name = "buttonPrint";
			this.buttonPrint.Size = new System.Drawing.Size(125, 25);
			this.buttonPrint.TabIndex = 6;
			this.buttonPrint.Text = "Print";
			this.buttonPrint.Click += new System.EventHandler(this.buttonPrint_Click);
			// 
			// buttonSaveAs
			// 
			this.buttonSaveAs.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonSaveAs.Location = new System.Drawing.Point(8, 192);
			this.buttonSaveAs.Name = "buttonSaveAs";
			this.buttonSaveAs.Size = new System.Drawing.Size(125, 25);
			this.buttonSaveAs.TabIndex = 5;
			this.buttonSaveAs.Text = "Save As";
			this.buttonSaveAs.Click += new System.EventHandler(this.buttonSaveAs_Click);
			// 
			// buttonWriteHtml
			// 
			this.buttonWriteHtml.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonWriteHtml.Location = new System.Drawing.Point(8, 160);
			this.buttonWriteHtml.Name = "buttonWriteHtml";
			this.buttonWriteHtml.Size = new System.Drawing.Size(125, 25);
			this.buttonWriteHtml.TabIndex = 4;
			this.buttonWriteHtml.Text = "Write some HTML";
			this.buttonWriteHtml.Click += new System.EventHandler(this.buttonWriteHtml_Click);
			// 
			// checkBox3DBorder
			// 
			this.checkBox3DBorder.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.checkBox3DBorder.Location = new System.Drawing.Point(8, 55);
			this.checkBox3DBorder.Name = "checkBox3DBorder";
			this.checkBox3DBorder.TabIndex = 3;
			this.checkBox3DBorder.Text = "3D Border";
			this.checkBox3DBorder.CheckedChanged += new System.EventHandler(this.checkBox3DBorder_CheckedChanged);
			// 
			// checkBoxXPThemed
			// 
			this.checkBoxXPThemed.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.checkBoxXPThemed.Location = new System.Drawing.Point(8, 31);
			this.checkBoxXPThemed.Name = "checkBoxXPThemed";
			this.checkBoxXPThemed.TabIndex = 2;
			this.checkBoxXPThemed.Text = "XP Themed";
			this.checkBoxXPThemed.CheckedChanged += new System.EventHandler(this.checkBoxXPThemed_CheckedChanged);
			// 
			// checkBoxScrollbars
			// 
			this.checkBoxScrollbars.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.checkBoxScrollbars.Location = new System.Drawing.Point(8, 8);
			this.checkBoxScrollbars.Name = "checkBoxScrollbars";
			this.checkBoxScrollbars.TabIndex = 0;
			this.checkBoxScrollbars.Text = "Scrollbars";
			this.checkBoxScrollbars.CheckedChanged += new System.EventHandler(this.checkBoxScrollbars_CheckedChanged);
			// 
			// statusBar1
			// 
			this.statusBar1.Location = new System.Drawing.Point(0, 416);
			this.statusBar1.Name = "statusBar1";
			this.statusBar1.Size = new System.Drawing.Size(728, 22);
			this.statusBar1.TabIndex = 5;
			// 
			// contextMenu1
			// 
			this.contextMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						 this.menuItem1});
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.Text = "Do something";
			// 
			// webBrowserEx1
			// 
			this.webBrowserEx1.AddressBar = true;
			this.webBrowserEx1.Border3D = false;
			this.webBrowserEx1.DisableBackSpace = false;
			this.webBrowserEx1.DisableCtrlF = false;
			this.webBrowserEx1.DisableCtrlN = false;
			this.webBrowserEx1.DisableCtrlP = false;
			this.webBrowserEx1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.webBrowserEx1.EnableHtmlDocumentEventHandling = false;
			this.webBrowserEx1.FlatScrollBar = false;
			this.webBrowserEx1.FullScreen = false;
			this.webBrowserEx1.Location = new System.Drawing.Point(176, 28);
			this.webBrowserEx1.Name = "webBrowserEx1";
			this.webBrowserEx1.Offline = false;
			this.webBrowserEx1.OpenInNewWindow = false;
			this.webBrowserEx1.Options = Sloppycode.Controls.BrowserOptions.Images;
			this.webBrowserEx1.RegisterAsBrowser = false;
			this.webBrowserEx1.RegisterAsDropTarget = true;
			this.webBrowserEx1.ScrollBarsVisible = false;
			this.webBrowserEx1.ShowWebsiteInDesigner = false;
			this.webBrowserEx1.Silent = false;
			this.webBrowserEx1.Size = new System.Drawing.Size(552, 388);
			this.webBrowserEx1.TabIndex = 6;
			this.webBrowserEx1.TheaterMode = false;
			this.webBrowserEx1.Url = null;
			this.webBrowserEx1.XPThemed = false;
			// 
			// MainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(728, 438);
			this.Controls.Add(this.webBrowserEx1);
			this.Controls.Add(this.panelLeft);
			this.Controls.Add(this.panelTop);
			this.Controls.Add(this.statusBar1);
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "WebBrowserEx Example";
			this.panelTop.ResumeLayout(false);
			this.panelLeft.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void checkBoxScrollbars_CheckedChanged(object sender, System.EventArgs e)
		{
			this.webBrowserEx1.ScrollBarsVisible = this.checkBoxScrollbars.Checked;
		}

		private void checkBoxFlatScrollbars_CheckedChanged(object sender, System.EventArgs e)
		{
			this.webBrowserEx1.ScrollBarsVisible = this.checkBoxScrollbars.Checked;
		}

		private void checkBoxXPThemed_CheckedChanged(object sender, System.EventArgs e)
		{
			this.webBrowserEx1.XPThemed = this.checkBoxXPThemed.Checked;
		}

		private void checkBox3DBorder_CheckedChanged(object sender, System.EventArgs e)
		{
			this.webBrowserEx1.Border3D = this.checkBox3DBorder.Checked;
		}

		private void buttonWriteHtml_Click(object sender, System.EventArgs e)
		{
			this.webBrowserEx1.CurrentDocument.write("<html><a href=http://www.yahoo.com>click here</a></html>");
		}

		private void buttonSaveAs_Click(object sender, System.EventArgs e)
		{
			this.webBrowserEx1.SaveAs("monkey.html");
		}

		private void buttonPrint_Click(object sender, System.EventArgs e)
		{
			this.webBrowserEx1.Print(true);
		}

		private void webBrowserEx1_HtmlDocumentMouseOver(object sender, WebBrowserExMouseEventArgs e)
		{
			this.statusBar1.Text = "HTML document event: Mouse over - x:" +e.X+",y:"+e.Y;
		}

		private void buttonPrintPreview_Click(object sender, System.EventArgs e)
		{
			this.webBrowserEx1.PrintPreview();
		}

		private void buttonFind_Click(object sender, System.EventArgs e)
		{
			this.webBrowserEx1.Find();
		}

		private void buttonPageProperties_Click(object sender, System.EventArgs e)
		{
			this.webBrowserEx1.ShowPageProperties();
		}

		private void textBoxAddress_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Return) 
				this.webBrowserEx1.Navigate(textBoxAddress.Text);
		}

		private void buttonGo_Click(object sender, System.EventArgs e)
		{
			this.webBrowserEx1.Navigate(textBoxAddress.Text);
		}


		private void checkBoxContextMenu_CheckedChanged(object sender, System.EventArgs e)
		{
			if ( this.checkBoxContextMenu.Checked )
				this.webBrowserEx1.ContextMenu = this.contextMenu1;
			else
				this.webBrowserEx1.ContextMenu = null;
		}

		private void checkBoxHtmlEvents_CheckedChanged(object sender, System.EventArgs e)
		{
			this.webBrowserEx1.EnableHtmlDocumentEventHandling = this.checkBoxHtmlEvents.Checked;
			this.statusBar1.Text = "";
			this.webBrowserEx1.Refresh(RefreshType.IfExpired);
		}

		private void buttonViewSource_Click(object sender, System.EventArgs e)
		{
			this.webBrowserEx1.ViewSource();
		}
	}
}
