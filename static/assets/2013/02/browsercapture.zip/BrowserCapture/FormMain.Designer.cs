﻿namespace BrowserCapture
{
	partial class FormMain
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this._buttonStart = new System.Windows.Forms.Button();
			this._checkBoxClose = new System.Windows.Forms.CheckBox();
			this._labelWidth = new System.Windows.Forms.Label();
			this._labelHeight = new System.Windows.Forms.Label();
			this._labelFolder = new System.Windows.Forms.Label();
			this._textBoxPath = new System.Windows.Forms.TextBox();
			this._buttonExplore = new System.Windows.Forms.Button();
			this._groupBox1 = new System.Windows.Forms.GroupBox();
			this._textBoxPathOpera = new System.Windows.Forms.TextBox();
			this._textBoxSafariPath = new System.Windows.Forms.TextBox();
			this._textBoxFirefoxPath = new System.Windows.Forms.TextBox();
			this._textBoxIePath = new System.Windows.Forms.TextBox();
			this._labelWebsite = new System.Windows.Forms.Label();
			this._textBoxWebsite = new System.Windows.Forms.TextBox();
			this._labelWait2b = new System.Windows.Forms.Label();
			this._maskedTextBoxWait2 = new System.Windows.Forms.MaskedTextBox();
			this._labelWait2a = new System.Windows.Forms.Label();
			this._labelWait1b = new System.Windows.Forms.Label();
			this._maskedTextBoxWait1 = new System.Windows.Forms.MaskedTextBox();
			this._labelWait1a = new System.Windows.Forms.Label();
			this._checkBoxOpera = new System.Windows.Forms.CheckBox();
			this._checkBoxSafari = new System.Windows.Forms.CheckBox();
			this._checkBoxFF2 = new System.Windows.Forms.CheckBox();
			this._checkBoxIE7 = new System.Windows.Forms.CheckBox();
			this._maskedTextBoxWidth = new System.Windows.Forms.MaskedTextBox();
			this._maskedTextBoxHeight = new System.Windows.Forms.MaskedTextBox();
			this._folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
			this._groupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// _buttonStart
			// 
			this._buttonStart.Location = new System.Drawing.Point(374, 333);
			this._buttonStart.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this._buttonStart.Name = "_buttonStart";
			this._buttonStart.Size = new System.Drawing.Size(75, 28);
			this._buttonStart.TabIndex = 0;
			this._buttonStart.Text = "Start";
			this._buttonStart.UseVisualStyleBackColor = true;
			this._buttonStart.Click += new System.EventHandler(this.buttonStart_Click);
			// 
			// _checkBoxClose
			// 
			this._checkBoxClose.AutoSize = true;
			this._checkBoxClose.Checked = true;
			this._checkBoxClose.CheckState = System.Windows.Forms.CheckState.Checked;
			this._checkBoxClose.Location = new System.Drawing.Point(7, 118);
			this._checkBoxClose.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this._checkBoxClose.Name = "_checkBoxClose";
			this._checkBoxClose.Size = new System.Drawing.Size(157, 20);
			this._checkBoxClose.TabIndex = 1;
			this._checkBoxClose.Text = "Close all browsers on exit?";
			this._checkBoxClose.UseVisualStyleBackColor = true;
			// 
			// _labelWidth
			// 
			this._labelWidth.AutoSize = true;
			this._labelWidth.Location = new System.Drawing.Point(6, 93);
			this._labelWidth.Name = "_labelWidth";
			this._labelWidth.Size = new System.Drawing.Size(42, 16);
			this._labelWidth.TabIndex = 4;
			this._labelWidth.Text = "Width:";
			// 
			// _labelHeight
			// 
			this._labelHeight.AutoSize = true;
			this._labelHeight.Location = new System.Drawing.Point(86, 93);
			this._labelHeight.Name = "_labelHeight";
			this._labelHeight.Size = new System.Drawing.Size(45, 16);
			this._labelHeight.TabIndex = 5;
			this._labelHeight.Text = "Height:";
			// 
			// _labelFolder
			// 
			this._labelFolder.AutoSize = true;
			this._labelFolder.Location = new System.Drawing.Point(5, 50);
			this._labelFolder.Name = "_labelFolder";
			this._labelFolder.Size = new System.Drawing.Size(96, 16);
			this._labelFolder.TabIndex = 6;
			this._labelFolder.Text = "Screenshot folder";
			// 
			// _textBoxPath
			// 
			this._textBoxPath.Location = new System.Drawing.Point(108, 47);
			this._textBoxPath.Name = "_textBoxPath";
			this._textBoxPath.Size = new System.Drawing.Size(276, 20);
			this._textBoxPath.TabIndex = 7;
			this._textBoxPath.Text = "c:\\";
			// 
			// _buttonExplore
			// 
			this._buttonExplore.Location = new System.Drawing.Point(390, 47);
			this._buttonExplore.Name = "_buttonExplore";
			this._buttonExplore.Size = new System.Drawing.Size(30, 23);
			this._buttonExplore.TabIndex = 8;
			this._buttonExplore.Text = "...";
			this._buttonExplore.UseVisualStyleBackColor = true;
			this._buttonExplore.Click += new System.EventHandler(this.buttonExplore_Click);
			// 
			// _groupBox1
			// 
			this._groupBox1.Controls.Add(this._textBoxPathOpera);
			this._groupBox1.Controls.Add(this._textBoxSafariPath);
			this._groupBox1.Controls.Add(this._textBoxFirefoxPath);
			this._groupBox1.Controls.Add(this._textBoxIePath);
			this._groupBox1.Controls.Add(this._labelWebsite);
			this._groupBox1.Controls.Add(this._textBoxWebsite);
			this._groupBox1.Controls.Add(this._labelWait2b);
			this._groupBox1.Controls.Add(this._maskedTextBoxWait2);
			this._groupBox1.Controls.Add(this._labelWait2a);
			this._groupBox1.Controls.Add(this._labelWait1b);
			this._groupBox1.Controls.Add(this._maskedTextBoxWait1);
			this._groupBox1.Controls.Add(this._labelWait1a);
			this._groupBox1.Controls.Add(this._checkBoxOpera);
			this._groupBox1.Controls.Add(this._checkBoxSafari);
			this._groupBox1.Controls.Add(this._checkBoxFF2);
			this._groupBox1.Controls.Add(this._checkBoxIE7);
			this._groupBox1.Controls.Add(this._labelFolder);
			this._groupBox1.Controls.Add(this._buttonExplore);
			this._groupBox1.Controls.Add(this._checkBoxClose);
			this._groupBox1.Controls.Add(this._textBoxPath);
			this._groupBox1.Controls.Add(this._maskedTextBoxWidth);
			this._groupBox1.Controls.Add(this._maskedTextBoxHeight);
			this._groupBox1.Controls.Add(this._labelHeight);
			this._groupBox1.Controls.Add(this._labelWidth);
			this._groupBox1.Location = new System.Drawing.Point(12, 12);
			this._groupBox1.Name = "_groupBox1";
			this._groupBox1.Size = new System.Drawing.Size(437, 314);
			this._groupBox1.TabIndex = 9;
			this._groupBox1.TabStop = false;
			// 
			// _textBoxPathOpera
			// 
			this._textBoxPathOpera.Location = new System.Drawing.Point(108, 232);
			this._textBoxPathOpera.Name = "_textBoxPathOpera";
			this._textBoxPathOpera.Size = new System.Drawing.Size(276, 20);
			this._textBoxPathOpera.TabIndex = 24;
			this._textBoxPathOpera.Text = "C:\\Program Files\\Opera\\opera.exe";
			// 
			// _textBoxSafariPath
			// 
			this._textBoxSafariPath.Location = new System.Drawing.Point(108, 207);
			this._textBoxSafariPath.Name = "_textBoxSafariPath";
			this._textBoxSafariPath.Size = new System.Drawing.Size(276, 20);
			this._textBoxSafariPath.TabIndex = 23;
			this._textBoxSafariPath.Text = "C:\\Program Files\\Safari\\safari.exe";
			// 
			// _textBoxFirefoxPath
			// 
			this._textBoxFirefoxPath.Location = new System.Drawing.Point(108, 182);
			this._textBoxFirefoxPath.Name = "_textBoxFirefoxPath";
			this._textBoxFirefoxPath.Size = new System.Drawing.Size(276, 20);
			this._textBoxFirefoxPath.TabIndex = 22;
			this._textBoxFirefoxPath.Text = "firefox";
			// 
			// _textBoxIePath
			// 
			this._textBoxIePath.Location = new System.Drawing.Point(108, 156);
			this._textBoxIePath.Name = "_textBoxIePath";
			this._textBoxIePath.Size = new System.Drawing.Size(276, 20);
			this._textBoxIePath.TabIndex = 21;
			this._textBoxIePath.Text = "iexplore";
			// 
			// _labelWebsite
			// 
			this._labelWebsite.AutoSize = true;
			this._labelWebsite.Location = new System.Drawing.Point(5, 22);
			this._labelWebsite.Name = "_labelWebsite";
			this._labelWebsite.Size = new System.Drawing.Size(49, 16);
			this._labelWebsite.TabIndex = 19;
			this._labelWebsite.Text = "Website";
			// 
			// _textBoxWebsite
			// 
			this._textBoxWebsite.Location = new System.Drawing.Point(108, 19);
			this._textBoxWebsite.Name = "_textBoxWebsite";
			this._textBoxWebsite.Size = new System.Drawing.Size(276, 20);
			this._textBoxWebsite.TabIndex = 20;
			this._textBoxWebsite.Text = "http://www.sloppycode.net";
			// 
			// _labelWait2b
			// 
			this._labelWait2b.AutoSize = true;
			this._labelWait2b.Location = new System.Drawing.Point(83, 283);
			this._labelWait2b.Name = "_labelWait2b";
			this._labelWait2b.Size = new System.Drawing.Size(191, 16);
			this._labelWait2b.TabIndex = 18;
			this._labelWait2b.Text = "seconds for screenshots to be taken";
			// 
			// _maskedTextBoxWait2
			// 
			this._maskedTextBoxWait2.Location = new System.Drawing.Point(42, 282);
			this._maskedTextBoxWait2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this._maskedTextBoxWait2.Mask = "00";
			this._maskedTextBoxWait2.Name = "_maskedTextBoxWait2";
			this._maskedTextBoxWait2.Size = new System.Drawing.Size(35, 20);
			this._maskedTextBoxWait2.TabIndex = 16;
			this._maskedTextBoxWait2.Text = "5";
			// 
			// _labelWait2a
			// 
			this._labelWait2a.AutoSize = true;
			this._labelWait2a.Location = new System.Drawing.Point(4, 283);
			this._labelWait2a.Name = "_labelWait2a";
			this._labelWait2a.Size = new System.Drawing.Size(32, 16);
			this._labelWait2a.TabIndex = 17;
			this._labelWait2a.Text = "Wait";
			// 
			// _labelWait1b
			// 
			this._labelWait1b.AutoSize = true;
			this._labelWait1b.Location = new System.Drawing.Point(209, 259);
			this._labelWait1b.Name = "_labelWait1b";
			this._labelWait1b.Size = new System.Drawing.Size(48, 16);
			this._labelWait1b.TabIndex = 15;
			this._labelWait1b.Text = "seconds";
			// 
			// _maskedTextBoxWait1
			// 
			this._maskedTextBoxWait1.Location = new System.Drawing.Point(171, 257);
			this._maskedTextBoxWait1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this._maskedTextBoxWait1.Mask = "00";
			this._maskedTextBoxWait1.Name = "_maskedTextBoxWait1";
			this._maskedTextBoxWait1.Size = new System.Drawing.Size(35, 20);
			this._maskedTextBoxWait1.TabIndex = 13;
			this._maskedTextBoxWait1.Text = "10";
			// 
			// _labelWait1a
			// 
			this._labelWait1a.AutoSize = true;
			this._labelWait1a.Location = new System.Drawing.Point(4, 260);
			this._labelWait1a.Name = "_labelWait1a";
			this._labelWait1a.Size = new System.Drawing.Size(166, 16);
			this._labelWait1a.TabIndex = 14;
			this._labelWait1a.Text = "Wait for browsers to launch for";
			// 
			// _checkBoxOpera
			// 
			this._checkBoxOpera.AutoSize = true;
			this._checkBoxOpera.Location = new System.Drawing.Point(7, 229);
			this._checkBoxOpera.Name = "_checkBoxOpera";
			this._checkBoxOpera.Size = new System.Drawing.Size(58, 20);
			this._checkBoxOpera.TabIndex = 12;
			this._checkBoxOpera.Text = "Opera";
			this._checkBoxOpera.UseVisualStyleBackColor = true;
			// 
			// _checkBoxSafari
			// 
			this._checkBoxSafari.AutoSize = true;
			this._checkBoxSafari.Location = new System.Drawing.Point(7, 207);
			this._checkBoxSafari.Name = "_checkBoxSafari";
			this._checkBoxSafari.Size = new System.Drawing.Size(56, 20);
			this._checkBoxSafari.TabIndex = 11;
			this._checkBoxSafari.Text = "Safari";
			this._checkBoxSafari.UseVisualStyleBackColor = true;
			// 
			// _checkBoxFF2
			// 
			this._checkBoxFF2.AutoSize = true;
			this._checkBoxFF2.Checked = true;
			this._checkBoxFF2.CheckState = System.Windows.Forms.CheckState.Checked;
			this._checkBoxFF2.Location = new System.Drawing.Point(7, 182);
			this._checkBoxFF2.Name = "_checkBoxFF2";
			this._checkBoxFF2.Size = new System.Drawing.Size(82, 20);
			this._checkBoxFF2.TabIndex = 10;
			this._checkBoxFF2.Text = "Firefox 2.0";
			this._checkBoxFF2.UseVisualStyleBackColor = true;
			// 
			// _checkBoxIE7
			// 
			this._checkBoxIE7.AutoSize = true;
			this._checkBoxIE7.Checked = true;
			this._checkBoxIE7.CheckState = System.Windows.Forms.CheckState.Checked;
			this._checkBoxIE7.Location = new System.Drawing.Point(7, 156);
			this._checkBoxIE7.Name = "_checkBoxIE7";
			this._checkBoxIE7.Size = new System.Drawing.Size(43, 20);
			this._checkBoxIE7.TabIndex = 9;
			this._checkBoxIE7.Text = "IE7";
			this._checkBoxIE7.UseVisualStyleBackColor = true;
			// 
			// _maskedTextBoxWidth
			// 
			this._maskedTextBoxWidth.Location = new System.Drawing.Point(48, 90);
			this._maskedTextBoxWidth.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this._maskedTextBoxWidth.Mask = "0000";
			this._maskedTextBoxWidth.Name = "_maskedTextBoxWidth";
			this._maskedTextBoxWidth.Size = new System.Drawing.Size(31, 20);
			this._maskedTextBoxWidth.TabIndex = 2;
			this._maskedTextBoxWidth.Text = "1024";
			// 
			// _maskedTextBoxHeight
			// 
			this._maskedTextBoxHeight.Location = new System.Drawing.Point(129, 90);
			this._maskedTextBoxHeight.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this._maskedTextBoxHeight.Mask = "0000";
			this._maskedTextBoxHeight.Name = "_maskedTextBoxHeight";
			this._maskedTextBoxHeight.Size = new System.Drawing.Size(35, 20);
			this._maskedTextBoxHeight.TabIndex = 3;
			this._maskedTextBoxHeight.Text = "768";
			// 
			// FormMain
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(464, 373);
			this.Controls.Add(this._groupBox1);
			this.Controls.Add(this._buttonStart);
			this.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.MaximizeBox = false;
			this.Name = "FormMain";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Multiple browser screenshot capture";
			this._groupBox1.ResumeLayout(false);
			this._groupBox1.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Button _buttonStart;
		private System.Windows.Forms.CheckBox _checkBoxClose;
		private System.Windows.Forms.Label _labelWidth;
		private System.Windows.Forms.Label _labelHeight;
		private System.Windows.Forms.Label _labelFolder;
		private System.Windows.Forms.TextBox _textBoxPath;
		private System.Windows.Forms.Button _buttonExplore;
		private System.Windows.Forms.GroupBox _groupBox1;
		private System.Windows.Forms.CheckBox _checkBoxSafari;
		private System.Windows.Forms.CheckBox _checkBoxFF2;
		private System.Windows.Forms.CheckBox _checkBoxIE7;
		private System.Windows.Forms.FolderBrowserDialog _folderBrowserDialog1;
		private System.Windows.Forms.CheckBox _checkBoxOpera;
		private System.Windows.Forms.Label _labelWait2b;
		private System.Windows.Forms.Label _labelWait2a;
		private System.Windows.Forms.Label _labelWait1b;
		private System.Windows.Forms.Label _labelWait1a;
		private System.Windows.Forms.MaskedTextBox _maskedTextBoxWait2;
		private System.Windows.Forms.MaskedTextBox _maskedTextBoxWait1;
		private System.Windows.Forms.MaskedTextBox _maskedTextBoxWidth;
		private System.Windows.Forms.MaskedTextBox _maskedTextBoxHeight;
		private System.Windows.Forms.Label _labelWebsite;
		private System.Windows.Forms.TextBox _textBoxWebsite;
		private System.Windows.Forms.TextBox _textBoxPathOpera;
		private System.Windows.Forms.TextBox _textBoxSafariPath;
		private System.Windows.Forms.TextBox _textBoxFirefoxPath;
		private System.Windows.Forms.TextBox _textBoxIePath;
	}
}

