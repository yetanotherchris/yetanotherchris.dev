DataProducer ASP Component
Version 1.00

� C.Small  2000-2001
Bugs + info: sloppycode@sloppycode.net
Website: www.sloppycode.net

Contents
========

1. Introduction
2. Installation
3. Documentation
4. Example usage

1. Introduction
---------------
Dataproducer, available for php,java servlets and asp is used to seperate the presentation layer from the data layer in web applications. With it you can specify single and multiple row tags inside a html template, which are then replaced with data that you specify. Please note this is the first version of the class and features little error handling. More features and error handling will appear in the next version.

2. Installation
---------------
To install this ASP Component for PWS or IIS 4/5, first copy it to your favourite directory, then enter the command prompt by using Start>Run>Command.com (or cmd in Win2k). Use the 'CD' (change directory) command to navigate the directory where you stored the DLL file, and then type

regsvr32 DataProducer.dll

This should register the ASP Component as ready to use by your computer.

3. Documentation
---------------
See the manual.html file that comes with this package.

4. Example Usage
---------------
Example usage can be found in the example.asp file that comes with this package. An example of using the DataProducer component with an Access database can be found in the dbexample.asp file.