using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Runtime.InteropServices;


namespace RichTextBoxCaretExample
{
	public class Form1 : System.Windows.Forms.Form
	{
		#region Components
		private System.Windows.Forms.RichTextBox richTextBox1;
		private System.Windows.Forms.ImageList imageList1;
		private System.Windows.Forms.StatusBar statusBar1;
		private System.Windows.Forms.StatusBarPanel statusBarPanel1;
		private System.Windows.Forms.StatusBarPanel statusBarPanel2;
		private System.Windows.Forms.StatusBarPanel statusBarPanel3;
		private System.ComponentModel.IContainer components;
		#endregion

		#region Constructor, dispose, main
		public Form1()
		{
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}
		#endregion

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.richTextBox1 = new System.Windows.Forms.RichTextBox();
			this.imageList1 = new System.Windows.Forms.ImageList(this.components);
			this.statusBar1 = new System.Windows.Forms.StatusBar();
			this.statusBarPanel1 = new System.Windows.Forms.StatusBarPanel();
			this.statusBarPanel2 = new System.Windows.Forms.StatusBarPanel();
			this.statusBarPanel3 = new System.Windows.Forms.StatusBarPanel();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel2)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel3)).BeginInit();
			this.SuspendLayout();
			// 
			// richTextBox1
			// 
			this.richTextBox1.AcceptsTab = true;
			this.richTextBox1.BackColor = System.Drawing.Color.Black;
			this.richTextBox1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.richTextBox1.Font = new System.Drawing.Font("Courier New", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.richTextBox1.ForeColor = System.Drawing.Color.Silver;
			this.richTextBox1.Location = new System.Drawing.Point(0, 0);
			this.richTextBox1.Name = "richTextBox1";
			this.richTextBox1.Size = new System.Drawing.Size(544, 344);
			this.richTextBox1.TabIndex = 0;
			this.richTextBox1.Text = "";
			this.richTextBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.richTextBox1_KeyDown);
			this.richTextBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.richTextBox1_MouseDown);
			this.richTextBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.richTextBox1_KeyPress);
			this.richTextBox1.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
			this.richTextBox1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.richTextBox1_MouseUp);
			// 
			// imageList1
			// 
			this.imageList1.ImageSize = new System.Drawing.Size(8, 16);
			this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
			this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// statusBar1
			// 
			this.statusBar1.Location = new System.Drawing.Point(0, 344);
			this.statusBar1.Name = "statusBar1";
			this.statusBar1.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
																						  this.statusBarPanel1,
																						  this.statusBarPanel2,
																						  this.statusBarPanel3});
			this.statusBar1.ShowPanels = true;
			this.statusBar1.Size = new System.Drawing.Size(544, 22);
			this.statusBar1.TabIndex = 2;
			this.statusBar1.Text = "statusBar1";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(544, 366);
			this.Controls.Add(this.richTextBox1);
			this.Controls.Add(this.statusBar1);
			this.Name = "Form1";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Telnet style demo app";
			this.Resize += new System.EventHandler(this.Form1_Resize);
			this.Load += new System.EventHandler(this.Form1_Load);
			this.Validating += new System.ComponentModel.CancelEventHandler(this.Form1_Validating);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);
			this.Enter += new System.EventHandler(this.Form1_Enter);
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel2)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel3)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		#region Winapi imports
		[DllImport("user32.dll")]
		public static extern int CreateCaret(IntPtr hwnd, IntPtr hbm, int cx, int cy);

		[DllImport("user32.dll")]
		public static extern int DestroyCaret();

		[DllImport("user32.dll")]
		public static extern int SetCaretPos(int x, int y);

		[DllImport("user32.dll")]
		public static extern int ShowCaret(IntPtr hwnd);

		[DllImport("user32.dll")]
		public static extern int HideCaret(IntPtr hwnd);

		[DllImport("User32.Dll")]
		public static extern int SendMessage(IntPtr hWnd,int Msg,int  wParam,int  lParam);   
		public const int EM_LINEINDEX = 0xBB;
		#endregion

		#region Private fields
		private Bitmap bm;
		private int currentCol;
		private int currentRow;
		private string prefix = "bash$ ";
		private ArrayList lookupTable;
		private int charPos = 0;
		#endregion

		#region Events
		private void Form1_Load(object sender, System.EventArgs e)
		{
			bm = new Bitmap(this.imageList1.Images[0]);
			this.richTextBox1.Clear();

			this.lookupTable = new ArrayList();
			lookupTable.Add("program files");
			lookupTable.Add("windows");
			lookupTable.Add("autoexec.bat");
			lookupTable.Add("hello.bat");
			lookupTable.Add("help");
		}

		
		private void richTextBox1_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			getposition();

			if ( e.KeyChar == 9 )
				e.Handled = true;
			else
				charPos = 0;
		}

		private void richTextBox1_TextChanged(object sender, System.EventArgs e)
		{
			showhidecaret();
		}

		private void richTextBox1_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
		{
			if ( (e.KeyCode == Keys.Back || e.KeyCode == Keys.Left) && currentCol == prefix.Length +1)
			{
				e.Handled = true;
			}

			if ( e.KeyCode == Keys.Down || e.KeyCode == Keys.Up )
			{
				e.Handled = true;
			}

			if ( e.KeyCode == Keys.Return ) 
			{
				e.Handled = true;
				this.richTextBox1.Text += "\r\n" +prefix;
				this.richTextBox1.Select(this.richTextBox1.Text.Length,0);
			}

			if ( e.KeyCode == Keys.Tab )
			{
				string s = this.getlastword();
				if ( s != "" )
				{
					if ( charPos == 0 )
						charPos = this.richTextBox1.Text.Length;

					this.statusBarPanel3.Text = s;

					char final = s[0];
					string fin = final +"";
					
					int n = -1;
					for (int i=0;i < lookupTable.Count;i++)
					{
						// See if it's in our lookup table
						if ( lookupTable[i].ToString().StartsWith(fin) )
						{
							n = i;
							break;
						}
					}

					if ( n != -1 )
					{
						string add = (string) lookupTable[n];
						add = add.Replace(s,"");

						if ( this.richTextBox1.Text.Length > charPos )
							this.statusBarPanel3.Text = charPos + "";

						this.richTextBox1.Text += add;
						this.richTextBox1.Select(this.richTextBox1.Text.Length,0);
					}
				}
			}

			showhidecaret();
		}
		#endregion

		#region Helpers
		private string getlastword()
		{
			string word = "";

			// Should always be on the last line
			int pos = this.richTextBox1.Text.Length;
			if ( pos > 1 )
			{
				
				string tmp = "";
				char f = new char();
				while ( f != ' ' )
				{
					pos--;
					tmp = this.richTextBox1.Text.Substring(pos,1);
					f = (char) tmp[0];
					word += f;
					
				}

				char[] ca = word.ToCharArray();
				Array.Reverse( ca );
				word = new String( ca );

			}
			return word.Trim();
			
		}

		// Had a lot of problems with the showhidecaret() method here - the caret was dissapearing when
		// it wasn't meant to, so I've stuck it everywhere for now as a temporary measure.
		private void getposition()
		{
			currentRow = richTextBox1.GetLineFromCharIndex(richTextBox1.SelectionStart)+1;
			this.statusBarPanel1.Text = "Row: " + currentRow; 

			richTextBox1.GetCharIndexFromPosition(richTextBox1.GetPositionFromCharIndex(richTextBox1.SelectionStart));   
			int rowStartIndex = SendMessage(richTextBox1.Handle, EM_LINEINDEX, -1, 0);
			currentCol = richTextBox1.SelectionStart - rowStartIndex+1;

			this.statusBarPanel2.Text = "Column:" + currentCol; 
		}
		#endregion

		#region Ensuring the caret behaves
		private void showhidecaret()
		{
			HideCaret(this.richTextBox1.Handle);
			CreateCaret(this.richTextBox1.Handle,this.bm.GetHbitmap(),8,16);
			ShowCaret(this.richTextBox1.Handle);
		}

		private void richTextBox1_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			this.richTextBox1.Select(this.richTextBox1.Text.Length,0);
			showhidecaret();
		}

		private void richTextBox1_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			this.richTextBox1.Select(this.richTextBox1.Text.Length,0);
			showhidecaret();
		}

		private void Form1_Validating(object sender, System.ComponentModel.CancelEventArgs e)
		{
			showhidecaret();
		}

		private void Form1_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			this.richTextBox1.Text = this.prefix;
			this.richTextBox1.Select(6,1);
			this.richTextBox1.Select(6,0);
			showhidecaret();
		}

		private void Form1_Resize(object sender, System.EventArgs e)
		{
			showhidecaret();
		}

		private void Form1_Enter(object sender, System.EventArgs e)
		{
			showhidecaret();
		}
		#endregion
	}
}
