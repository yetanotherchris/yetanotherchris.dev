TWinampApi Class
Version 1.00

� C.Small  2000-2001
Bugs + info: sloppycode@sloppycode.net
Website: www.sloppycode.net

Contents
========

1. Introduction
2. Installation
3. Documentation
4. Example usage

1. Introduction
---------------
TWinampApi can be used for controlling open instances of winamp. It features methods and properties for controlling most aspects of winamp. This can then be used for remote control of winamp running on a seperate machine (e.g. a server running as a stereo). An instance of the class is created using one parameter - the path to winamp, which is used for writing out the current playlist. This class works with Winamp 2.x, and may work with Winamp 3.x unless Nullsoft have changed their API. Winamp can be downloaded from www.winamp.com - definitely recommended.

2. Installation
---------------
Unzip the ZIP file, and include "WinampApi.pas" in the uses clause of your Delphi application.

3. Documentation
---------------
See the manual.html file that comes with this package.

4. Example Usage
---------------
Example usage can be found in the "winampAPI-test" folder