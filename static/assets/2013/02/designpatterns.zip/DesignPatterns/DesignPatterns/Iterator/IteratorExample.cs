﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace DesignPatterns
{
    public class IteratorExample : IEnumerable
    {
        Dictionary<string, string> _dictionary;

        public IteratorExample()
        {
            // Add 5 names to a key/value pair list.
            _dictionary = new Dictionary<string, string>();
            _dictionary.Add("Hans", "Pisces");
            _dictionary.Add("Fred", "Aquarius");
            _dictionary.Add("Andrew", "Gemini");
            _dictionary.Add("Zach", "Scorpio");
            _dictionary.Add("Berfa", "Cancer");
        }

        /// <summary>
        /// Demonstrates yield with IEnumerable.
        /// </summary>
        public IEnumerator GetEnumerator()
        {
            // Sort by name
            var sorted = from d in _dictionary orderby d.Key select d;

            // Iterate through the sorted collection
            foreach (KeyValuePair<string, string> item in sorted)
            {
                yield return item.Key;
                yield return string.Format("({0})",item.Value);
            }
        }
    }
}
