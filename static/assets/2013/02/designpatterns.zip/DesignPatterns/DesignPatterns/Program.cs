﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesignPatterns
{
    class Program
    {
        private static void Main(string[] args)
        {
            AbstractFactoryTest();
            Console.ReadLine();
        }

        private static void FactoryTest()
        {
            // Very basic test with a GIF
            PluginFactory factory = new PluginFactory();
            Console.WriteLine(factory.ShowFileDetails("gif"));
        }

        private static void AbstractFactoryTest()
        {
            AbstractPluginFactory factory = AbstractPluginFactory.GetFactory("ASPX");
            factory.Renderer.DrawImage("blah.gif");

            factory = AbstractPluginFactory.GetFactory("Winforms");
            factory.Renderer.DrawImage("blah.gif");
        }

        private static void StrategyTest()
        {
            // 5 dummy users
            User user1 = new User() { Name = "Hans", Age = 61 };
            User user2 = new User() { Name = "Fred", Age = 52 };
            User user3 = new User() { Name = "Andrew", Age = 15 };
            User user4 = new User() { Name = "Zäch", Age = 22 };
            User user5 = new User() { Name = "Zâch", Age = 8 };

            List<User> users = new List<User>();
            users.Add(user1);
            users.Add(user2);
            users.Add(user3);
            users.Add(user4);
            users.Add(user5);

            // Sort by name
            Console.WriteLine("Sorted by name:");
            users.Sort(new NameSorter());
            Console.WriteLine(users.Print());

            // Sort by age
            Console.WriteLine("Sorted by age:");
            users.Sort(new AgeSorter());
            Console.WriteLine(users.Print());
        }

        private static void IteratorTest()
        {
            IteratorExample example = new IteratorExample();
            foreach (string item in example)
            {
                Console.WriteLine(item);
            }
        }

        private static void MediatorTest()
        {
            Mediator mediator = new Mediator();

            // 3 test people
            Person person1 = new Person(mediator, "Chris");
            Person person2 = new Person(mediator, "John");
            Person person3 = new Person(mediator, "Michael");

            // Chris says hello to everyone.
            person1.Send("Hallo everybody!");
        }

        private static void ObserverTest()
        {
            // 2 observers for the subject, the 2nd observer
            // filters the messages
            Subject subject = new Subject();

            Observer observer1 = new Observer(subject, "First observer");
            Observer observer2 = new Observer(subject, "Second observer");
            observer2.MessageFilter = "Finding"; // any message beginning with 'Finding'

            subject.Run();
        }

        private static void StateTest()
        {
            State state = new SittingState();

            // Do some actions
            Console.WriteLine(state.SitDown(state));
            Console.WriteLine(state.Run(state));
            Console.WriteLine(state.Walk(state));
            Console.WriteLine(state.SitDown(state));
        }
    }
}
