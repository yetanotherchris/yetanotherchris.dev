﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesignPatterns
{
    /// <summary>
    /// Default State that every state inherits from.
    /// </summary>
    public abstract class State
    {
        /// <summary>
        /// Holds the current state we're in.
        /// </summary>
        public State CurrentState
        { 
            get; 
            set; 
        }

        public virtual string SitDown(State context)
        {
            return "";
        }

        public virtual string Walk(State context)
        {
            return "";
        }

        public virtual string Run(State context)
        {
            return "";
        }
    }

    public class SittingState : State
    {
        public override string SitDown(State context)
        {
            context.CurrentState = new SittingState();
            return "Sitting down.";
        }

        public override string Walk(State context)
        {
            context.CurrentState = new WalkingState();
            return "I'm walking.";
        }

        public override string Run(State context)
        {
            return "I can't run while I'm sitting down.";
        }
    }

    /// <summary>
    /// WalkingState can move back and forward from sitting to running.
    /// </summary>
    public class WalkingState : State
    {
        public override string SitDown(State context)
        {
            context.CurrentState = new SittingState();
            return "Sitting down.";
        }

        public override string Walk(State context)
        {
            context.CurrentState = new WalkingState();
            return "I'm walking.";
        }

        public override string Run(State context)
        {
            context.CurrentState = new RunningState();
            return "I'm running.";
        }
    }

    public class RunningState : State
    {
        public override string SitDown(State context)
        {
            return "I can't sit down while I'm running (try slowing down first).";
        }

        public override string Walk(State context)
        {
            context.CurrentState = new WalkingState();
            return "I'm walking.";
        }

        public override string Run(State context)
        {
            context.CurrentState = new RunningState();
            return "I'm running.";
        }
    }

}
