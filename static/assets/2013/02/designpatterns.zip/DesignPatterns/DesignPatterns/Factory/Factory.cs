﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesignPatterns
{
    /// <summary>
    /// Defines the methods/properties the plugin can support.
    /// </summary>
    public interface IPlugin
    {
        string GetDetails();
    }

    /// <summary>
    /// A plugin for Gifs.
    /// </summary>
    public class GifHandler : IPlugin
    {
        public string GetDetails()
        {
            return "I'm a plugin for .GIF filetypes";
        }
    }

    /// <summary>
    /// A plugin for jpgs.
    /// </summary>
    public class JpgHandler : IPlugin
    {
        public string GetDetails()
        {
            return "I'm a plugin for  .JPG filetypes.";
        }
    }

    /// <summary>
    /// The class to handle extensions with.
    /// </summary>
    public class PluginFactory
    {
        public string ShowFileDetails(string extension)
        {
            IPlugin plugin = null;

            switch (extension)
            {
                case "gif":
                    plugin = new GifHandler();
                    break;
                case "jpg":
                    plugin = new JpgHandler();
                    break;
                default:
                    throw new NotSupportedException(string.Format("{0} is not supported.", extension));
            }

            return plugin.GetDetails();
        }
    }
}
