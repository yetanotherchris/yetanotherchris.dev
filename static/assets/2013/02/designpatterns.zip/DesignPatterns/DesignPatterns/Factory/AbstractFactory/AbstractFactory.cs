﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesignPatterns
{

    public abstract class AbstractPluginFactory
    {
        public static AbstractPluginFactory GetFactory(string renderer)
        {
            switch (renderer)
            {
                case "ASPX":
                    return new ASPXRendererFactory();
                case "Winforms":
                    return new WinformsRendererFactory();
                default:
                    throw new NotSupportedException(string.Format("{0} is not supported", renderer));
            }
        }

        public abstract Renderer Renderer { get; } 
    }

    public class ASPXRendererFactory : AbstractPluginFactory
    {
        private Renderer _renderer;

        public override Renderer Renderer
        {
            get
            {
                return _renderer;
            }
        }

        public ASPXRendererFactory()
        {
            // This could be a protected field in PluginFactory
            _renderer = new ASPXRenderer();
        }
    }

    public class WinformsRendererFactory : AbstractPluginFactory
    {
        private Renderer _renderer;

        public override Renderer Renderer
        {
            get
            {
                return _renderer;
            }
        }

        public WinformsRendererFactory()
        {
            // This could be a protected field in PluginFactory
            _renderer = new WinformsRenderer();
        }
    }

    public abstract class Renderer
    {
        public abstract void DrawImage(string filename);
    }

    public class WinformsRenderer : Renderer
    {
        public override void DrawImage(string filename)
        {
            // This would draw onto a canvas provided via
            // a Graphics object.
            Console.WriteLine("Drawing an image for Windows forms");
        }
    }

    public class ASPXRenderer : Renderer
    {
        public override void DrawImage(string filename)
        {
            // This would output an <img..> tag to the child controls or similar.
            Console.WriteLine("Drawing an image for ASP.NET");
        }
    }




}
