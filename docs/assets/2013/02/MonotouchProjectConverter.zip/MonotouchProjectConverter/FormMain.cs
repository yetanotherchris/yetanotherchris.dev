﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading;

namespace MonotouchProjectConverter
{
	public partial class FormMain : Form
	{
		static string ReferenceContent = @"<?xml version=""1.0"" encoding=""utf-8""?>
<Project ToolsVersion=""4.0"" xmlns=""http://schemas.microsoft.com/developer/msbuild/2003"">
  <PropertyGroup>
    <ReferencePath>{0}</ReferencePath>
  </PropertyGroup>
</Project>";

		public FormMain()
		{
			InitializeComponent();
		}

		private void _buttonMore_Click(object sender, EventArgs e)
		{
			OpenFileDialog dialog = new OpenFileDialog();
			dialog.Filter = "Project files|*.csproj";
			if (dialog.ShowDialog() == DialogResult.OK)
			{
				_textBoxProjectFile.Text = dialog.FileName;
			}
		}

		private void _buttonMoreAllProjects_Click(object sender, EventArgs e)
		{
			FolderBrowserDialog dialog = new FolderBrowserDialog();
			if (dialog.ShowDialog() == DialogResult.OK)
			{
				_textBoxProjectFile.Text = dialog.SelectedPath;
			}
		}

		private void _buttonConvertToVs_Click(object sender, EventArgs e)
		{
			_toolStripStatusLabel.Text = "Converting .csproj files...";

			Thread thread = new Thread(Convert);
			thread.Start(false);
		}

		private void _buttonConvertToMd_Click(object sender, EventArgs e)
		{
			_toolStripStatusLabel.Text = "Converting .csproj files...";
			Thread thread = new Thread(Convert);
			thread.Start(true);
		}

		private void Convert(object state)
		{
			if (InvokeRequired)
			{
				Invoke(new Action<object>(Convert), state);
				return;
			}

			bool isMonoDevelop = (bool)state;

			string path = _textBoxAllProjects.Text;

			if (!string.IsNullOrEmpty(path))
			{
				if (Directory.Exists(path))
				{
					_toolStripStatusLabel.Text = "Searching for .csproj files...";
					List<string> files = SearchFiles(path);
					
					foreach (string file in files)
					{
						ConvertProject(isMonoDevelop, file);
					}
					_toolStripStatusLabel.Text = "Done";
				}
			}
			else
			{
				ConvertProject(isMonoDevelop, _textBoxProjectFile.Text);
			}
		}

		private List<string> SearchFiles(string path)
		{
			List<string> files = new List<string>();
			foreach (string file in Directory.EnumerateFiles(path, "*.csproj", SearchOption.AllDirectories))
			{
				files.Add(file);
			}

			return files;
		}

		private void ConvertProject(bool toMonoDevelop, string csprojFile)
		{
			if (string.IsNullOrEmpty(csprojFile))
				return;

			if (!File.Exists(csprojFile))
			{
				MessageBox.Show("The project file no longer exists");
				return;
			}

			string content = File.ReadAllText(csprojFile);
			string backupFile = string.Format("{0}.converter.bak", csprojFile);

			// Make a backup of the project file
			File.Copy(csprojFile, backupFile, true);

			if (toMonoDevelop)
			{
				//
				// Swap the Monodevelop guids
				//
				//content = content.Replace("<ProjectGuid>{25B16A36-324E-4DB2-BCE9-85DF33504CD3}</ProjectGuid>", "<ProjectGuid>{95D28B03-E797-42C2-B5C6-B19D8C3D6670}</ProjectGuid>");
				content = content.Replace("<ProjectGuids />","<ProjectTypeGuids>{E613F3A2-FE9C-494F-B74E-F63BCB86FEA6};{FAE04EC0-301F-11D3-BF4B-00C04F79EFBC}</ProjectTypeGuids>");

				Regex regex = new Regex("<None Include=\"(.*).xib\" />");
				content = regex.Replace(content, "<Page Include=\"$1.xib\" />");

				File.WriteAllText(csprojFile, content);
			}
			else
			{
				//
				// Write to Visual Studio format
				//
				//content = content.Replace("<ProjectGuid>{95D28B03-E797-42C2-B5C6-B19D8C3D6670}</ProjectGuid>", "<ProjectGuid>{25B16A36-324E-4DB2-BCE9-85DF33504CD3}</ProjectGuid>");
				content = content.Replace("<ProjectTypeGuids>{E613F3A2-FE9C-494F-B74E-F63BCB86FEA6};{FAE04EC0-301F-11D3-BF4B-00C04F79EFBC}</ProjectTypeGuids>", "<ProjectGuids />");

				Regex regex = new Regex("<Page Include=\"(.*).xib\" />");
				content = regex.Replace(content, "<None Include=\"$1.xib\" />");

				File.WriteAllText(csprojFile,content);

				//
				// Add the userprefs file if it doesn't exist
				//
				string userprefs = string.Format("{0}.user", csprojFile);
				if (!File.Exists(userprefs))
				{
					string referenceContent = string.Format(ReferenceContent, @"C:\windows\monotouch");
					File.WriteAllText(userprefs, referenceContent);
				}
				else
				{
					_toolStripStatusLabel.Text = "The .user file already exists";	
				}
			}

			MessageBox.Show(string.Format("Converted {0}",Path.GetFileName(csprojFile)));
		}
	}
}
