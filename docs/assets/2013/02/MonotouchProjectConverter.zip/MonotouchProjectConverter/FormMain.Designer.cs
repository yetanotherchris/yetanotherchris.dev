﻿namespace MonotouchProjectConverter
{
	partial class FormMain
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
			this._textBoxProjectFile = new System.Windows.Forms.TextBox();
			this._buttonProjectMore = new System.Windows.Forms.Button();
			this._labelProjectFile = new System.Windows.Forms.Label();
			this._buttonConvertToVs = new System.Windows.Forms.Button();
			this._buttonConvertToMd = new System.Windows.Forms.Button();
			this._labelMonotouchDll = new System.Windows.Forms.Label();
			this.statusStrip1 = new System.Windows.Forms.StatusStrip();
			this._toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
			this._labelAllProjects = new System.Windows.Forms.Label();
			this._buttonMoreAllProjects = new System.Windows.Forms.Button();
			this._textBoxAllProjects = new System.Windows.Forms.TextBox();
			this.statusStrip1.SuspendLayout();
			this.SuspendLayout();
			// 
			// _textBoxProjectFile
			// 
			this._textBoxProjectFile.Location = new System.Drawing.Point(117, 16);
			this._textBoxProjectFile.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this._textBoxProjectFile.Name = "_textBoxProjectFile";
			this._textBoxProjectFile.Size = new System.Drawing.Size(194, 25);
			this._textBoxProjectFile.TabIndex = 0;
			// 
			// _buttonProjectMore
			// 
			this._buttonProjectMore.Location = new System.Drawing.Point(318, 13);
			this._buttonProjectMore.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this._buttonProjectMore.Name = "_buttonProjectMore";
			this._buttonProjectMore.Size = new System.Drawing.Size(29, 30);
			this._buttonProjectMore.TabIndex = 1;
			this._buttonProjectMore.Text = "...";
			this._buttonProjectMore.UseVisualStyleBackColor = true;
			this._buttonProjectMore.Click += new System.EventHandler(this._buttonMore_Click);
			// 
			// _labelProjectFile
			// 
			this._labelProjectFile.AutoSize = true;
			this._labelProjectFile.Location = new System.Drawing.Point(7, 19);
			this._labelProjectFile.Name = "_labelProjectFile";
			this._labelProjectFile.Size = new System.Drawing.Size(69, 17);
			this._labelProjectFile.TabIndex = 2;
			this._labelProjectFile.Text = "Project file";
			// 
			// _buttonConvertToVs
			// 
			this._buttonConvertToVs.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._buttonConvertToVs.Location = new System.Drawing.Point(82, 104);
			this._buttonConvertToVs.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this._buttonConvertToVs.Name = "_buttonConvertToVs";
			this._buttonConvertToVs.Size = new System.Drawing.Size(265, 51);
			this._buttonConvertToVs.TabIndex = 3;
			this._buttonConvertToVs.Text = "Convert to Visual Studio -->";
			this._buttonConvertToVs.UseVisualStyleBackColor = true;
			this._buttonConvertToVs.Click += new System.EventHandler(this._buttonConvertToVs_Click);
			// 
			// _buttonConvertToMd
			// 
			this._buttonConvertToMd.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._buttonConvertToMd.Location = new System.Drawing.Point(82, 163);
			this._buttonConvertToMd.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this._buttonConvertToMd.Name = "_buttonConvertToMd";
			this._buttonConvertToMd.Size = new System.Drawing.Size(265, 48);
			this._buttonConvertToMd.TabIndex = 4;
			this._buttonConvertToMd.Text = "<-- Convert to MonoDevelop";
			this._buttonConvertToMd.UseVisualStyleBackColor = true;
			this._buttonConvertToMd.Click += new System.EventHandler(this._buttonConvertToMd_Click);
			// 
			// _labelMonotouchDll
			// 
			this._labelMonotouchDll.AutoSize = true;
			this._labelMonotouchDll.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this._labelMonotouchDll.Location = new System.Drawing.Point(7, 83);
			this._labelMonotouchDll.Name = "_labelMonotouchDll";
			this._labelMonotouchDll.Size = new System.Drawing.Size(304, 13);
			this._labelMonotouchDll.TabIndex = 7;
			this._labelMonotouchDll.Text = "Monotouch.dll etc. are assumed to be c:\\windows\\monodevelop";
			// 
			// statusStrip1
			// 
			this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._toolStripStatusLabel});
			this.statusStrip1.Location = new System.Drawing.Point(0, 228);
			this.statusStrip1.Name = "statusStrip1";
			this.statusStrip1.Size = new System.Drawing.Size(369, 22);
			this.statusStrip1.TabIndex = 8;
			this.statusStrip1.Text = "statusStrip1";
			// 
			// _toolStripStatusLabel
			// 
			this._toolStripStatusLabel.Name = "_toolStripStatusLabel";
			this._toolStripStatusLabel.Size = new System.Drawing.Size(0, 17);
			// 
			// _labelAllProjects
			// 
			this._labelAllProjects.AutoSize = true;
			this._labelAllProjects.Location = new System.Drawing.Point(7, 53);
			this._labelAllProjects.Name = "_labelAllProjects";
			this._labelAllProjects.Size = new System.Drawing.Size(90, 17);
			this._labelAllProjects.TabIndex = 11;
			this._labelAllProjects.Text = "All projects in:";
			// 
			// _buttonMoreAllProjects
			// 
			this._buttonMoreAllProjects.Location = new System.Drawing.Point(318, 47);
			this._buttonMoreAllProjects.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this._buttonMoreAllProjects.Name = "_buttonMoreAllProjects";
			this._buttonMoreAllProjects.Size = new System.Drawing.Size(29, 30);
			this._buttonMoreAllProjects.TabIndex = 10;
			this._buttonMoreAllProjects.Text = "...";
			this._buttonMoreAllProjects.UseVisualStyleBackColor = true;
			this._buttonMoreAllProjects.Click += new System.EventHandler(this._buttonMoreAllProjects_Click);
			// 
			// _textBoxAllProjects
			// 
			this._textBoxAllProjects.Location = new System.Drawing.Point(117, 50);
			this._textBoxAllProjects.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this._textBoxAllProjects.Name = "_textBoxAllProjects";
			this._textBoxAllProjects.Size = new System.Drawing.Size(194, 25);
			this._textBoxAllProjects.TabIndex = 9;
			// 
			// FormMain
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(369, 250);
			this.Controls.Add(this._labelAllProjects);
			this.Controls.Add(this._buttonMoreAllProjects);
			this.Controls.Add(this._textBoxAllProjects);
			this.Controls.Add(this.statusStrip1);
			this.Controls.Add(this._labelMonotouchDll);
			this.Controls.Add(this._buttonConvertToMd);
			this.Controls.Add(this._buttonConvertToVs);
			this.Controls.Add(this._labelProjectFile);
			this.Controls.Add(this._buttonProjectMore);
			this.Controls.Add(this._textBoxProjectFile);
			this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.MaximizeBox = false;
			this.Name = "FormMain";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Monotouch to Visual Studio";
			this.statusStrip1.ResumeLayout(false);
			this.statusStrip1.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TextBox _textBoxProjectFile;
		private System.Windows.Forms.Button _buttonProjectMore;
		private System.Windows.Forms.Label _labelProjectFile;
		private System.Windows.Forms.Button _buttonConvertToVs;
		private System.Windows.Forms.Button _buttonConvertToMd;
		private System.Windows.Forms.Label _labelMonotouchDll;
		private System.Windows.Forms.StatusStrip statusStrip1;
		private System.Windows.Forms.ToolStripStatusLabel _toolStripStatusLabel;
		private System.Windows.Forms.Label _labelAllProjects;
		private System.Windows.Forms.Button _buttonMoreAllProjects;
		private System.Windows.Forms.TextBox _textBoxAllProjects;
	}
}

