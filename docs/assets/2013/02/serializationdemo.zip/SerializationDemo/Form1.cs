using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters;
using System.Runtime.Serialization.Formatters.Binary;


namespace SerializationDemo
{
	public class Form1 : System.Windows.Forms.Form
	{
		#region Components

		private System.Windows.Forms.ListView listView1;
		private System.Windows.Forms.ColumnHeader columnHeader1;
		private System.Windows.Forms.ColumnHeader columnHeader2;
		private System.Windows.Forms.Button buttonSerialize;
		private System.Windows.Forms.Button buttonDeSerialize;
		private System.Windows.Forms.ColumnHeader columnHeader3;
		private System.Windows.Forms.ColumnHeader columnHeader4;
		private System.ComponentModel.Container components = null;
		#endregion

		#region Constructor, dispose, main
		public Form1()
		{
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}
		#endregion

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.buttonSerialize = new System.Windows.Forms.Button();
			this.buttonDeSerialize = new System.Windows.Forms.Button();
			this.listView1 = new System.Windows.Forms.ListView();
			this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
			this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
			this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
			this.columnHeader4 = new System.Windows.Forms.ColumnHeader();
			this.SuspendLayout();
			// 
			// buttonSerialize
			// 
			this.buttonSerialize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.buttonSerialize.Location = new System.Drawing.Point(8, 288);
			this.buttonSerialize.Name = "buttonSerialize";
			this.buttonSerialize.Size = new System.Drawing.Size(128, 23);
			this.buttonSerialize.TabIndex = 0;
			this.buttonSerialize.Text = "Create data + serialize";
			this.buttonSerialize.Click += new System.EventHandler(this.buttonSerialize_Click);
			// 
			// buttonDeSerialize
			// 
			this.buttonDeSerialize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.buttonDeSerialize.Location = new System.Drawing.Point(144, 288);
			this.buttonDeSerialize.Name = "buttonDeSerialize";
			this.buttonDeSerialize.TabIndex = 1;
			this.buttonDeSerialize.Text = "Deserialize";
			this.buttonDeSerialize.Click += new System.EventHandler(this.buttonDeSerialize_Click);
			// 
			// listView1
			// 
			this.listView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																						this.columnHeader1,
																						this.columnHeader2,
																						this.columnHeader3,
																						this.columnHeader4});
			this.listView1.HoverSelection = true;
			this.listView1.Location = new System.Drawing.Point(8, 8);
			this.listView1.Name = "listView1";
			this.listView1.Size = new System.Drawing.Size(376, 272);
			this.listView1.TabIndex = 2;
			this.listView1.View = System.Windows.Forms.View.Details;
			// 
			// columnHeader1
			// 
			this.columnHeader1.Text = "Name";
			this.columnHeader1.Width = 162;
			// 
			// columnHeader2
			// 
			this.columnHeader2.Text = "Code";
			this.columnHeader2.Width = 88;
			// 
			// columnHeader3
			// 
			this.columnHeader3.Text = "Price";
			// 
			// columnHeader4
			// 
			this.columnHeader4.Text = "In stock";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(392, 318);
			this.Controls.Add(this.listView1);
			this.Controls.Add(this.buttonDeSerialize);
			this.Controls.Add(this.buttonSerialize);
			this.Name = "Form1";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Serialisation demo";
			this.ResumeLayout(false);

		}
		#endregion

		#region Serialize / deserialize clicks
		private void buttonSerialize_Click(object sender, System.EventArgs e)
		{
			try
			{
				this.Cursor = Cursors.WaitCursor;

				// Create dummy data
				ProductCollection collection = new ProductCollection();
				for (int i=0;i <= 20000;i++)
				{
					Product product = new Product();
					product.Name = "Product #"+i;
					product.Code = "AB"+i;
					product.InStock = (i % 2 == 0);
					product.Price = i;

					collection.Add(product);
				}

				// Serialize to a file
				FileStream fileStream = new FileStream("Test.out",FileMode.Create);
				BinaryFormatter binaryFormatter = new BinaryFormatter( );
			
				binaryFormatter.Serialize(fileStream,collection);
				fileStream.Close();

				MessageBox.Show("Serialization to file 'Test.out' complete");		
			}
			catch (Exception er)
			{
				MessageBox.Show(er.Message);
			}
			finally
			{
				this.Cursor = Cursors.Default;
			}
		}

		private void buttonDeSerialize_Click(object sender, System.EventArgs e)
		{
			try
			{
				this.Cursor = Cursors.WaitCursor;

				// De-serialize
				FileStream fileStream = new FileStream("Test.out",FileMode.Open);
				BinaryFormatter binaryFormatter = new BinaryFormatter();
				ProductCollection collection = (ProductCollection) binaryFormatter.Deserialize(fileStream);
				fileStream.Close();

				this.listView1.BeginUpdate();

				// Display
				foreach (Product product in collection)
				{
					ListViewItem listViewItem = listView1.Items.Add(product.Name);
					listViewItem.SubItems.Add(product.Code);
					listViewItem.SubItems.Add(product.Price.ToString());
					listViewItem.SubItems.Add((product.InStock)? "Yes" : "No" );
				}

				this.listView1.EndUpdate();
			}
			catch (Exception er)
			{
				MessageBox.Show(er.Message);
			}
			finally
			{
				this.Cursor = Cursors.Default;
			}
		}
		#endregion
	}
}
