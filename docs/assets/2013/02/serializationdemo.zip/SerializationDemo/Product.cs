using System;
using System.Collections;

namespace SerializationDemo
{
	[Serializable]
	public struct Product
	{
		public string Name
		{
			get
			{
				return this._name;
			}
			set
			{
				this._name = value;
			}
		}

		public double Price
		{
			get
			{
				return this._price;
			}
			set
			{
				this._price = value;
			}
		}

		public string Code
		{
			get
			{
				return this._code;
			}
			set
			{
				this._code = value;
			}
		}

		public bool InStock
		{
			get
			{
				return this._inStock;
			}
			set
			{
				this._inStock = value;
			}
		}

		private string _name;
		private double _price;
		private string _code;
		private bool _inStock;
	}

	[Serializable]
	public class ProductCollection : CollectionBase
	{
		public void Add(Product product)
		{
			List.Add(product);
		}

		public bool Remove(int index)
		{
			if (index > Count - 1 || index < 0)
			{
				return false;
			}
			else
			{
				List.RemoveAt(index);
				return true;
			}
		}

		public Product Item(int Index)
		{
			return (Product) List[Index];
		}
	}
}
