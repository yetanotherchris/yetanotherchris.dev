DataProducer Java Class
Version 1.00

� C.Small  2000-2001
Bugs + info: sloppycode@sloppycode.net
Website: www.sloppycode.net

Contents
========

1. Introduction
2. Installation
3. Documentation
4. Example usage

1. Introduction
---------------
Dataproducer, available for php,java servlets and asp is used to seperate the presentation layer from the data layer in web applications. With it you can specify single and multiple row tags inside a html template, which are then replaced with data that you specify. Please note this is the first version of the class and features little error handling. More features and error handling will appear in the next version.

2. Installation
---------------
A compiled version of the source (using JDK 1.3), 'DataProducer.class' comes with this package. To use the class, put it in a directory in your class path, or make it part of a package. The two examples will need compiling. You will need the JDBC API for the database example, if it isn't included with the Java distribution you have (available from http://java.sun.com/products/jdbc/download.html)

3. Documentation
---------------
See the manual.html file that comes with this package.

4. Example Usage
---------------
Example usage can be found in the Example.java file that comes with this package. An example of using the DataProducer component with an Access database can be found in the DbExample.java file.