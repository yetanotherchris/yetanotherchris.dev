/*
************************************************************************
* � Sloppycode.net All rights reserved.
*
* This is a standard copyright header for all source code appearing
* at sloppycode.net. This application/class/script may be redistributed,
* as long as the above copyright remains intact. 
* Comments to sloppycode@sloppycode.net
************************************************************************
*/

/* DataProducer Example */
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

public class Example extends HttpServlet 
{

	public void doGet(HttpServletRequest request,HttpServletResponse response)
	throws ServletException, IOException 
	{
			
		String templatefile;	
						
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		// Open template html file + add to string
		DataProducer dp = new DataProducer();
		
		// Alter this to reflect the path to your template file if necessary
		templatefile = getServletContext().getRealPath("/")+"template.html";
		String contents = dp.openTemplate(templatefile);

		// Single data
		Hashtable singledata = new Hashtable();
		singledata.put("firstname","John");
		singledata.put("surname","Smith");
		singledata.put("fruit","Apple");
		contents = dp.doSingleDataProducer(singledata,contents);
		
		// Multiple data
		Hashtable row1 = new Hashtable();
		Hashtable row2 = new Hashtable();
		Hashtable row3 = new Hashtable();
		
		row1.put("product_name","Can of beans");
		row1.put("product_code","#23A534EE25");
		row1.put("product_price","12.34");
		
		row2.put("product_name","LCD monitor");
		row2.put("product_code","#87J56NFG56");
		row2.put("product_price","222.99");
		
		row3.put("product_name","Lampshade");
		row3.put("product_code","#2RE4YH4H5");
		row3.put("product_price","36.00");
		
		Vector multirows = new Vector();
		multirows.add(row1);
		multirows.add(row2);
		multirows.add(row3);
		
		contents = dp.doDataProducer("<rows_start>","</rows_start>",multirows,contents);
		
		out.println(contents);
	}

}