/*
************************************************************************
* � Sloppycode.net All rights reserved.
*
* This is a standard copyright header for all source code appearing
* at sloppycode.net. This application/class/script may be redistributed,
* as long as the above copyright remains intact. 
* Comments to sloppycode@sloppycode.net
************************************************************************
*/

/* DataProducer Database Example */
import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

public class DbExample extends HttpServlet
{

   public void doGet(HttpServletRequest request,HttpServletResponse response)
   throws ServletException, IOException
   {

      try
      {
      	String templatefile;	
						
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		// Open template html file + add to string
		DataProducer dp = new DataProducer();
		
		// Alter this to reflect the path to your template file if necessary
		templatefile = getServletContext().getRealPath("/")+"template.html";
		String contents = dp.openTemplate(templatefile);
		
		// Single data
		Hashtable singledata = new Hashtable();
		singledata.put("firstname","John");
		singledata.put("surname","Smith");
		singledata.put("fruit","Apple");
		contents = dp.doSingleDataProducer(singledata,contents);
		
		/* -- Multiple rows database example */
		
        // Driver
	    Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
	
	    // Connect to db
	    String dbinfo = "jdbc:odbc:Driver={Microsoft Access Driver (*.mdb)};DBQ="+getServletContext().getRealPath("/")+"exampledb.mdb";
	
	    Connection conn = DriverManager.getConnection(dbinfo);
	
	    // Execute SQL, get recordset
	    Statement stmt = conn.createStatement();
	    ResultSet RS = stmt.executeQuery("SELECT * FROM exampletable");
	
	    // If there are rows
	    if (RS != null)
	    {       
	       // Vector to hold hashtables
	       Vector multirows = new Vector();
	       
	       // Go through each record and add the tags to a hashtable, then add to multirows
	       while(RS.next())
	       {
	       		Hashtable tmprow = new Hashtable();
	       		tmprow.put("product_name",RS.getString("product_name"));
	       		tmprow.put("product_code",RS.getString("product_code"));
				tmprow.put("product_price",RS.getString("product_price"));
				multirows.add(tmprow);
				
				tmprow = null;
	       }
	       contents = dp.doDataProducer("<rows_start>","</rows_start>",multirows,contents);
	    }
	    
	    out.println(contents);
	    stmt.close();
	    conn.close();

      } catch(Exception e){
         response.setContentType("text/html");
         PrintWriter out = response.getWriter();
         out.println("Error: "+e);
      }

   }

}