/*
************************************************************************
* � Sloppycode.net All rights reserved.
*
* This is a standard copyright header for all source code appearing
* at sloppycode.net. This application/class/script may be redistributed,
* as long as the above copyright remains intact. 
* Comments to sloppycode@sloppycode.net
************************************************************************
*/
import java.io.*;
import java.util.*;

public class DataProducer
{
	
	public String openTemplate(String htmlFilename)
	{
		/* Try to open html template */
		try 
		{
			FileReader fHnd = new FileReader(htmlFilename);
		
			/* Go through all lines and return as string */
			String contents = new String();
			int i;
			while ( (i = fHnd.read()) != -1)
			{
				contents += (char) i;
			}
			fHnd.close();	
			
			return contents;
		} catch (Exception e){
			return "Error in opening template file:"+htmlFilename+"<br><h5>("+e+")</h5>";
		}
	}
	
	public String doSingleDataProducer(Hashtable data,String contents)
	{
		if (contents == null || contents == "")
		{
			throw new RuntimeException("DataProducer.doSingleDataProducer() error: template file (contents) is empty.");
		}
		
		// Go through all elements of the hashtable, replace
		// the <keyname> with its value
		Enumeration allKeys = data.keys();
		while (allKeys.hasMoreElements())
		{
			Object keyName = allKeys.nextElement();	
			
			if (data.get(keyName) != null)
			{
				contents = replaceString(contents,"<"+(String) keyName+">",(String) data.get(keyName));
			} else{
				contents = replaceString(contents,"<"+(String) keyName+">","");
			}
					
		}
		return contents;
	}
	
	public String doDataProducer(String startTag,String endTag,Vector data,String contents)
	{
		if (startTag == "" || startTag == null)
		{
			throw new RuntimeException("DataProducer.doDataProducer() error: startTag is empty.");
		}
		if (endTag == "" || endTag == null)
		{
			throw new RuntimeException("DataProducer.doDataProducer() error: endTag is empty.");
		}
		if (contents == null || contents == "")
		{
			throw new RuntimeException("DataProducer.doDataProducer() error: template file (contents) is empty.");
		}
		
		
		int start,end,innerLength;
		String prefix,suffix,dataTemplate;
	
		// Get start and end points
		start = contents.indexOf(startTag);
		end   = contents.indexOf(endTag,start);
		
		// Retrieve everything before start tag
		prefix  = contents.substring(0,start);
		prefix  = ltrim(prefix);
	
		// Retrieve everything after end tag. Make it starts at the end of end-tag
		suffix = substr(contents,end + endTag.length(), contents.length() - (end + endTag.length()));
		suffix = ltrim(suffix);
	
		// Retrieve data template. make sure it starts at the end of the start-tag.
		dataTemplate = substr(contents,start + startTag.length(),end - (start + startTag.length()));

		// Go through each vector element and use hashtable keys to replace
		int numRecords = data.size();		
		String build = ""; // builds up a string of replaced tags
		
		for (int i=0; i <= numRecords -1;i++)
		{
			String tempReplace = dataTemplate;
			Hashtable thisRow = (Hashtable) data.get(i);
			Enumeration e = thisRow.keys();
			
			while (e.hasMoreElements())
			{
				Object keyName = e.nextElement();
				Object keyValue   = thisRow.get(keyName);
			
				if (keyValue != null)
				{
					tempReplace = replaceString(tempReplace,"<"+(String) keyName+">",(String) keyValue);
				} else{
					tempReplace = replaceString(tempReplace,"<"+(String) keyName+">","");
				}
			}	
			build += tempReplace;
		}
					
		return prefix + build + suffix;
	}
	
	
	/* -- String Functions ---------- */
	
	private static String replaceString (String body, String findString, String replaceString)
	{
	  StringBuffer newBodyBuffer = new StringBuffer (findString.length()*2);
	  char[] chars = body.toCharArray();
	  int start = 0;
	  while (true)
	  {
	   int index = body.indexOf (findString, start);
	   if (index == -1) break;
	   newBodyBuffer.append (chars, start, index-start);
	   newBodyBuffer.append (replaceString);
	   start = index + findString.length();
	  }
	  newBodyBuffer.append (chars, start, chars.length-start);
	  return newBodyBuffer.toString();
	}
	 
	 
	private String ltrim (String s)
	{
		//char chkws = (char) s.charAt(0);
		while(s.charAt(0) == ' ')
		{
	 		s = s.substring(1);
		}
		return(s);
	}

	private String rtrim (String s)
	{
		int len = s.length();
		//char chkws = (char) s.charAt(len-1);
		while(s.charAt(len-1) == ' ')
		{
			s = s.substring(0,len-1);
			len--;
		}
		return(s);
	}

	private String substr(String s,int start,int length)
	{
		return s.substring(start,start + length);
	}

}