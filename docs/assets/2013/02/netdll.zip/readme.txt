NETDLL ASP Component
Version 1.00

� W.Tracz  2000-2001
Bugs + info: wtracz@yahoo.co.uk
Website: www.nervetoxin.co.uk/www.sloppycode.net

Contents
========

1. Introduction
2. Installation
3. Documentation
4. Example usage

1. Introduction
---------------
NETDLL is suite of networking tools built into one ASP component. Included is a ping function, an IP to hostname lookup, a hostname to IP lookup and a function for retrieving the serving computer's IP.

2. Installation
---------------
To install this ASP Component for PWS or IIS 4/5, first copy it to your favourite directory, then enter the command prompt by using Start>Run>Command.com (or cmd in Win2k). Use the 'CD' (change directory) command to navigate the directory where you stored the DLL file, and then type

regsvr32 netdll.dll

This should register the ASP Component as ready to use by your computer.

3. Documentation
---------------
See the manual.html file that comes with this package.

4. Example Usage
---------------
Example usage can be found in the example.asp file that comes with this package, and also a Visual Basic example, in the 'VisualBasic' folder.