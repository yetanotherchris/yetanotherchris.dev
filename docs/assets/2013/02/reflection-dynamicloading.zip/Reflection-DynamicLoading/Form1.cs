using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Reflection;

namespace ReflectionTypeDiscovery
{
	public class Form1 : System.Windows.Forms.Form
	{
		#region Components
		private System.Windows.Forms.Button buttonRetrieve;
		private System.Windows.Forms.Panel panelTop;
		private System.Windows.Forms.Panel panelBottom;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Panel panelMiddleTop;
		private System.Windows.Forms.Splitter splitter1;
		private System.Windows.Forms.TreeView treeView1;
		private System.ComponentModel.Container components = null;
		#endregion

		#region Constructor, dispose, main
		public Form1()
		{
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}
		#endregion

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.panelTop = new System.Windows.Forms.Panel();
			this.panelMiddleTop = new System.Windows.Forms.Panel();
			this.treeView1 = new System.Windows.Forms.TreeView();
			this.splitter1 = new System.Windows.Forms.Splitter();
			this.panelBottom = new System.Windows.Forms.Panel();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.buttonRetrieve = new System.Windows.Forms.Button();
			this.panelTop.SuspendLayout();
			this.panelMiddleTop.SuspendLayout();
			this.panelBottom.SuspendLayout();
			this.SuspendLayout();
			// 
			// panelTop
			// 
			this.panelTop.Controls.Add(this.panelMiddleTop);
			this.panelTop.Controls.Add(this.splitter1);
			this.panelTop.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panelTop.Location = new System.Drawing.Point(0, 0);
			this.panelTop.Name = "panelTop";
			this.panelTop.Size = new System.Drawing.Size(536, 342);
			this.panelTop.TabIndex = 0;
			// 
			// panelMiddleTop
			// 
			this.panelMiddleTop.Controls.Add(this.treeView1);
			this.panelMiddleTop.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panelMiddleTop.Location = new System.Drawing.Point(0, 0);
			this.panelMiddleTop.Name = "panelMiddleTop";
			this.panelMiddleTop.Size = new System.Drawing.Size(536, 339);
			this.panelMiddleTop.TabIndex = 0;
			// 
			// treeView1
			// 
			this.treeView1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.treeView1.ImageIndex = -1;
			this.treeView1.Location = new System.Drawing.Point(0, 0);
			this.treeView1.Name = "treeView1";
			this.treeView1.SelectedImageIndex = -1;
			this.treeView1.Size = new System.Drawing.Size(536, 339);
			this.treeView1.TabIndex = 0;
			this.treeView1.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView1_AfterSelect);
			// 
			// splitter1
			// 
			this.splitter1.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.splitter1.Location = new System.Drawing.Point(0, 339);
			this.splitter1.Name = "splitter1";
			this.splitter1.Size = new System.Drawing.Size(536, 3);
			this.splitter1.TabIndex = 6;
			this.splitter1.TabStop = false;
			// 
			// panelBottom
			// 
			this.panelBottom.Controls.Add(this.textBox1);
			this.panelBottom.Controls.Add(this.buttonRetrieve);
			this.panelBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panelBottom.Location = new System.Drawing.Point(0, 342);
			this.panelBottom.Name = "panelBottom";
			this.panelBottom.Size = new System.Drawing.Size(536, 40);
			this.panelBottom.TabIndex = 1;
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(7, 11);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(288, 21);
			this.textBox1.TabIndex = 1;
			this.textBox1.Text = "C:\\WINDOWS\\Microsoft.NET\\Framework\\v1.1.4322\\System.dll";
			// 
			// buttonRetrieve
			// 
			this.buttonRetrieve.Location = new System.Drawing.Point(304, 10);
			this.buttonRetrieve.Name = "buttonRetrieve";
			this.buttonRetrieve.TabIndex = 0;
			this.buttonRetrieve.Text = "Retrieve";
			this.buttonRetrieve.Click += new System.EventHandler(this.buttonRetrieve_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(536, 382);
			this.Controls.Add(this.panelTop);
			this.Controls.Add(this.panelBottom);
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "Form1";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Basic Reflection example";
			this.panelTop.ResumeLayout(false);
			this.panelMiddleTop.ResumeLayout(false);
			this.panelBottom.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		#region Retrieve, after select
		private void buttonRetrieve_Click(object sender, System.EventArgs e)
		{
			if ( this.textBox1.Text != "" )
			{
				try
				{
					this.treeView1.Nodes.Clear();
					Assembly assembly = Assembly.LoadFrom(textBox1.Text);

					if ( assembly == null )
						throw new Exception();

					Type[] types = assembly.GetTypes();
					TreeNode treeNode,treeNode1;

					treeNode = new TreeNode(textBox1.Text);

					foreach (Type type in types)
					{
						treeNode1 = treeNode.Nodes.Add(type.Namespace +"."+ type.Name);
						treeNode1.Tag = type;
					}

					this.treeView1.Nodes.Add(treeNode);
				}
				catch
				{
					MessageBox.Show("Unable to retrieve details for: " + this.textBox1.Text,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
				}
			}
		}

		private void getTypes(Type type,TreeNode treeNode)
		{
			if ( type == null )
				return;

			MemberInfo[] members = type.GetMembers();

			TreeNode treeNode1;
			foreach (MemberInfo member in members)
			{
				treeNode1 = new TreeNode(member.Name);
				treeNode1.Tag = member;
				treeNode.Nodes.Add(treeNode1);
			}
		}

		private void treeView1_AfterSelect(object sender, System.Windows.Forms.TreeViewEventArgs e)
		{
			if ( e.Node.Nodes.Count < 1 )
				this.getTypes((Type) e.Node.Tag,e.Node);
		}
		#endregion
	}
}
