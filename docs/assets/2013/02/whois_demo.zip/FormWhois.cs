using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Threading;

namespace Whois
{
	public class FormWhois : System.Windows.Forms.Form
	{
		#region Components
		private System.Windows.Forms.Panel panelTop;
		private System.Windows.Forms.GroupBox groupBoxBottom;
		private System.Windows.Forms.TextBox textBoxLookup;
		private System.Windows.Forms.Button buttonLookup;
		private System.Windows.Forms.RichTextBox richTextBoxResult;
		private System.Windows.Forms.Label labelWhoisServer;
		private System.ComponentModel.Container components = null;
		#endregion

		#region Constructor, main etc.
		public FormWhois()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new FormWhois());
		}
		#endregion

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.panelTop = new System.Windows.Forms.Panel();
			this.buttonLookup = new System.Windows.Forms.Button();
			this.textBoxLookup = new System.Windows.Forms.TextBox();
			this.groupBoxBottom = new System.Windows.Forms.GroupBox();
			this.labelWhoisServer = new System.Windows.Forms.Label();
			this.richTextBoxResult = new System.Windows.Forms.RichTextBox();
			this.panelTop.SuspendLayout();
			this.groupBoxBottom.SuspendLayout();
			this.SuspendLayout();
			// 
			// panelTop
			// 
			this.panelTop.Controls.AddRange(new System.Windows.Forms.Control[] {
																				   this.buttonLookup,
																				   this.textBoxLookup});
			this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
			this.panelTop.Name = "panelTop";
			this.panelTop.Size = new System.Drawing.Size(496, 32);
			this.panelTop.TabIndex = 1;
			// 
			// buttonLookup
			// 
			this.buttonLookup.Location = new System.Drawing.Point(389, 8);
			this.buttonLookup.Name = "buttonLookup";
			this.buttonLookup.Size = new System.Drawing.Size(96, 21);
			this.buttonLookup.TabIndex = 1;
			this.buttonLookup.Text = "Lookup";
			this.buttonLookup.Click += new System.EventHandler(this.buttonLookup_Click);
			// 
			// textBoxLookup
			// 
			this.textBoxLookup.Location = new System.Drawing.Point(8, 8);
			this.textBoxLookup.Name = "textBoxLookup";
			this.textBoxLookup.Size = new System.Drawing.Size(368, 21);
			this.textBoxLookup.TabIndex = 0;
			this.textBoxLookup.Text = "www.sloppycode.net";
			// 
			// groupBoxBottom
			// 
			this.groupBoxBottom.Controls.AddRange(new System.Windows.Forms.Control[] {
																						 this.labelWhoisServer,
																						 this.richTextBoxResult});
			this.groupBoxBottom.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBoxBottom.Location = new System.Drawing.Point(0, 32);
			this.groupBoxBottom.Name = "groupBoxBottom";
			this.groupBoxBottom.Size = new System.Drawing.Size(496, 224);
			this.groupBoxBottom.TabIndex = 2;
			this.groupBoxBottom.TabStop = false;
			this.groupBoxBottom.Text = "Lookup results";
			// 
			// labelWhoisServer
			// 
			this.labelWhoisServer.Location = new System.Drawing.Point(12, 20);
			this.labelWhoisServer.Name = "labelWhoisServer";
			this.labelWhoisServer.Size = new System.Drawing.Size(320, 16);
			this.labelWhoisServer.TabIndex = 1;
			// 
			// richTextBoxResult
			// 
			this.richTextBoxResult.Location = new System.Drawing.Point(8, 40);
			this.richTextBoxResult.Name = "richTextBoxResult";
			this.richTextBoxResult.Size = new System.Drawing.Size(480, 176);
			this.richTextBoxResult.TabIndex = 0;
			this.richTextBoxResult.Text = "";
			// 
			// FormWhois
			// 
			this.AcceptButton = this.buttonLookup;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(496, 256);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.groupBoxBottom,
																		  this.panelTop});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "FormWhois";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Whois Lookup";
			this.panelTop.ResumeLayout(false);
			this.groupBoxBottom.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		#region Do the whois....
		private void buttonLookup_Click(object sender, System.EventArgs e)
		{
			Thread thread = new Thread(new ThreadStart(whoisThread));
			thread.Start();
		}

		private void whoisThread()
		{
			Whois whois = new Whois();
			whois.LookupComplete += new WhoisEventHandler(this.OnLookupComplete);
			whois.WhoisServer = "whois.internic.net";
			whois.Lookup(this.textBoxLookup.Text);
		}

		private void OnLookupComplete(object sender,WhoisEventArgs e)
		{
			this.richTextBoxResult.Text = e.WhoisInfo;
			this.labelWhoisServer.Text = "Lookup using server: " +e.WhoisServer;
		}
		#endregion
	}
}
