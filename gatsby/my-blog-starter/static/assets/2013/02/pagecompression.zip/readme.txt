Add the following line in your web.config file, inside the <httpModules> node:


<add name="PageCompressionModule" type="Compression.PageCompressionModule, Compression.PageCompressionModule"/>