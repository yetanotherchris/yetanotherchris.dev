using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Runtime.InteropServices;
namespace LineCount
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class LineCountForm : System.Windows.Forms.Form
	{
		internal const uint SHGFI_ICON              =0x000000100;    // get icon
		internal const uint SHGFI_TYPENAME          =0x000000400;     // get type name
		internal const uint SHGFI_SYSICONINDEX      =0x000004000;     // get system icon index
		internal const uint SHGFI_SMALLICON         =0x000000001;     // get small icon
		internal const uint SHGFI_USEFILEATTRIBUTES =0x000000010;     // use passed dwFileAttribute
		internal const uint SHGFI_LARGEICON         =0x000000000;     // get large icon
		// Use when pszPath is a string
		[DllImport("shell32.dll", CharSet=CharSet.Auto)]
		internal static extern IntPtr SHGetFileInfo(string pszPath, int
			dwFileAttributes, out SHFILEINFO psfi, int cbFileInfo, uint uFlags);
		
		[StructLayout(LayoutKind.Sequential,CharSet=CharSet.Auto)]
			internal struct SHFILEINFO
		{
			private const int MAX_PATH = 260;
			public IntPtr hIcon; 
			public int    iIcon; 
			public int    dwAttributes; 
			[MarshalAs(UnmanagedType.ByValTStr, SizeConst=MAX_PATH)]
			public string szDisplayName;
			[MarshalAs(UnmanagedType.ByValTStr, SizeConst=80)]
			public string szTypeName; 
		}
		[StructLayout(LayoutKind.Sequential,CharSet=CharSet.Auto)]
			internal struct LPSTR
		{	
			private const int MAX_PATH = 260;
			[MarshalAs(UnmanagedType.ByValTStr, SizeConst=MAX_PATH)]
			public string lpBuffer;
		}

		private System.Windows.Forms.TextBox txtProjectDirectory;
		private System.Windows.Forms.Label lblProjectDirectory;
		private System.Windows.Forms.Label lblFileTypes;
		private System.Windows.Forms.TextBox txtFileTypes;
		private System.Windows.Forms.Button btnCountNumLines;
		private System.Windows.Forms.Label lblLineCount;
		private System.Windows.Forms.TextBox txtLineCount;
		private System.Windows.Forms.TextBox txtCCommentLines;
		private System.Windows.Forms.Label lblCCommentLines;
		private System.Windows.Forms.Label lblEmptyLines;
		private System.Windows.Forms.TextBox txtEmptyLines;
		private System.Windows.Forms.Label lblCodeLines;
		private System.Windows.Forms.TextBox txtCodeLines;
		private System.Windows.Forms.CheckBox cbSearchSubDiretories;
		private System.Windows.Forms.ColumnHeader columnHeaderFileName;
		private System.Windows.Forms.ListView listViewFiles;
		private System.Windows.Forms.TextBox txtFilesCounted;
		private System.Windows.Forms.Label lblFilesCounted;
		private System.Windows.Forms.ColumnHeader columnHeaderLineCount;
		private System.Windows.Forms.ColumnHeader columnHeaderCommentLines;
		private System.Windows.Forms.ColumnHeader columnHeaderEmptyLines;
		private System.Windows.Forms.ColumnHeader columnHeaderResult;
		private System.Windows.Forms.ColumnHeader columnHeaderDirectory;
		private System.Windows.Forms.ImageList _fileIconImageList;
		private System.ComponentModel.IContainer components;
		private System.Windows.Forms.ColumnHeader columnHeaderFileType;
		private Hashtable _FileExtensionInfoTable;
		
		public LineCountForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			_FileExtensionInfoTable = new Hashtable();
			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.txtProjectDirectory = new System.Windows.Forms.TextBox();
			this.btnCountNumLines = new System.Windows.Forms.Button();
			this.lblProjectDirectory = new System.Windows.Forms.Label();
			this.lblFileTypes = new System.Windows.Forms.Label();
			this.txtFileTypes = new System.Windows.Forms.TextBox();
			this.lblLineCount = new System.Windows.Forms.Label();
			this.txtLineCount = new System.Windows.Forms.TextBox();
			this.txtCCommentLines = new System.Windows.Forms.TextBox();
			this.lblCCommentLines = new System.Windows.Forms.Label();
			this.lblEmptyLines = new System.Windows.Forms.Label();
			this.txtEmptyLines = new System.Windows.Forms.TextBox();
			this.lblCodeLines = new System.Windows.Forms.Label();
			this.txtCodeLines = new System.Windows.Forms.TextBox();
			this.cbSearchSubDiretories = new System.Windows.Forms.CheckBox();
			this.listViewFiles = new System.Windows.Forms.ListView();
			this.columnHeaderFileName = new System.Windows.Forms.ColumnHeader();
			this.columnHeaderFileType = new System.Windows.Forms.ColumnHeader();
			this.columnHeaderLineCount = new System.Windows.Forms.ColumnHeader();
			this.columnHeaderCommentLines = new System.Windows.Forms.ColumnHeader();
			this.columnHeaderEmptyLines = new System.Windows.Forms.ColumnHeader();
			this.columnHeaderResult = new System.Windows.Forms.ColumnHeader();
			this.columnHeaderDirectory = new System.Windows.Forms.ColumnHeader();
			this._fileIconImageList = new System.Windows.Forms.ImageList(this.components);
			this.txtFilesCounted = new System.Windows.Forms.TextBox();
			this.lblFilesCounted = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// txtProjectDirectory
			// 
			this.txtProjectDirectory.Location = new System.Drawing.Point(112, 24);
			this.txtProjectDirectory.Name = "txtProjectDirectory";
			this.txtProjectDirectory.Size = new System.Drawing.Size(208, 20);
			this.txtProjectDirectory.TabIndex = 0;
			this.txtProjectDirectory.Text = "c:\\";
			// 
			// btnCountNumLines
			// 
			this.btnCountNumLines.Location = new System.Drawing.Point(112, 192);
			this.btnCountNumLines.Name = "btnCountNumLines";
			this.btnCountNumLines.Size = new System.Drawing.Size(200, 23);
			this.btnCountNumLines.TabIndex = 1;
			this.btnCountNumLines.Text = "Count Lines";
			this.btnCountNumLines.Click += new System.EventHandler(this.btnCountNumLines_Click);
			// 
			// lblProjectDirectory
			// 
			this.lblProjectDirectory.Location = new System.Drawing.Point(0, 24);
			this.lblProjectDirectory.Name = "lblProjectDirectory";
			this.lblProjectDirectory.TabIndex = 2;
			this.lblProjectDirectory.Text = "Project Directory";
			// 
			// lblFileTypes
			// 
			this.lblFileTypes.Location = new System.Drawing.Point(0, 96);
			this.lblFileTypes.Name = "lblFileTypes";
			this.lblFileTypes.TabIndex = 3;
			this.lblFileTypes.Text = "File Types";
			// 
			// txtFileTypes
			// 
			this.txtFileTypes.Location = new System.Drawing.Point(112, 92);
			this.txtFileTypes.Multiline = true;
			this.txtFileTypes.Name = "txtFileTypes";
			this.txtFileTypes.Size = new System.Drawing.Size(208, 88);
			this.txtFileTypes.TabIndex = 4;
			this.txtFileTypes.Text = "*.cs\r\n*.aspx\r\n*.ascx\r\n*.xml\r\n*.asax\r\n*.config\r\n*.js\r\n*.vb";
			// 
			// lblLineCount
			// 
			this.lblLineCount.Location = new System.Drawing.Point(344, 58);
			this.lblLineCount.Name = "lblLineCount";
			this.lblLineCount.Size = new System.Drawing.Size(136, 20);
			this.lblLineCount.TabIndex = 5;
			this.lblLineCount.Text = "Line Count";
			// 
			// txtLineCount
			// 
			this.txtLineCount.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.txtLineCount.Location = new System.Drawing.Point(488, 58);
			this.txtLineCount.Name = "txtLineCount";
			this.txtLineCount.ReadOnly = true;
			this.txtLineCount.Size = new System.Drawing.Size(128, 20);
			this.txtLineCount.TabIndex = 6;
			this.txtLineCount.Text = "";
			// 
			// txtCCommentLines
			// 
			this.txtCCommentLines.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.txtCCommentLines.Location = new System.Drawing.Point(488, 92);
			this.txtCCommentLines.Name = "txtCCommentLines";
			this.txtCCommentLines.ReadOnly = true;
			this.txtCCommentLines.Size = new System.Drawing.Size(128, 20);
			this.txtCCommentLines.TabIndex = 7;
			this.txtCCommentLines.Text = "";
			// 
			// lblCCommentLines
			// 
			this.lblCCommentLines.Location = new System.Drawing.Point(344, 92);
			this.lblCCommentLines.Name = "lblCCommentLines";
			this.lblCCommentLines.Size = new System.Drawing.Size(136, 20);
			this.lblCCommentLines.TabIndex = 8;
			this.lblCCommentLines.Text = "Commented Lines //";
			// 
			// lblEmptyLines
			// 
			this.lblEmptyLines.Location = new System.Drawing.Point(344, 126);
			this.lblEmptyLines.Name = "lblEmptyLines";
			this.lblEmptyLines.Size = new System.Drawing.Size(136, 20);
			this.lblEmptyLines.TabIndex = 9;
			this.lblEmptyLines.Text = "Empty Lines";
			// 
			// txtEmptyLines
			// 
			this.txtEmptyLines.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.txtEmptyLines.Location = new System.Drawing.Point(488, 126);
			this.txtEmptyLines.Name = "txtEmptyLines";
			this.txtEmptyLines.ReadOnly = true;
			this.txtEmptyLines.Size = new System.Drawing.Size(128, 20);
			this.txtEmptyLines.TabIndex = 10;
			this.txtEmptyLines.Text = "";
			// 
			// lblCodeLines
			// 
			this.lblCodeLines.Location = new System.Drawing.Point(344, 160);
			this.lblCodeLines.Name = "lblCodeLines";
			this.lblCodeLines.Size = new System.Drawing.Size(136, 20);
			this.lblCodeLines.TabIndex = 11;
			this.lblCodeLines.Text = "Result";
			// 
			// txtCodeLines
			// 
			this.txtCodeLines.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.txtCodeLines.Location = new System.Drawing.Point(488, 160);
			this.txtCodeLines.Name = "txtCodeLines";
			this.txtCodeLines.ReadOnly = true;
			this.txtCodeLines.Size = new System.Drawing.Size(128, 20);
			this.txtCodeLines.TabIndex = 12;
			this.txtCodeLines.Text = "";
			// 
			// cbSearchSubDiretories
			// 
			this.cbSearchSubDiretories.Checked = true;
			this.cbSearchSubDiretories.CheckState = System.Windows.Forms.CheckState.Checked;
			this.cbSearchSubDiretories.Location = new System.Drawing.Point(112, 48);
			this.cbSearchSubDiretories.Name = "cbSearchSubDiretories";
			this.cbSearchSubDiretories.Size = new System.Drawing.Size(208, 24);
			this.cbSearchSubDiretories.TabIndex = 14;
			this.cbSearchSubDiretories.Text = "Search Sub Directories";
			// 
			// listViewFiles
			// 
			this.listViewFiles.AllowColumnReorder = true;
			this.listViewFiles.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.listViewFiles.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																							this.columnHeaderFileName,
																							this.columnHeaderFileType,
																							this.columnHeaderLineCount,
																							this.columnHeaderCommentLines,
																							this.columnHeaderEmptyLines,
																							this.columnHeaderResult,
																							this.columnHeaderDirectory});
			this.listViewFiles.Location = new System.Drawing.Point(8, 224);
			this.listViewFiles.Name = "listViewFiles";
			this.listViewFiles.Size = new System.Drawing.Size(608, 128);
			this.listViewFiles.SmallImageList = this._fileIconImageList;
			this.listViewFiles.TabIndex = 15;
			this.listViewFiles.View = System.Windows.Forms.View.Details;
			this.listViewFiles.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.listViewFiles_ColumnClick);
			// 
			// columnHeaderFileName
			// 
			this.columnHeaderFileName.Text = "File Name";
			this.columnHeaderFileName.Width = 100;
			// 
			// columnHeaderFileType
			// 
			this.columnHeaderFileType.Text = "File Type";
			// 
			// columnHeaderLineCount
			// 
			this.columnHeaderLineCount.Text = "Line Count";
			this.columnHeaderLineCount.Width = 107;
			// 
			// columnHeaderCommentLines
			// 
			this.columnHeaderCommentLines.Text = "Commented Lines //";
			this.columnHeaderCommentLines.Width = 119;
			// 
			// columnHeaderEmptyLines
			// 
			this.columnHeaderEmptyLines.Text = "Empty Lines";
			this.columnHeaderEmptyLines.Width = 85;
			// 
			// columnHeaderResult
			// 
			this.columnHeaderResult.Text = "Result";
			this.columnHeaderResult.Width = 89;
			// 
			// columnHeaderDirectory
			// 
			this.columnHeaderDirectory.Text = "Directory";
			// 
			// _fileIconImageList
			// 
			this._fileIconImageList.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
			this._fileIconImageList.ImageSize = new System.Drawing.Size(16, 16);
			this._fileIconImageList.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// txtFilesCounted
			// 
			this.txtFilesCounted.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.txtFilesCounted.Location = new System.Drawing.Point(488, 24);
			this.txtFilesCounted.Name = "txtFilesCounted";
			this.txtFilesCounted.ReadOnly = true;
			this.txtFilesCounted.Size = new System.Drawing.Size(128, 20);
			this.txtFilesCounted.TabIndex = 6;
			this.txtFilesCounted.Text = "";
			// 
			// lblFilesCounted
			// 
			this.lblFilesCounted.Location = new System.Drawing.Point(344, 24);
			this.lblFilesCounted.Name = "lblFilesCounted";
			this.lblFilesCounted.Size = new System.Drawing.Size(136, 20);
			this.lblFilesCounted.TabIndex = 5;
			this.lblFilesCounted.Text = "Files Counted";
			// 
			// LineCountForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(624, 358);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.listViewFiles,
																		  this.cbSearchSubDiretories,
																		  this.txtCodeLines,
																		  this.lblCodeLines,
																		  this.txtEmptyLines,
																		  this.lblEmptyLines,
																		  this.lblCCommentLines,
																		  this.txtCCommentLines,
																		  this.txtLineCount,
																		  this.lblLineCount,
																		  this.txtFileTypes,
																		  this.lblFileTypes,
																		  this.lblProjectDirectory,
																		  this.btnCountNumLines,
																		  this.txtProjectDirectory,
																		  this.txtFilesCounted,
																		  this.lblFilesCounted});
			this.Name = "LineCountForm";
			this.Text = "Line Counter";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new LineCountForm());
		}
		private void LoadImageList(string[] fileExtensions)
		{
			this._fileIconImageList.Images.Clear();
			
			
			for (int i=0; i<fileExtensions.Length; i++)
			{	
				SHFILEINFO rInfo = new SHFILEINFO();
				string strType = fileExtensions[i].Remove(0,2);
				IntPtr pointer = SHGetFileInfo("foo."+strType,0,out rInfo,Marshal.SizeOf(typeof(SHFILEINFO)),
					SHGFI_ICON |
					SHGFI_SMALLICON |
					SHGFI_SYSICONINDEX |
					SHGFI_USEFILEATTRIBUTES|
					SHGFI_TYPENAME
					);
				Icon aIcon = System.Drawing.Icon.FromHandle(rInfo.hIcon);
				this._fileIconImageList.Images.Add(aIcon);
				_FileExtensionInfoTable[strType] = new string[]{rInfo.szTypeName,i.ToString()};
			}
		}
		
		private ListViewItem CreateListViewItem(FileCodeCountInfo file)
		{
			int result = file.LineCount-file.CommentLineCount-file.EmptyLineCount;
			string fileName = file.FileName;
			string ext = fileName.Substring(fileName.LastIndexOf('.')+1);
			string[] fileExtensionInfo = (string[])_FileExtensionInfoTable[ext];
			ListViewItem item = new ListViewItem(new string[]{file.FileName,fileExtensionInfo[0],file.LineCount.ToString(),file.CommentLineCount.ToString(),file.EmptyLineCount.ToString(),result.ToString(),file.Directory}
												,Convert.ToInt32(fileExtensionInfo[1]));
			return item;
		}
		private void btnCountNumLines_Click(object sender, System.EventArgs e)
		{
			Cursor.Current = Cursors.WaitCursor;
			try
			{
				LineCount.LineCounter counter = new LineCount.LineCounter(this.txtProjectDirectory.Text,this.txtFileTypes.Lines,this.cbSearchSubDiretories.Checked);
				counter.CountLines();
				int comment = counter.CommentLineCount;
				int empty = counter.EmptyLineCount;
				int total = counter.TotalLineCount;

				this.txtCCommentLines.Text = comment.ToString();
				this.txtEmptyLines.Text	= empty.ToString();
				this.txtLineCount.Text = total.ToString();
				
				this.txtCodeLines.Text = (total-empty-comment).ToString() ;
				this.listViewFiles.Items.Clear();
				
				this.LoadImageList(this.txtFileTypes.Lines);

				ICollection collection = counter.FilesInProject;
				this.txtFilesCounted.Text = collection.Count.ToString();
				foreach(FileCodeCountInfo file in collection)
				{
					this.listViewFiles.Items.Add(this.CreateListViewItem(file));
				}
			}
			catch(System.Exception error)
			{
				MessageBox.Show(error.ToString());
			}
			Cursor.Current = Cursors.Default;
		}

		private void listViewFiles_ColumnClick(object sender, System.Windows.Forms.ColumnClickEventArgs e)
		{
			try
			{
				ListViewColumnSort sorter = null;
				SortOrder sortOrder = SortOrder.Ascending;
				if(this.listViewFiles.Sorting == SortOrder.Ascending)
				{
					sortOrder = SortOrder.Descending;
					this.listViewFiles.Sorting = SortOrder.Ascending;
				}
				else
					this.listViewFiles.Sorting = SortOrder.Descending;
				
				if(e.Column == 0 || e.Column == 1 || e.Column == 6)
					sorter = new ListViewColumnSort(e.Column,sortOrder,ListViewColumnSort.CompareType.Text);
				else
					sorter = new ListViewColumnSort(e.Column,sortOrder,ListViewColumnSort.CompareType.Numeric);
				
				this.listViewFiles.ListViewItemSorter = sorter;
				
				if(this.listViewFiles.Sorting == SortOrder.Ascending)
					this.listViewFiles.Sorting = SortOrder.Descending;
				else
					this.listViewFiles.Sorting = SortOrder.Ascending;

				this.listViewFiles.ListViewItemSorter = null;
				
			}
			catch(System.Exception error)
			{
				String Error = error.ToString();
				MessageBox.Show(Error);

			}
		}
	
		private class ListViewColumnSort: IComparer
		{
			public enum CompareType
			{
				Text,
				Numeric,
				DateTime
			}
			private int m_SubItemIndex  = 0;
			private SortOrder m_SortOrder;
			private CompareType m_compareType;
			public ListViewColumnSort(int SubItemIndex,SortOrder sortOrder,CompareType compareType )
			{
				this.m_SubItemIndex = SubItemIndex;
				this.m_SortOrder = sortOrder;
				this.m_compareType = compareType;
			}
			public int Compare(object objCompare1, object objCompare2 )
			{
				//Implements IComparer.Compare
				int rc = 0;
				ListViewItem lviItem1;
				ListViewItem lviItem2; 
				lviItem1 = (ListViewItem)objCompare1;
				lviItem2 = (ListViewItem)objCompare2;
			
				
				//Sort in Ascending/Descending order
				if( m_SortOrder == SortOrder.Ascending)
				{
					//Execute sort based on Compare Method
					switch(this.m_compareType)
					{
						case CompareType.Text:
							rc = String.Compare(lviItem1.SubItems[m_SubItemIndex].Text,lviItem2.SubItems[m_SubItemIndex].Text);
							break;
						case CompareType.Numeric:
							rc = Decimal.Compare(Convert.ToDecimal(lviItem1.SubItems[m_SubItemIndex].Text),Convert.ToDecimal(lviItem2.SubItems[m_SubItemIndex].Text));
							break;
						case CompareType.DateTime:
							rc = DateTime.Compare(Convert.ToDateTime(lviItem1.SubItems[m_SubItemIndex].Text),Convert.ToDateTime(lviItem2.SubItems[m_SubItemIndex].Text));
							break;
					}

				}
				else
				{
					//Execute sort based on Compare Method
					switch(m_compareType)
					{
						case CompareType.Text:
							rc = String.Compare(lviItem2.SubItems[m_SubItemIndex].Text,lviItem1.SubItems[m_SubItemIndex].Text);
							break;
						case CompareType.Numeric:
							rc = Decimal.Compare(Convert.ToDecimal(lviItem2.SubItems[m_SubItemIndex].Text),Convert.ToDecimal(lviItem1.SubItems[m_SubItemIndex].Text));
							break;
						case CompareType.DateTime:
							rc = DateTime.Compare(Convert.ToDateTime(lviItem2.SubItems[m_SubItemIndex].Text),Convert.ToDateTime(lviItem1.SubItems[m_SubItemIndex].Text));
							break;
					}
				}	
				
				//Destroy local objects
				lviItem1 = null;
				lviItem2 = null;
				return rc;
			}				 
		}
	
	}
	
}
