using System;
using System.Collections;
using System.IO;

namespace LineCount
{
	/// <summary>
	/// Application: It counts code lines in the VS.NET Project
	/// Author: Levent Camlibel
	/// Date: July 26, 2001
	/// 
	/// Modified By Patrick Wright (patrick_d_wright@hotmail.com) so the
	/// code runs on the RTM version of .Net
	///
	///	Modified by Trent Dinn (trentdinn@hotmail.com) to account for c style comments and
	///	empty lines.  It also works now as a standalone windows application. 
	/// </summary>
	/// 

	
	public class LineCounter
    {	
		//FileNames holds the names of files in the project directories
		protected ArrayList _fileNames= new ArrayList(200);
		
		public LineCounter():this(@"c:",new string[]{"*.cs"},false){}
		public LineCounter(string projectDirectory, string[] fileTypes,bool searchSubDirectories)
		{
			this._projectDirectory = projectDirectory;
			this._fileTypes = fileTypes;
			this._seachSubDirectories = searchSubDirectories;
		}
		/// <summary>
		/// Returns a collection which contains objects of FileCodeCountInfo.  This CountLine method will fill the collection with the approaiate information
		/// </summary>
		public ArrayList FilesInProject
		{
			get
			{
				return _fileNames;
			}
		}
		protected bool _seachSubDirectories;
		/// <summary>
		/// Set to true if you wish to seach the subdirectories of the specified Project Direcotry.  The intial value is set to false;
		/// </summary>
		public bool SeachSubDirectories
		{
			get{return this._seachSubDirectories;}
			set{this._seachSubDirectories = value;}
		}
		protected string _projectDirectory;
		/// <summary>
		/// The directory in which to seach for code files.
		/// </summary>
		public string ProjectDirectory
		{
			get{return this._projectDirectory;}
			set{this._projectDirectory = value;}
		}
		protected string[] _fileTypes;
		/// <summary>
		/// File types that you wish to seach for. 
		/// </summary>
		public string[] FileTypes
		{
			get{return _fileTypes;}
			set{_fileTypes = value;}
		}
		protected int _lineCount;
		/// <summary>
		/// Returns the total line count for all files after the CountLine method has been called
		/// </summary>
		public int TotalLineCount
		{
			get{return this._lineCount;}
		}
		protected int _commentLineCount;
		/// <summary>
		/// Returns the total comment line count for all files after the CountLine method has been called
		/// </summary>
		public int CommentLineCount
		{
			get{return this._commentLineCount;}
		}
		protected int _emptyLinesCount;
		public int EmptyLineCount
		{
			get{return this._emptyLinesCount;}
		}
		/// <summary>
		/// Count the number of lines accoding to the parameters set in the constuctor or through their property methods
		/// </summary>
		public void CountLines()
		{
			this._lineCount =0;
			this._commentLineCount =0;
			this._emptyLinesCount =0;
			this.GetLineCount(_projectDirectory);
			this._fileNames.TrimToSize();
		}
		string _comment ="//";
		/// <summary>
		/// Count the lines in the specified direcotry name
		/// </summary>
		/// <param name="directoryName"></param>
		private void GetLineCount(string directoryName)
		{
			int LineCount=0;
			
			// This needs to be set to a valid directory
			string myProjectDirectory = directoryName;
			
			DirectoryInfo dir = new DirectoryInfo(directoryName);
			DirectoryInfo[] Directories = dir.GetDirectories();
			if(_seachSubDirectories)
			{
				foreach(DirectoryInfo directory in Directories)
				{
					this.GetLineCount(directory.FullName);
				}
			}
				// this loops file types
			foreach(String sFileType in _fileTypes)
			{
				// this loops files
				foreach (FileInfo file in dir.GetFiles(sFileType)) 
				{
					int fileLineCount = 0;
					int fileCommentLineCount =0;
					int fileEmptyLineCount = 0;
						
					// open files for streamreader
					StreamReader sr = File.OpenText(file.FullName);

					//loop until the end
					bool keepReading = true;
					while (keepReading) 
					{	
						string line = sr.ReadLine();
						
						if(line != null)
						{
							line = line.Trim();
							if(line == "")
								fileEmptyLineCount++;
							else if(line.StartsWith(_comment))
								fileCommentLineCount++;
						
							fileLineCount++;
						}
						else
							keepReading = false;
					}
					
					// add the file info to the FileNames ArrayList
					LineCount += fileLineCount;
					_emptyLinesCount += fileEmptyLineCount;
					_commentLineCount += fileCommentLineCount;
					
					_fileNames.Add(new FileCodeCountInfo(file.Name,file.DirectoryName,fileLineCount,fileCommentLineCount,fileEmptyLineCount));
					//close the streamreader
					sr.Close(); 
				}
			}
			_lineCount += LineCount;
			
		}
	}
	/// <summary>
	/// A struct to store information about the individual files.
	/// </summary>
	public struct FileCodeCountInfo
	{
		public int LineCount;
		public int CommentLineCount;
		public int EmptyLineCount;
		public string FileName;
		public string Directory;
		public FileCodeCountInfo(string fileName, string directory, int lineCount, int commentLineCount, int emptyLineCount)
		{
			this.Directory = directory;
			this.FileName = fileName;
			this.LineCount = lineCount;
			this.CommentLineCount = commentLineCount;
			this.EmptyLineCount = emptyLineCount;
		}
	}
}
