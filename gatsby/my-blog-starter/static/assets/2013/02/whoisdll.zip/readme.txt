WhoisDLL ASP Component
Version 1.00

� C.Small 2001
Bugs + info: sloppycode@sloppycode.net
Website: www.sloppycode.net

Contents
========

1. Introduction
2. Installation
3. Documentation
4. Example usage

1. Introduction
---------------
WhoisDLL is a Whois COM object that makes querying domain names a lot easier. The whois server is automagically found (whois servers aren't hard coded in) by WhoisDLL, and the lookup is then done using this. The server it uses is then available as a property, the whois lookup is performed using one simple method.

2. Installation
---------------
To install this ASP Component for PWS or IIS 4/5, first copy it to your favourite directory, then enter the command prompt by using Start>Run>Command.com (or cmd in Win2k). Use the 'CD' (change directory) command to navigate the directory where you stored the DLL file, and then type

regsvr32 whoisdll.dll

This should register the ASP Component as ready to use by your computer.

3. Documentation
---------------
See the manual.html file that comes with this package.

4. Example Usage
---------------
Example usage can be found in the example.asp file that comes with this package, and also a Visual Basic example, in the 'VisualBasic' folder.