﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Net.Sockets;
using System.Net;
using System.IO.Compression;

namespace SystemIOTests
{
	class Program
	{
		static void Main(string[] args)
		{
			//Tests.ExceptionTests();
		}
	}

	public class Tests
	{
		public static void ExceptionTests()
		{
			byte[] b = new byte[int.MaxValue];

			using ( Stream stream = new FileStream(@"C:\install.log",FileMode.Open) )
			{
				//Stream stream2 = new FileStream( @"C:\install.log", FileMode.Open );
				//byte[] b = new byte[2];
				//stream.Read( b, 2, 1 );
				//stream.WriteByte( 255 );
			}
		}

		public static void StreamReaderTest()
		{
			Stream stream = File.Open( @"c:\INSTALL.LOG", FileMode.Open );
			
			using ( StreamReader reader = new StreamReader( stream ) )
			{
				// Read character by character
				StringBuilder builder = new StringBuilder();
				while ( !reader.EndOfStream )
				{
					builder.Append((char) reader.Read());
				}

				Console.WriteLine( builder .ToString());
			}

			// 0x0A86 is 'આ' in Unicode (Gujarati AA).
			// Casting it to 2 bytes makes it useable as Unicode.
			// This could be removed if we wanted and stick to UTF32
			byte[] buffer = BitConverter.GetBytes( (Int16) 0x0A86 );
			MemoryStream stream2 = new MemoryStream( buffer );

			using ( StreamReader reader = new StreamReader( stream2,Encoding.Unicode ) )
			{
				string contents = reader.ReadToEnd();
			}

			// For NetworkStream, see the other example
			// BufferedStream offers no performance benefit so isn't shown
		}

		public static void StreamWriterTest()
		{
			// Basic test
			using ( StreamWriter writer = new StreamWriter(@"c:\streamwriter.dat") )
			{
				writer.Write(true);
				writer.Write(1234);
				writer.Write("A string");
				writer.WriteLine("A whole line of text!");
				writer.WriteLine(1234);
			}

			// Output:
			//
			// True1234A stringA whole line of text!
			// 1234
			// 
			//

			// Test with MemoryStream
			MemoryStream memoryStream = new MemoryStream( 8 );
			using ( StreamWriter writer = new StreamWriter(memoryStream) )
			{
				writer.Write( "1234" );
			}

			// This only returns the amount of bytes in the MemoryStream, not the capacity
			byte[] buffer = memoryStream.ToArray();

			//
			// Output of buffer with default encoding:
			// 49,50,51,52
			// e.g. The ascii equivalent of those numbers.
			//
			// With unicode it's an 10 byte array, first two are 254,255 (not sure what this is),
			// followed by 49,0,50,0,51,0,52,0
		}

		public static void StreamReaderWriterNetworkTest()
		{
			string host = "codeproject.com";
			string page = "/KB/scripting/HTMLFixedHeaders.aspx";

			TcpClient tcp = new TcpClient();
			tcp.Connect( host, 80 );
			NetworkStream stream = tcp.GetStream();

			// Send a HTTP request
			byte[] data = Encoding.Default.GetBytes( string.Format( "GET {0} HTTP/1.0{1}{1}", page, "\r\n" ) );

			// Make sure you flush or it isn't written out
			StreamWriter writer = new StreamWriter( stream );
			stream.Write( data, 0, data.Length );
			writer.Flush();

			string s = "";
			using ( StreamReader reader = new StreamReader(stream) )
			{
				s = reader.ReadToEnd();
			}

			using ( writer = new StreamWriter( @"c:\out.html" ) )
				writer.Write( s );
		}

		public static void StringWriterTest()
		{
			StringBuilder builder = new StringBuilder();
			using ( StringWriter writer = new StringWriter( builder ) )
			{
				writer.Write( true );
				writer.Write( 12345 );
				writer.Write( (byte) 0x0a );
				writer.WriteLine( "A line of text" );
				writer.Flush();
			}

			Console.WriteLine(builder.ToString());
		}

		public static void StringReaderTest()
		{
			string s = "A line of text\r\nAnother line";
			using ( StringReader reader = new StringReader(s) )
			{
				char next = (char) reader.Peek(); // 65 or A
				reader.Read();
				char[] line = new char[5];

				// line contains ' line'.
				// N.B. the index argument is based on the current pointer position not the
				// string as a whole.
				reader.ReadBlock( line, 0, 5 );
				Console.WriteLine(line);
				Console.WriteLine( reader.ReadLine() );
				
				// ReadLine() has advanced the internal pointer to 'A' from 'Another'.
				reader.Read();// A
				reader.Read();// n
				reader.Read();// o
				Console.WriteLine( reader.ReadToEnd()); // ther line
			}
		}

		public static void BinaryReaderTest()
		{
			using ( FileStream stream = new FileStream( @"c:\binarywriter.dat", FileMode.Open ) )
			{
				BinaryReader reader = new BinaryReader( stream );
				string s = reader.ReadString();
				s = reader.ReadString();
				byte[] b = reader.ReadBytes( (int) stream.Length );
				bool bo = reader.ReadBoolean();
				int i = reader.ReadInt32();
				
				i = reader.ReadInt32();
				i = reader.ReadInt32();
				i = reader.ReadInt32();
				i = reader.ReadInt32();
				i = reader.ReadInt32();
				reader.Close();
			}
		}

        public static void BinaryWriterTest()
        {
            using (FileStream stream = new FileStream(@"c:\binarywriter.dat", FileMode.Create))
            {
                BinaryWriter writer = new BinaryWriter(stream);

				writer.Write( "Hello world" );
				writer.Write( (byte) 255 );
				writer.Write( "Hello world" );

                //
                // Ints
                //
                // Uses 4 bytes to write each int
				writer.Write( 1 ); // 01
				writer.Write( 10 ); // 0a
				writer.Write( 100 ); // 64
				writer.Write( 1000 ); // 3e8
				writer.Write( 10000 ); // 2710
				//writer.Write( 123456789 ); // 75BCD15

                ////The above is displayed as:
                //// 01 00 00 00 0a 00 00 00 64 00 00 00 e8 03 00 00 10 27 00 00 15 cd 5b 07
                //// The output is Little Endian Format, which puts the Least Significant Bit
                //// (LSB) first.

				// Boolean
				//writer.Write( true );
				//writer.Write( false );

				//writer.Write( (Int16) 100 ); // Small int only uses 2 bytes, so 64 00
				//float f = 0.01f; // 3c 23 d7 0a 
				//Write( f );
				// 60
				// 0111 1000
				// 0010 0011
				// 1101 0111
				// 0000 1010
                //writer.Write(f);
                writer.Close();
            }
        }

		public static unsafe void Write(float value)
		{
			// 00111100 00100011 11010111 00001010
			// 1) 00000000 00111100 00100011 11010111
			// 1008981770
			uint num = *( (uint*) &value );
			byte[] _buffer = new byte[4];
			_buffer[0] = (byte) num;
			_buffer[1] = (byte) ( num >> 8 );
			_buffer[2] = (byte) ( num >> 0x10 );
			_buffer[3] = (byte) ( num >> 0x18 );
		}

		public static void FileStreamTest()
		{
			using ( FileStream stream = new FileStream(@"c:\filestream.txt", FileMode.Open) )
			{
				//stream.WriteByte();
			}
		}

		public static void GZipTest()
		{
			
			using ( FileStream fileStream = new FileStream(@"c:\out.html",FileMode.Open))
			{
				// Read the file
				byte[] buffer = new byte[fileStream.Length];
				fileStream.Read(buffer,0,buffer.Length);
				fileStream.Close();

				// Zip the file in memory using a MemoryStream
				MemoryStream memoryStream = new MemoryStream();
				GZipStream gzipStream = new GZipStream( memoryStream,CompressionMode.Compress,true);
				gzipStream.Write( buffer, 0, buffer.Length );
				gzipStream.Close();

				// Write to disk
				FileStream fileStreamOut = new FileStream(@"c:\out.zip",FileMode.Create);
				memoryStream.WriteTo( fileStreamOut );
				fileStreamOut.Close();
			}
		}

		public static void MemoryStreamTest()
		{
			// Ascii/Latin reference:
			// 97  - a
			// 98  - b
			// 100 - c
			// 101 - d
			// 63  - ?
			// ë   - 235

			// 'આ' is from Gujarati (Gujarati in Unicode is from 0A80 - 0AFF). The symbol is U+0A86.
			// 'ë' is from Windows 1252 which is a subset of ISO 8859-2 Latin Alphabet 2 (extended ascii to include accented symbols,
			// special letters and symbols ). This is Symbol #235.
			string s = "abcdeઆë";

			// This will try to translate the Gujarati symbol to ascii, fail and converts
			// it to ascii character 63 (a question mark symbol '?').
			// It will do the same with 'ë' as this isn't an ascii character.
			//
			// Ascii is 8 bit/1 byte per character.
			byte[] b = Encoding.ASCII.GetBytes( s );

			// Windows 1252 is Encoding.Default for most Western users. So this will sucessfully get the right
			// number (235) for 'ë', however the Gujarati symbol will still fail.
			//
			// Windows 1252 is 8 bit/1 byte per character.
			b = Encoding.Default.GetBytes( s );

			// UTF8 is the commonest Unicode encoding, and can encode any Unicode characters. 
			// It uses 1 byte to represent ascii characters, but up to 4 for others.
			b = Encoding.UTF8.GetBytes( s ); // 

			// Now it's 16 bit/2 bytes per char and will pickup the Gujarati symbol correctly.
			// The byte array will now be 14 in length. This is because every character has a numerical
			// 2 byte value (16 bit, 65536 possibilities). Index 10+11 in the array hold the value
			// [10] 134 (86).
			// [11] 10 (0A)
			// (In reverse order).
			// 
			// UTF16 can go up to 4 bytes per character for symbols higher than U+FFFF.
			b = Encoding.Unicode.GetBytes( s );

			// UTF32 translate it to 4 bytes per character, so the array is 32 bytes now.
			b = Encoding.UTF32.GetBytes( s );

			//byte[] b = { 0, 1, 2, 255 };
			//byte[] b = { 0, 1, 2, 256 }; // Compilation error
			MemoryStream stream = new MemoryStream( b );

			// If you want to add extra values to a byte array, just ensure its size is large enough
			// when you create it. For example:
			MemoryStream stream2 = new MemoryStream( 1024 );
			stream2.Write( b, 0, b.Length );
			byte[] buffer = new byte[] { 0, 1, 2, 3 };
			stream2.Write( buffer, 0, buffer.Length );
		}

		public static void NetworkStreamTest()
		{
			string host = "google.com";
			string page = "/search?q=networkstream";

			// This is the simplest way of getting a NetworkStream back. It can also be
			// done at a lower level using your own Socket class and the options you
			// require.
			TcpClient tcp = new TcpClient( );
			tcp.Connect( host, 80);
			NetworkStream stream = tcp.GetStream();

			// Send a HTTP request
			byte[] data = Encoding.Default.GetBytes( string.Format("GET {0} HTTP/1.0{1}{1}",page,"\r\n") );
			stream.Write( data, 0,data.Length);

			// Get the returned data in 1k chunks.
			byte[] buffer = new byte[1024];
			int i = stream.Read( buffer, 0, 1024 );
			StringBuilder builder = new StringBuilder();
			while ( i > 0 )
			{
				builder.Append( Encoding.Default.GetString( buffer ) );
				i = stream.Read( buffer, 0, 1024 );
			}
			
			// Write out to a file. NB the server header will be contained in this file too.
			using ( StreamWriter writer = new StreamWriter(@"c:\out.html") )
				writer.Write( builder.ToString() );
		}

		public static void BufferedStreamTest()
		{
			Stream fileStream = new FileStream( @"C:\testfile-bfs.dat", FileMode.Create );
			BufferedStream bf = new BufferedStream( fileStream );
			bf.Write( new byte[] { 0, 1, 3, 4 }, 0, 4 );
			bf.Close();
		}
	}
}
