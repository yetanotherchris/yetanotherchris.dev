InteliSource
	Created by:		by Ticluse Teknologi
	Compiled on:		January 24, 2001
	Copyright:			� 2001 Ticluse Teknologi, All Rights Reserved.

	Bug Reports:		bugs@intelidev.com
	Questions/Comments:	info@intelidev.com

	Files:
		InteliSource.dll
		Samples:
			Visual Basic sample application
			ASP sample script

	Information:
		InteliSource is a component with allows an application to directly connect to a web server to request a web page. The component returns the source of the file as a string, which can be parsed at will. Secondary routines, such as a function to remove all HTML make this component a must-have for any COM enabled system or application.

	Installation:
		Register the DLL using regsvr32.exe InteliSource.dll
		Place the ASP sample in your web root.