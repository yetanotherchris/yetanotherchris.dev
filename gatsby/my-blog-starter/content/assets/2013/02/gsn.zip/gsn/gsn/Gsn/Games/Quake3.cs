using System;
using System.Net;
using System.Net.Sockets;
using System.Collections;
using System.Text;
using System.Text.RegularExpressions;

namespace Gsn.Games
{
	/// <summary>
	/// 
	/// </summary>
	public class Quake3: Engines.Quake3
	{		
		#region IGameServerQuery events implementation
		/// <summary>
		/// See <see cref="IGameServerQuery.ServerDetailsFinished">IGameServerQuery.Timeout</see>
		/// </summary>
		public override event ServerEventHandler GetServerDetailsFinished;

		/// <summary>
		/// See <see cref="IGameServerQuery.GetServerListFinished">IGameServerQuery.GetServerListFinished</see>
		/// </summary>
		public override event ServerListEventHandler GetServerListFinished;
		#endregion

		#region Quake3 specific properties
		public enum Quake3GameType
		{
			FFA,
			OneOnOneTournament,
			SinglePlayer,
			TeamDeathmatch,
			CTF,
			OneFlagCTF,
			Obelisk,
			Harvester,
			TeamTournament
		}
		public Quake3()
		{
			this.masterIp = "192.246.40.56";
			this.masterPort = 27950;
		}
		#endregion

		#region Public methods
		/// <summary>
		/// See See <see cref="IGameServerQuery.GetServerDetails">IGameServerQuery.GetServerDetails</see>
		/// </summary>
		public override void GetServerDetails(string Ip,int Port)
		{
			base.GetServerDetails(Ip,Port);

			if ( this.serverDetails.AdditionalInfo.ContainsKey("g_gametype") )
			{
				string gametype = (string) this.serverDetails.AdditionalInfo["g_gameType"];
				this.serverDetails.AdditionalInfo["g_gametype"] = (Quake3GameType) Utility.IntParse(gametype);
			}

			// Fire the event to indicate processing is finished
			if ( this.GetServerDetailsFinished != null )
			{
				ServerEventArgs e = new ServerEventArgs();
				e.ServerInfo = this.serverDetails;
				this.GetServerDetailsFinished(this, e);
			}
		}

		/// <summary>
		/// See <see cref="IGameServerQuery.GetServerList">IGameServerQuery.GetServerList</see>
		/// </summary>
		public override void GetServerList()
		{
			base.GetServerList();
		
			if ( this.GetServerListFinished != null )
			{
				ServerListEventArgs e = new ServerListEventArgs();
				e.Servers = this.serverList;
				this.GetServerListFinished(this,e);
			}
		}
		#endregion
	}
}
