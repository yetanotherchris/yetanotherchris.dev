using System;
using System.Collections;

namespace Gsn
{
	#region Server struct + collection
	/// <summary>
	/// Represents a game server for any of the supported games.
	/// </summary>
	public struct Server
	{
		/// <summary>
		/// The IP of the server.
		/// </summary>
		public string Ip;
		/// <summary>
		/// The port the server is using.
		/// </summary>
		public int Port;
		/// <summary>
		/// The hostname for the server.
		/// </summary>
		public string Hostname;
		/// <summary>
		/// Whether the server requires a password to connect.
		/// </summary>
		public bool PasswordProtected;
		/// <summary>
		/// The name of the map in use on the server.
		/// </summary>
		public string Map;
		/// <summary>
		/// The name of the mod in use, if any, on the server.
		/// For example, Counter Strike, Day of Defeat.
		/// </summary>
		public string ModName;
		/// <summary>
		/// The number of players on the server.
		/// </summary>
		public int PlayerCount;
		/// <summary>
		/// The maximum number of players the server can hold.
		/// </summary>
		public int MaxPlayers;
		/// <summary>
		/// Holds any additional rules or server name/values that
		/// are sent by the server when its status is requested
		/// by GSN.
		/// </summary>
		public Hashtable AdditionalInfo;
		/// <summary>
		/// A collection of Player objects, each one representing
		/// a player on the server.
		/// </summary>
		public PlayerCollection Players;
	}

	/// <summary>
	/// Represents a collection of Server objects. This
	/// is currently un-used in the GSN library, it
	/// will be used in the future when master-server
	/// querying is built in.
	/// </summary>
	public class ServerCollection : CollectionBase
	{
		/// <summary>
		/// Add a server to the collection.
		/// </summary>
		/// <param name="server"></param>
		public void Add(Server server)
		{
			List.Add(server);
		}

		/// <summary>
		/// Remove a server from the collection.
		/// </summary>
		/// <param name="index">The index of the server to remove.</param>
		/// <returns>True if the remove was sucessful,
		/// false otherwise.</returns>
		public bool Remove(int index)
		{
			if (index > Count - 1 || index < 0)
			{
				return false;
			}
			else
			{
				List.RemoveAt(index);
				return true;
			}
		}

		/// <summary>
		/// Retrieves a server object from the index
		/// in the collection.
		/// </summary>
		/// <param name="Index">The index of the server to remove.</param>
		/// <returns>A server object</returns>
		public Server Item(int Index)
		{
			return (Server) List[Index];
		}
	}
	#endregion

	#region Player struct + collection
	/// <summary>
	/// Represents a single player on a server.
	/// </summary>
	public struct Player
	{
		/// <summary>
		/// The name of the player.
		/// </summary>
		public string Name;
		/// <summary>
		/// The player's score.
		/// </summary>
		public int Score;
		/// <summary>
		/// The amount of time the player has spent
		/// on the server (if available).
		/// </summary>
		public TimeSpan Time;
		/// <summary>
		/// The player's ping (if available).
		/// </summary>
		public int Ping;
		/// <summary>
		/// The amount times the player has died (if available).
		/// </summary>
		public int Deaths;
		/// <summary>
		/// A number indicating the team the player is on (if available).
		/// </summary>
		public int Team;
		/// <summary>
		/// Any other information relating to the player, is stored
		/// inside this, for example the Hashkey in Battlefield 1942.
		/// </summary>
		public Hashtable AdditionalInfo;
	}

	/// <summary>
	/// Represents a collection of Player objects.
	/// This is used inside the <see cref="Server">Server</see>
	/// object to hold details about all the players on the server.
	/// </summary>
	public class PlayerCollection : CollectionBase
	{
		/// <summary>
		/// Adds a player to the collection.
		/// </summary>
		/// <param name="player">The player object to add.</param>
		public void Add(Player player)
		{
			List.Add(player);
		}

		/// <summary>
		/// Removes a player from the collection
		/// </summary>
		/// <param name="index">The index of the player to remove.</param>
		/// <returns>True if the remove was sucessful,
		/// false otherwise.</returns>
		public bool Remove(int index)
		{
			if (index > Count - 1 || index < 0)
			{
				return false;
			}
			else
			{
				List.RemoveAt(index);
				return true;
			}
		}

		/// <summary>
		/// Retrieves a player object from the index
		/// in the collection.
		/// </summary>
		/// <param name="Index">The index of the player to remove.</param>
		/// <returns>A player object</returns>
		public Player Item(int Index)
		{
			return (Player) List[Index];
		}
	}	
	#endregion

	#region Events
	/// <summary>
	/// Holds information about the server previously queried.
	/// </summary>
	public class ServerEventArgs : EventArgs
	{
		/// <summary>
		/// A server object holding information about
		/// the server just queried.
		/// </summary>
		public Server ServerInfo
		{
			get
			{
				return this.serverInfo;
			}
			set
			{
				this.serverInfo = value;
			}
		}
		private Server serverInfo;
	}

	/// <summary>
	/// Holds information about the master server previously queried.
	/// </summary>
	public class ServerListEventArgs : EventArgs
	{
		/// <summary>
		/// An array of ip:port numbers for the
		/// master server that was just queried.
		/// </summary>
		public ArrayList Servers
		{
			get
			{
				return this.servers;
			}
			set
			{
				this.servers = value;
			}
		}
		private ArrayList servers;
	}

	/// <summary>
	/// The event handler for the Server event.
	/// </summary>
	public delegate void ServerEventHandler(object sender, ServerEventArgs e);

	/// <summary>
	/// The event handler for the ServerList event.
	/// </summary>
	public delegate void ServerListEventHandler(object sender, ServerListEventArgs e);
	#endregion

	#region IGameServerQuery interface
	/// <summary>
	/// Summary description for IGsnQuery.
	/// </summary>
	public interface IGameServerQuery
	{
		/// <summary>
		/// How long the connection to the server waits for with no reply,
		/// before quiting.
		/// </summary>
		int Timeout { get;set; }

		/// <summary>
		/// This holds the Server object for the server that was
		/// previously queried. This object is also provided in the
		/// ServerEventArgs object in the GetServerDetailsFinished event.
		/// </summary>
		Server ServerDetails { get;set; }

		/// <summary>
		/// This holds the list of ips for master server that was
		/// just queried. The format is ip:port.
		/// This object is also provided in the
		/// ServerListEventArgs object in the GetServerListFinished event.
		/// </summary>
		ArrayList ServerList { get;set; }

		/// <summary>
		/// The ip of the master server to query.
		/// </summary>
		string MasterServerIp { get;set; }
 
		/// <summary>
		/// The port number of the master server to query.
		/// </summary>
		int MasterServerPort { get;set; }

		/// <summary>
		/// Retrieves information for a server, using the ip/port
		/// provided. Once the operation is complete, the GetServerDetailsFinished
		/// event is fired. This provides a Server object in the ServerEventArgs object,
		/// this same object is also in the ServerDetails property.
		/// <remarks>
		/// The GetServerDetailsFinished event is not automatically fired by the
		/// Engine classes. If you are creating a class for a game that is not
		/// supported by GSN, and wish to subclass one of the Engine classes,, you will need
		/// to fire the event manually yourself, 
		/// <example>
		/// <code>
		/// if ( this.GetServerDetailsFinished != null )
		/// {
		///		this.GetServerDetailsFinished(this,new EventArgs());
		/// }
		/// </code>
		/// </example>
		/// </remarks>
		/// </summary>
		/// <param name="Ip">The ip of the server to query.</param>
		/// <param name="Port">The port number of the server to query.</param>
		void GetServerDetails(string Ip,int Port);

		/// <summary>
		/// Retrieves a list of servers for the game. This is done by using
		/// a 'master server' which returns a list of ip:ports. Not all games
		/// provide this information, some prefer to keep it locked from public useage.
		/// Once the operation is complete, the GetServerListFinished event
		/// is fired. This provides an ArrayList object in the ServerEventArgs object,
		/// this same object is also in the ServerList property. The master server
		/// to query is set using the MasterServerIp and MasterServerPort properties.
		/// <remarks>
		/// The GetServerListFinished event is not automatically fired by the
		/// Engine classes. If you are creating a class for a game that is not
		/// supported by GSN, and wish to subclass one of the Engine classes,, you will need
		/// to fire the event manually yourself, 
		/// <example>
		/// <code>
		/// if ( this.GetServerListFinished != null )
		/// {
		///		this.GetServerListFinished(this,new EventArgs());
		/// }
		/// </code>
		/// </example>
		/// </remarks>
		/// </summary>
		void GetServerList();

		/// <summary>
		/// This event is fired when the GetServerDetails method has finished
		/// querying the game server. The second parameter in the event handler
		/// contains a ServerEventArgs object, which contains information
		/// about the server just queried. The ServerDetails property also contains
		/// the same information.
		/// </summary>
		event ServerEventHandler GetServerDetailsFinished;

		/// <summary>
		/// This event is fired when the GetServerList method has finished
		/// querying the game server. The second parameter in the event handler
		/// contains a ServerListEventArgs object, which contains an ArrayList
		/// of all the servers returned. The ServerList property also contains
		/// the same ArrayList.
		/// </summary>
		event ServerListEventHandler GetServerListFinished;
	}
	#endregion
}
