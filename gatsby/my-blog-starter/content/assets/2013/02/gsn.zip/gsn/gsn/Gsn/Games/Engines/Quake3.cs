using System;
using System.Net;
using System.Net.Sockets;
using System.Collections;
using System.Text;
using System.Text.RegularExpressions;

namespace Gsn.Games.Engines
{
	/// <summary>
	/// 
	/// </summary>
	public class Quake3 : IGameServerQuery
	{				  
		#region IGameServerQuery implementation
		/// <summary>
		/// See <see cref="IGameServerQuery.Timeout">IGameServerQuery.Timeout</see>
		/// </summary>
		public int Timeout 
		{ 
			get
			{
				return this.timeout;
			}
			set
			{
				this.timeout = value;
			}
		}

		/// <summary>
		/// See <see cref="IGameServerQuery.ServerDetails">IGameServerQuery.ServerDetails</see>
		/// </summary>
		public Server ServerDetails
		{ 
			get
			{
				return this.serverDetails;
			}
			set
			{
				this.serverDetails = value;
			}
		}

		/// <summary>
		/// See <see cref="IGameServerQuery.ServerList">IGameServerQuery.ServerList</see>
		/// </summary>
		public ArrayList ServerList
		{ 
			get
			{
				return this.serverList;
			}
			set
			{
				this.serverList = value;
			}
		}

		/// <summary>
		/// See <see cref="IGameServerQuery.MasterServerIp">IGameServerQuery.MasterServerIp</see>
		/// </summary>
		public string MasterServerIp 
		{ 
			get
			{
				return this.masterIp;
			}
			set
			{
				this.masterIp = value;
			}
		}

		/// <summary>
		/// See <see cref="IGameServerQuery.MasterServerPort">IGameServerQuery.MasterServerPort</see>
		/// </summary>
		public int MasterServerPort 
		{ 
			get
			{
				return this.masterPort;
			}
			set
			{
				this.masterPort = value;
			}
		}

		/// <summary>
		/// See <see cref="IGameServerQuery.ServerDetailsFinished">IGameServerQuery.Timeout</see>
		/// </summary>
		public virtual event ServerEventHandler GetServerDetailsFinished;

		/// <summary>
		/// See <see cref="IGameServerQuery.GetServerListFinished">IGameServerQuery.GetServerListFinished</see>
		/// </summary>
		public virtual event ServerListEventHandler GetServerListFinished;

		/// <summary>
		/// Private member for the public property.
		/// </summary>
		protected int timeout = 10000;

		/// <summary>
		/// Private member for the public property.
		/// </summary>
		protected string masterIp = "192.246.40.56";

		/// <summary>
		/// Private member for the public property.
		/// </summary>
		protected int masterPort = 27950;

		/// <summary>
		/// Private member for the public property.
		/// </summary>
		protected ArrayList serverList;

		/// <summary>
		/// Private member for the public property.
		/// </summary>
		protected Server serverDetails;
		#endregion

		#region Quake3 Engine specific properties
		public bool StripPlayernameColors 
		{ 
			get
			{
				return this.stripPlayernameColors;
			}
			set
			{
				this.stripPlayernameColors = value;
			}
		}
		protected bool stripPlayernameColors = true;
		protected string statusCommand = "\xff\xff\xff\xffgetstatus\x0";
		protected string responseHeader = "\xff\xff\xff\xffstatusResponse\x0a\\";
		protected string masterStatusCommand = "\xff\xff\xff\xffgetservers";
		protected string masterResponseHeader = "\xff\xff\xff\xffgetserversResponse\\";
		protected int masterProtocolVersion = 68;

		#endregion

		#region Public methods
		/// <summary>
		/// See See <see cref="IGameServerQuery.GetServerDetails">IGameServerQuery.GetServerDetails</see>
		/// </summary>
		public virtual void GetServerDetails(string Ip,int Port)
		{
			this.serverDetails = new Server();
			this.serverDetails.AdditionalInfo = new Hashtable();
			this.serverDetails.Players = new PlayerCollection();

			// Server info
			this.serverDetails.Ip = Ip;
			this.serverDetails.Port = Port;

			UdpHelper udpHelper = new UdpHelper();
			udpHelper.Timeout = 10000;
			string response = udpHelper.GetUdpResponse(Ip,Port,this.statusCommand);

			// Was there a reply?
			if ( response.StartsWith(this.responseHeader) )
			{
				// 4 xff , statusResponse, x0a and \ = 
				response = response.Substring(this.responseHeader.Length,response.Length - this.responseHeader.Length);
				
				// Player names start with "...(needs checking)
				int start = response.IndexOf("\n");

				if ( start != -1 )
				{
					string serverinfo = response.Substring(0,start);
					string playerinfo = response.Substring(start+1,response.Length - (start +1) );

					this.getServerInfo(serverinfo);
					this.getPlayers(playerinfo);
				}

			}
			else
			{
				this.serverDetails.Map = "None";
				this.serverDetails.Hostname = "Unable to connect";
			}
		}

		/// <summary>
		/// See <see cref="IGameServerQuery.GetServerList">IGameServerQuery.GetServerList</see>
		/// </summary>
		public virtual void GetServerList()
		{
			//����getservers 57
			this.serverList = new ArrayList();

			UdpHelper udpHelper = new UdpHelper();
			udpHelper.Timeout = 1000;
			string response = udpHelper.GetUdpResponse(this.masterIp,this.masterPort,this.masterStatusCommand+ " " +this.masterProtocolVersion);

			// Was there a reply?
			if ( response.StartsWith(this.masterResponseHeader) )
			{
				// 4 xff , statusResponse, x0a and \ = 
				response = response.Substring(this.masterResponseHeader.Length,response.Length - this.masterResponseHeader.Length);
				
				if ( response != "" )
				{
					string[] servers = response.Split('\\');
					string ip;
					int port;
					int port1;
					int port2;

					for (int i=0; i < servers.Length;i++)
					{
						if ( servers[i].Length == 6 )
						{
							ip = "";
							ip += ((int) servers[i][0]) + ".";
							ip += ((int) servers[i][1]) + ".";
							ip += ((int) servers[i][2]) + ".";
							ip += ((int) servers[i][3]);

							port1 = (int) servers[i][4];
							port2 = (int) servers[i][5];

							port = (port1 * 256) + port2;

							this.serverList.Add(ip+ ":" +port);						
						}

					}
				}

			}
		}
		#endregion

		#region Protected methods
		protected virtual void getServerInfo(string serverinfo)
		{
			string[] parts= serverinfo.Split('\\');

			for (int i=0;i < parts.Length;i+=2)
			{
				switch (parts[i])
				{
					case "mapname":
						if ( parts.Length >= i+1)
							this.serverDetails.Map = parts[i+1];
						break;
					case "sv_hostname":
						if ( parts.Length >= i+1 )
							this.serverDetails.Hostname = parts[i+1];
						break;
					case "sv_maxclients":
						if ( parts.Length >= i+1 )
							this.serverDetails.MaxPlayers = Utility.IntParse(parts[i+1]);
						break;
					case "sv_needpass":
						if ( parts.Length >= i+1 )
							this.serverDetails.PasswordProtected = Utility.BoolParse(parts[i+1]);
						break;
					default:
						if ( parts.Length > i+1 && ! this.serverDetails.AdditionalInfo.ContainsKey(parts[i]) )
						{
							this.serverDetails.AdditionalInfo.Add(parts[i],parts[i+1] );
						}
						break;
				}
			}
		}

		protected virtual void getPlayers(string playerinfo)
		{
			Player player;
			// If only Valve had done it this way..
			string[] players = playerinfo.Split('\n');
			this.serverDetails.PlayerCount = players.Length;

			// Format: score ping name
			for (int i=0;i < players.Length;i++)
			{
				int nameStart = players[i].IndexOf("\"");

				if ( nameStart != -1 )
				{
					player = new Player();

					string info = players[i].Substring(0,nameStart);
					string name = players[i].Substring(nameStart,players[i].Length - nameStart);

					// Format: "name" """
					name = name.Substring(1,name.Length-2);

					// Remove colour coding if specified
					if ( this.stripPlayernameColors )
					{
						Regex regex = new Regex("\\^[0-9]",RegexOptions.IgnorePatternWhitespace);
						name = regex.Replace(name,"");
					}

					player.Name = name;

					// Ping and frags
					if ( info.IndexOf(" ") != -1 )
					{
						info = info.TrimEnd(new Char[] {' '});

						string[] infoParts = info.Split(' ');

						if ( infoParts.Length == 2 )
						{
							player.Score = Utility.IntParse(infoParts[0]);
							player.Ping  = Utility.IntParse(infoParts[1]);
						}
					}

					this.serverDetails.Players.Add(player);
				}
			}
		}
		#endregion
	}
}
