using System;
using System.Collections;

namespace Gsn
{
	/// <summary>
	/// Summary description for Utility.
	/// </summary>
	public class Utility
	{
		/// <summary>
		/// Whether the string contains a parseable number or not.
		/// </summary>
		/// <param name="o">The string to parse</param>
		/// <returns>True if the string could be parsed to a number,
		/// otherwise false.</returns>
		public static bool IsNumeric(string o)
		{
			try
			{
				int.Parse(o);
				return true;
			}
			catch
			{
				return false;
			}
		}

		/// <summary>
		/// Just a wrapper for int.Parse, reducing 8
		/// lines of code into one call.
		/// </summary>
		/// <param name="o">The string to parse</param>
		/// <returns>0 if the string couldn't be parsed,
		/// otherwise the number.</returns>
		public static int IntParse(string o)
		{
			try
			{
				return int.Parse(o);
			}
			catch
			{
				return 0;
			}
		}

		/// <summary>
		/// Just a wrapper for bool.Parse, reducing 8
		/// lines of code into one call.
		/// </summary>
		/// <param name="o">The string to parse</param>
		/// <returns>false if the string couldn't be parsed,
		/// otherwise the string as a boolean.</returns>
		public static bool BoolParse(string o)
		{
			try
			{
				return bool.Parse(o);
			}
			catch
			{
				return false;
			}
		}

		/// <summary>
		/// Similar to the String.Split method, except this method
		/// splits a string using a string as the token.
		/// </summary>
		/// <param name="Token">The token to split the string with.</param>
		/// <param name="Contents">The string to tokenize.</param>
		/// <returns>As with the String.Split method, Tokenize
		/// returns an array of strings, from the tokens found in the 
		/// Contents string.</returns>
		public static string[] Tokenize(string Token,string Contents)
		{
			ArrayList arrayList = new ArrayList();

			if ( Contents.IndexOf(Token) != -1 )
			{
				int pos = 0;
				int n = 0;
				string tmp = "";

				while ( n < Contents.Length)
				{
					pos = Contents.IndexOf(Token,n);

					if ( pos == -1 ) 
					{
						pos = Contents.Length;
					}
					tmp = Contents.Substring(n,pos - n);
					arrayList.Add(tmp);

					n = pos + Token.Length;
				}

			}

			string[] result = new string[arrayList.Count];
			for (int i=0;i < arrayList.Count;i++)
			{
				result.SetValue(arrayList[i],i);
			}

			return result;
			
		}
	}
}
