using System;
using System.Net;
using System.Net.Sockets;
using System.Collections;
using System.Text;

namespace Gsn.Games
{
	/// <summary>
	/// Summary description for UnrealTournament.
	/// </summary>
	public class UnrealTournament : IGameServerQuery
	{				  
		#region IGameServerQuery implementation
		/// <summary>
		/// See <see cref="IGameServerQuery.Timeout">IGameServerQuery.Timeout</see>
		/// </summary>
		public int Timeout 
		{ 
			get
			{
				return this.timeout;
			}
			set
			{
				this.timeout = value;
			}
		}

		/// <summary>
		/// See <see cref="IGameServerQuery.ServerDetails">IGameServerQuery.ServerDetails</see>
		/// </summary>
		public Server ServerDetails
		{ 
			get
			{
				return this.serverDetails;
			}
			set
			{
				this.serverDetails = value;
			}
		}

		/// <summary>
		/// See <see cref="IGameServerQuery.ServerList">IGameServerQuery.ServerList</see>
		/// </summary>
		public ArrayList ServerList
		{ 
			get
			{
				return this.serverList;
			}
			set
			{
				this.serverList = value;
			}
		}

		/// <summary>
		/// See <see cref="IGameServerQuery.MasterServerIp">IGameServerQuery.MasterServerIp</see>
		/// </summary>
		public string MasterServerIp 
		{ 
			get
			{
				return this.masterIp;
			}
			set
			{
				this.masterIp = value;
			}
		}

		/// <summary>
		/// See <see cref="IGameServerQuery.MasterServerPort">IGameServerQuery.MasterServerPort</see>
		/// </summary>
		public int MasterServerPort 
		{ 
			get
			{
				return this.masterPort;
			}
			set
			{
				this.masterPort = value;
			}
		}

		/// <summary>
		/// See <see cref="IGameServerQuery.ServerDetailsFinished">IGameServerQuery.Timeout</see>
		/// </summary>
		public virtual event ServerEventHandler GetServerDetailsFinished;

		/// <summary>
		/// See <see cref="IGameServerQuery.GetServerListFinished">IGameServerQuery.GetServerListFinished</see>
		/// </summary>
		public virtual event ServerListEventHandler GetServerListFinished;

		/// <summary>
		/// Private member for the public property.
		/// </summary>
		protected int timeout = 10000;

		/// <summary>
		/// Private member for the public property.
		/// </summary>
		protected string masterIp = "192.246.40.56";

		/// <summary>
		/// Private member for the public property.
		/// </summary>
		protected int masterPort = 27950;

		/// <summary>
		/// Private member for the public property.
		/// </summary>
		protected ArrayList serverList;

		/// <summary>
		/// Private member for the public property.
		/// </summary>
		protected Server serverDetails;
		#endregion

		/// <summary>
		/// See See <see cref="IGameServerQuery.GetServerDetails">IGameServerQuery.GetServerDetails</see>
		/// </summary>
		public void GetServerDetails(string Ip,int Port)
		{
		}

		/// <summary>
		/// See <see cref="IGameServerQuery.GetServerList">IGameServerQuery.GetServerList</see>
		/// </summary>
		public void GetServerList()
		{

		}
	}
}

