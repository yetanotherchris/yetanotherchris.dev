using System;
using System.Net;
using System.Net.Sockets;
using System.Collections;
using System.Text;

namespace Gsn.Games
{
	/// <summary>
	/// Summary description for Battlefield1942.
	/// </summary>
	public class ReturnToCastleWolfenstein : Engines.Quake3
	{
		#region IGameServerQuery events implementation
		/// <summary>
		/// See <see cref="IGameServerQuery.ServerDetailsFinished">IGameServerQuery.Timeout</see>
		/// </summary>
		public override event ServerEventHandler GetServerDetailsFinished;

		/// <summary>
		/// See <see cref="IGameServerQuery.GetServerListFinished">IGameServerQuery.GetServerListFinished</see>
		/// </summary>
		public override event ServerListEventHandler GetServerListFinished;
		#endregion

		#region Public methods
		/// <summary>
		/// See See <see cref="IGameServerQuery.GetServerDetails">IGameServerQuery.GetServerDetails</see>
		/// </summary>
		public override void GetServerDetails(string Ip,int Port)
		{
			base.GetServerDetails(Ip,Port);

			// Password protected is taken from a different 
			// variable, so adjust this.


			// Fire the event to indicate processing is finished
			if ( this.GetServerDetailsFinished != null )
			{
				ServerEventArgs e = new ServerEventArgs();
				e.ServerInfo = this.serverDetails;
				this.GetServerDetailsFinished(this, e);
			}
		}

		/// <summary>
		/// See <see cref="IGameServerQuery.GetServerList">IGameServerQuery.GetServerList</see>
		/// </summary>
		public override void GetServerList()
		{

		}
		#endregion
	}
}




