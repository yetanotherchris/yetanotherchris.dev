using System;
using System.Net;
using System.Net.Sockets;
using System.Text;


namespace BF1942
{

	public class UdpClientNew : UdpClient
	{

		public Socket Socket
		{
			get { return this.Client; }
			set
			{
				if ( value == null )
					throw new ArgumentNullException("Socket", "Socket is null.");
				this.Client = value;
			}
		}

		private byte[] bufferSend;
		private byte[] bufferReceive = new byte[1024*1024];
		private object stateObjectSend = new Object();
		private object stateObjectReceive = new Object();
		private EndPoint destEp;
		private EndPoint remoteEp;
		private string result = "";
		public event UdpEventHandler done;
		


		public void SendReceiveUT2003(byte[] dgram, IPEndPoint destEP, ref IPEndPoint remoteEP)
		{
			if ( dgram == null || destEP == null )
			{
				return;
			}

			this.bufferSend = dgram;
			destEp = (EndPoint) destEP;
			remoteEp = (EndPoint) remoteEP;
			result = "";

			this.Socket.BeginSendTo(this.bufferSend,0,this.bufferSend.Length,SocketFlags.None,this.destEp,new AsyncCallback(this.beginSendTo),this.stateObjectSend);			
		}
		private void beginSendTo(IAsyncResult ar)
		{
			int bytesSent = this.Socket.EndSendTo(ar);

			if ( bytesSent > 0 )
			{
				this.Socket.BeginReceiveFrom(this.bufferReceive,0,bufferReceive.Length,SocketFlags.None,ref this.remoteEp,new AsyncCallback(this.beginReceiveFrom),this.stateObjectReceive);
			}
			/*
			int r = this.Socket.EndSendTo(ar);
			if ( r > 0 )
			{
				this.Socket.BeginSendTo(this.bufferSend,0,bufferSend.Length,SocketFlags.None,ep,new AsyncCallback(this.beginSendTo),stateObject);
			}
			else
			{
				this.Socket.BeginReceiveFrom(this.bufferReceive,0,bufferReceive.Length,SocketFlags.None,ref ep,new AsyncCallback(this.beginReceiveFrom),stateObject);
			}*/
		}


		// Stick a breakpoint here
		private void beginReceiveFrom(IAsyncResult ar)
		{
			int r = this.Socket.EndReceiveFrom(ar,ref this.remoteEp);
			System.Diagnostics.Debug.WriteLine("Bytes received: "+r);

			if ( r > 0 )
			{
				result += Encoding.Default.GetString(bufferReceive);

				// Resetup the sending function pointer (ala MS example code)
				this.Socket.BeginReceiveFrom(this.bufferReceive,0,bufferReceive.Length,SocketFlags.None,ref this.remoteEp,new AsyncCallback(this.beginReceiveFrom),this.stateObjectReceive);
			}

			// Call the "Done" event once all the packets are received
			if ( this.done != null )
			{
				UdpEventArgs e = new UdpEventArgs();
				e.Packets = this.result;
				this.done(this,e);
			}
		}
		
	}

	// Custom event stuff
	public delegate void UdpEventHandler(object sender,UdpEventArgs e);

	public class UdpEventArgs : EventArgs
	{
		public string Packets;
	}

}
