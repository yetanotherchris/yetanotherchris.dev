using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using System.Net;
using System.Net.Sockets;
using System.Text;

namespace UdpTest
{
	public class Form1 : System.Windows.Forms.Form
	{
		#region Components
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Panel panel2;
		private System.ComponentModel.IContainer components;
		private System.Windows.Forms.StatusBar statusBar1;
		#endregion

		#region Members
		private IPEndPoint fromIPEndPoint = new IPEndPoint(IPAddress.Any,0);	
		
		// Half life :
		private IPEndPoint toIPEndPoint = new IPEndPoint(IPAddress.Parse("213.230.204.28"),27050);
		private System.Windows.Forms.Button button4;
		private System.Windows.Forms.Timer timer1;
		private System.Windows.Forms.ListView listView1;
		private System.Windows.Forms.ColumnHeader columnHeader1;
		private System.Windows.Forms.ColumnHeader columnHeader2;
		private System.Windows.Forms.ColumnHeader columnHeader3;
		private System.Windows.Forms.Button button5;
		private string command = "\xff\xff\xff\xffplayers\x0";

		// Bf1942
		//private IPEndPoint toIPEndPoint = new IPEndPoint(IPAddress.Parse("213.186.35.63"),23000);
		//private string command = "\\status\\";
		#endregion

		#region Constructor,dispose,main
		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}
		#endregion

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.button3 = new System.Windows.Forms.Button();
			this.panel1 = new System.Windows.Forms.Panel();
			this.listView1 = new System.Windows.Forms.ListView();
			this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
			this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
			this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
			this.statusBar1 = new System.Windows.Forms.StatusBar();
			this.panel2 = new System.Windows.Forms.Panel();
			this.button4 = new System.Windows.Forms.Button();
			this.timer1 = new System.Windows.Forms.Timer(this.components);
			this.button5 = new System.Windows.Forms.Button();
			this.panel1.SuspendLayout();
			this.panel2.SuspendLayout();
			this.SuspendLayout();
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(8, 8);
			this.button1.Name = "button1";
			this.button1.TabIndex = 0;
			this.button1.Text = "UdpClient";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(96, 8);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(96, 23);
			this.button2.TabIndex = 1;
			this.button2.Text = "TimedUdpClient";
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// button3
			// 
			this.button3.Location = new System.Drawing.Point(208, 8);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(112, 23);
			this.button3.TabIndex = 2;
			this.button3.Text = "UdpClientNew";
			this.button3.Click += new System.EventHandler(this.button3_Click);
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.listView1);
			this.panel1.Controls.Add(this.statusBar1);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel1.Location = new System.Drawing.Point(0, 40);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(640, 246);
			this.panel1.TabIndex = 3;
			// 
			// listView1
			// 
			this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																						this.columnHeader1,
																						this.columnHeader2,
																						this.columnHeader3});
			this.listView1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.listView1.Location = new System.Drawing.Point(0, 0);
			this.listView1.Name = "listView1";
			this.listView1.Size = new System.Drawing.Size(640, 224);
			this.listView1.Sorting = System.Windows.Forms.SortOrder.Descending;
			this.listView1.TabIndex = 7;
			this.listView1.View = System.Windows.Forms.View.Details;
			// 
			// columnHeader1
			// 
			this.columnHeader1.Text = "name";
			this.columnHeader1.Width = 200;
			// 
			// columnHeader2
			// 
			this.columnHeader2.Text = "score";
			// 
			// columnHeader3
			// 
			this.columnHeader3.Text = "time";
			this.columnHeader3.Width = 150;
			// 
			// statusBar1
			// 
			this.statusBar1.Location = new System.Drawing.Point(0, 224);
			this.statusBar1.Name = "statusBar1";
			this.statusBar1.Size = new System.Drawing.Size(640, 22);
			this.statusBar1.TabIndex = 6;
			// 
			// panel2
			// 
			this.panel2.Controls.Add(this.button5);
			this.panel2.Controls.Add(this.button4);
			this.panel2.Controls.Add(this.button1);
			this.panel2.Controls.Add(this.button2);
			this.panel2.Controls.Add(this.button3);
			this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel2.Location = new System.Drawing.Point(0, 0);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(640, 40);
			this.panel2.TabIndex = 4;
			// 
			// button4
			// 
			this.button4.Location = new System.Drawing.Point(336, 8);
			this.button4.Name = "button4";
			this.button4.TabIndex = 3;
			this.button4.Text = "timer on/off";
			this.button4.Click += new System.EventHandler(this.button4_Click);
			// 
			// timer1
			// 
			this.timer1.Interval = 1000;
			this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
			// 
			// button5
			// 
			this.button5.Location = new System.Drawing.Point(424, 8);
			this.button5.Name = "button5";
			this.button5.TabIndex = 4;
			this.button5.Text = "hl master";
			this.button5.Click += new System.EventHandler(this.button5_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(640, 286);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.panel2);
			this.Name = "Form1";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Form1";
			this.panel1.ResumeLayout(false);
			this.panel2.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		#region Event handlers
		private void button1_Click(object sender, System.EventArgs e)
		{
			TimeSpan start = new TimeSpan(DateTime.Now.Ticks);
			this.Cursor = Cursors.WaitCursor;
			
			UdpClient udpClient = new UdpClient();
			string result = "";
			byte[] sendData = Encoding.Default.GetBytes(this.command);
			byte[] recvData;

			udpClient.Send(sendData,sendData.Length,toIPEndPoint);
			recvData = udpClient.Receive(ref fromIPEndPoint);

			while ( recvData != null )
			{
				result += Encoding.Default.GetString(recvData);
				recvData = udpClient.Receive(ref fromIPEndPoint);

			} // for UT: && result.IndexOf("\\final\\") == -1 );

			result = result.Replace("\x0","(0)");
			//this.richTextBox1.Text = result;

			this.Cursor = Cursors.Default;

			TimeSpan end = new TimeSpan(DateTime.Now.Ticks);
			TimeSpan timeTaken = end - start;
			this.statusBar1.Text =  timeTaken.Seconds + "." +timeTaken.TotalMilliseconds+ " seconds taken.";
		}

		private void button2_Click(object sender, System.EventArgs e)
		{
			TimeSpan start = new TimeSpan(DateTime.Now.Ticks);
			this.Cursor = Cursors.WaitCursor;

			TimedUdpClient udpClient = new TimedUdpClient();
			string result = "";
			byte[] sendData = Encoding.Default.GetBytes(this.command);
			byte[] recvData;

			udpClient.Send(sendData,sendData.Length,toIPEndPoint);

			do
			{
				recvData = udpClient.Receive(ref fromIPEndPoint);

				if ( recvData != null )
				{
					result += Encoding.Default.GetString(recvData);
				}		

			} while ( recvData != null );

			result = result.Replace("\x0","(0)");
			//this.richTextBox1.Text = result;

			this.Cursor = Cursors.Default;
			TimeSpan end = new TimeSpan(DateTime.Now.Ticks);
			TimeSpan timeTaken = end - start;
			this.statusBar1.Text =  timeTaken.Seconds + "." +timeTaken.TotalMilliseconds+ " seconds taken.";
		}

		private void button3_Click(object sender, System.EventArgs e)
		{
			TimeSpan start = new TimeSpan(DateTime.Now.Ticks);
			this.Cursor = Cursors.WaitCursor;

			UdpClientNew udpClient = new UdpClientNew();
			byte[] sendData = Encoding.Default.GetBytes(this.command);
			string result = udpClient.SendReceiveHalfLife(sendData,this.toIPEndPoint,ref this.fromIPEndPoint);

			//result = result.Replace("\x0","\r\n");
			this.listView1.Items.Clear();
			this.getPlayers(result);

			this.Cursor = Cursors.Default;
			TimeSpan end = new TimeSpan(DateTime.Now.Ticks);
			TimeSpan timeTaken = end - start;
			this.statusBar1.Text =  timeTaken.Seconds + "." +timeTaken.TotalMilliseconds+ " seconds taken.";
		}

		#endregion

		private void button4_Click(object sender, System.EventArgs e)
		{
			this.timer1.Enabled = ! this.timer1.Enabled;
		}

		private void timer1_Tick(object sender, System.EventArgs e)
		{
			this.button3_Click(null,null);
		}

		private void button5_Click(object sender, System.EventArgs e)
		{
			UdpClientNew udp = new UdpClientNew();
			ArrayList arrayList = udp.hlMaster();
		}

		private void getPlayers(string data)
		{
			if ( data.Length > 6 )
			{
				//Player player;
				int start = 0;
				int end = 0;
				int tmpend = 0;
				string tmp ="";
				//Remove FF FF FF FF 44 04 01
				data = data.Substring(6,data.Length - 7);

				while (start < data.Length)
				{
					// Order of info: index,playername,0,8bytes of info	
					end = data.IndexOf("\x0",start);
					if ( end >0 && end +9 < data.Length )
					{
						tmp = data.Substring(start,(end +9) -start);
					}
					else
					{
						tmp = data.Substring(start,data.Length - start);
					}
					if ( tmp != "" )
					{
						//player = new Player();

						// Get player name
						tmpend = tmp.IndexOf("\x0");
						string name = tmp.Substring(1,tmpend -1);
					
						// Work out frags and time
						string details = tmp.Substring(tmpend+1,tmp.Length - tmpend-1);
						int frags = 0;
						float time = 0;

						if ( details.Length >= 8 )
						{
							frags = ((byte) details[0]) + ((byte) details[1] + ((byte) details[2]) + ((byte) details[3]));
							byte[] tmpB = new byte[4] {(byte) details[4],(byte) details[5],(byte) details[6],(byte) details[7]};
							time = BitConverter.ToSingle(tmpB,0);
						}

						ListViewItem listViewItem = this.listView1.Items.Add(name);
						listViewItem.SubItems.Add(frags + "");
						TimeSpan t = new TimeSpan(0,0,(int) time);

						listViewItem.SubItems.Add(t.TotalSeconds + " seconds");
					}

					start = end +9;
				}
			}
		}
	}


}
