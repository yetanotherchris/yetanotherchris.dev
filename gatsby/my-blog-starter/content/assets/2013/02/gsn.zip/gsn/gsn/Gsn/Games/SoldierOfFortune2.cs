using System;
using System.Net;
using System.Net.Sockets;
using System.Collections;
using System.Text;
using System.Text.RegularExpressions;

namespace Gsn.Games
{
	/// <summary>
	/// 
	/// </summary>
	public class SoldierOfFortune2 : Engines.Quake3
	{	
		#region IGameServerQuery events implementation
		/// <summary>
		/// See <see cref="IGameServerQuery.ServerDetailsFinished">IGameServerQuery.Timeout</see>
		/// </summary>
		public override event ServerEventHandler GetServerDetailsFinished;

		/// <summary>
		/// See <see cref="IGameServerQuery.GetServerListFinished">IGameServerQuery.GetServerListFinished</see>
		/// </summary>
		public override event ServerListEventHandler GetServerListFinished;
		#endregion

		#region Public methods
		/// <summary>
		/// See See <see cref="IGameServerQuery.GetServerDetails">IGameServerQuery.GetServerDetails</see>
		/// </summary>
		public override void GetServerDetails(string Ip,int Port)
		{
			base.GetServerDetails(Ip,Port);

			// Password protected is taken from a different 
			// variable, so adjust this.


			// Fire the event to indicate processing is finished
			if ( this.GetServerDetailsFinished != null )
			{
				ServerEventArgs e = new ServerEventArgs();
				e.ServerInfo = this.serverDetails;
				this.GetServerDetailsFinished(this, e);
			}
		}

		/// <summary>
		/// See <see cref="IGameServerQuery.GetServerList">IGameServerQuery.GetServerList</see>
		/// </summary>
		public override void GetServerList()
		{

		}
		#endregion

		#region Private methods
		protected override void getPlayers(string playerinfo)
		{
			Player player;
			// If only Valve had done it this way..
			string[] players = playerinfo.Split('\n');
			this.serverDetails.PlayerCount = players.Length;

			// Format: score ping deaths name
			for (int i=0;i < players.Length;i++)
			{
				int nameStart = players[i].IndexOf("\"");

				if ( nameStart != -1 )
				{
					player = new Player();

					string info = players[i].Substring(0,nameStart);
					string name = players[i].Substring(nameStart,players[i].Length - nameStart);

					// Format: "name" """
					name = name.Substring(1,name.Length-2);

					// Remove colour coding if specified
					if ( this.stripPlayernameColors )
					{
						Regex regex = new Regex("\\^[0-9]",RegexOptions.IgnorePatternWhitespace);
						name = regex.Replace(name,"");

					}

					player.Name = name;

					// Include deaths
					if ( info.IndexOf(" ") != -1 )
					{
						info = info.TrimEnd(new Char[] {' '});

						string[] infoParts = info.Split(' ');

						if ( infoParts.Length == 4 )
						{
							player.Score = Utility.IntParse(infoParts[0]);
							player.Ping  = Utility.IntParse(infoParts[1]);
							player.Deaths  = Utility.IntParse(infoParts[2]);
						}
					}

					this.serverDetails.Players.Add(player);
				}
			}
		}
		#endregion
	}
}





