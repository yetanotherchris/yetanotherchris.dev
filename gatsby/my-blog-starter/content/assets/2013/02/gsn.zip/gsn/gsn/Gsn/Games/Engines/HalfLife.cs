using System;
using System.Net;
using System.Net.Sockets;
using System.Collections;
using System.Text;

namespace Gsn.Games.Engines
{
	/// <summary>
	/// Currently todo:
	/// - Add secure,modversion,cldll,mod,gamedir,lan,proxytarget,protocol to AdditionalInfo hashtable
	/// - Remove GetServerListFinished, change to ServerAdded (with custom eventargs)
	/// </summary>
	public class HalfLife : IGameServerQuery
	{
		#region IGameServerQuery implementation
		/// <summary>
		/// See <see cref="IGameServerQuery.Timeout">IGameServerQuery.Timeout</see>
		/// </summary>
		public int Timeout 
		{ 
			get
			{
				return this.timeout;
			}
			set
			{
				this.timeout = value;
			}
		}

		/// <summary>
		/// See <see cref="IGameServerQuery.ServerDetails">IGameServerQuery.ServerDetails</see>
		/// </summary>
		public Server ServerDetails
		{ 
			get
			{
				return this.serverDetails;
			}
			set
			{
				this.serverDetails = value;
			}
		}

		/// <summary>
		/// See <see cref="IGameServerQuery.ServerList">IGameServerQuery.ServerList</see>
		/// </summary>
		public ArrayList ServerList
		{ 
			get
			{
				return this.serverList;
			}
			set
			{
				this.serverList = value;
			}
		}

		/// <summary>
		/// See <see cref="IGameServerQuery.MasterServerIp">IGameServerQuery.MasterServerIp</see>
		/// </summary>
		public string MasterServerIp 
		{ 
			get
			{
				return this.masterIp;
			}
			set
			{
				this.masterIp = value;
			}
		}

		/// <summary>
		/// See <see cref="IGameServerQuery.MasterServerPort">IGameServerQuery.MasterServerPort</see>
		/// </summary>
		public int MasterServerPort 
		{ 
			get
			{
				return this.masterPort;
			}
			set
			{
				this.masterPort = value;
			}
		}

		/// <summary>
		/// See <see cref="IGameServerQuery.ServerDetailsFinished">IGameServerQuery.Timeout</see>
		/// </summary>
		public event ServerEventHandler GetServerDetailsFinished;

		/// <summary>
		/// See <see cref="IGameServerQuery.GetServerListFinished">IGameServerQuery.GetServerListFinished</see>
		/// </summary>
		public event ServerListEventHandler GetServerListFinished;

		/// <summary>
		/// Private member for the public property.
		/// </summary>
		private int timeout = 10000;

		/// <summary>
		/// Private member for the public property.
		/// </summary>
		protected string masterIp = "207.173.177.11";

		/// <summary>
		/// Private member for the public property.
		/// </summary>
		protected int masterPort = 27010;

		/// <summary>
		/// Private member for the public property.
		/// </summary>
		private ArrayList serverList;

		/// <summary>
		/// Private member for the public property.
		/// </summary>
		private Server serverDetails;
		#endregion

		#region HalfLife specific properties
		/// <summary>
		/// The following items are available to filter the Half Life
		/// master server listing:
		/// <list type="bullet">
		/// <item>Servers running dedicated: \type\d</item>
		/// <item>Servers using anti-cheat technology (VAC): \secure\1</item>
		/// <item>Servers running the specified modification (ex. cstrike): \gamedir\[mod]</item>
		/// <item>Servers running the specified map (ex. cs_italy):	  \map\[map]</item>
		/// <item>Servers running on a Linux platform:  \linux\1</item>
		/// <item>Servers that are not empty: \empty\1</item>
		/// <item>Servers that are not full: \full\1</item>
		/// <item>Servers that are spectator proxies: \proxy\1</item>
		/// </list>
		/// For example, to find all non-full secure counter strike servers, you would
		/// use \gamedir\cstrike\full\1\secure\1
		/// </summary>
		public string HlMasterFilter
		{
			get
			{
				return this.hlMasterFilter;
			}
			set
			{
				this.hlMasterFilter = value;
			}
		}

		/// <summary>
		/// The geographical region to filter the Half Life master server list with.
		/// The following values are available, the default is 0 :
		/// <list type="bullet">
		/// <item>0: US East coast</item>
		/// <item>1: US West coast</item> 
		/// <item>2: South America</item>
		/// <item>3: Europe </item>
		/// <item>4: Asia</item>
		/// <item>5: Australia</item>
		/// <item>6: Middle East</item>
		/// <item>7: Africa</item>
		/// </list>
		/// </summary>
		public int HlMasterRegion
		{
			get
			{
				return this.hlMasterRegion;
			}
			set
			{
				this.hlMasterRegion = value;
			}
		}

		/// <summary>
		/// Private member for the public property.
		/// </summary>
		private int hlMasterRegion = 0;

		/// <summary>
		/// Private member for the public property.
		/// </summary>
		private string hlMasterFilter = null;

		#endregion

		#region Public methods
		/// <summary>
		/// See See <see cref="IGameServerQuery.GetServerDetails">IGameServerQuery.GetServerDetails</see>
		/// </summary>
		public void GetServerDetails(string Ip,int Port)
		{
			this.serverDetails = new Server();
			this.serverDetails.AdditionalInfo = new Hashtable();
			this.serverDetails.Players = new PlayerCollection();

			Gsn.UdpClient udpClient = new Gsn.UdpClient();
			udpClient.Timeout = this.timeout;

			// Server info
			this.serverDetails.Ip = Ip;
			this.serverDetails.Port = Port;

			string command = "\xff\xff\xff\xffinfostring\x0";
			byte[] response = udpClient.QueryGameServer(GameEngineType.HalfLife,command,Ip,Port);
			string res = Encoding.UTF8.GetString(response);
			this.getServerInfo(res);

			// Players
			command = "\xff\xff\xff\xffplayers\x0";
			response = udpClient.QueryGameServer(GameEngineType.HalfLife,command,Ip,Port);
			res = Encoding.UTF8.GetString(response);
			this.getPlayers(res);

			// Rules
			command = "\xff\xff\xff\xffrules\x0";
			response = udpClient.QueryGameServer(GameEngineType.HalfLife,command,Ip,Port);
			res = Encoding.UTF8.GetString(response);
			this.getRules(res);

			// Fire the event to indicate processing is finished
			if ( this.GetServerDetailsFinished != null )
			{
				ServerEventArgs e = new ServerEventArgs();
				e.ServerInfo = this.serverDetails;
				this.GetServerDetailsFinished(this, e);
			}
		}

		/// <summary>
		/// See <see cref="IGameServerQuery.GetServerList">IGameServerQuery.GetServerList</see>
		/// </summary>
		public void GetServerList()
		{
			TimeSpan diff;
			byte byteRegion = 0;
			string lastIp = "";
			this.serverList = new ArrayList();

			string ip  = "0.0.0.0:0";
			
			if ( this.hlMasterRegion > -1 && this.hlMasterRegion < 8 )
			{
				byteRegion = (byte) this.hlMasterRegion;
			}
			string command = "1" + byteRegion + ip +"\x00\\gamedir\\cstrike\x00";

			
			DateTime start = DateTime.Now;

			// Send the command
			IPEndPoint IPEndPoint = new IPEndPoint(IPAddress.Any,0);
			Gsn.UdpClient udpClient = new Gsn.UdpClient();
			udpClient.Timeout = this.timeout;

			byte[] sendData = Encoding.Default.GetBytes(command);
			udpClient.Send(sendData,sendData.Length,this.masterIp,this.masterPort);

			// We don't use UDP helper for this, as the master query for
			// Half Life requires the last IP of the previous packet to
			// be sent each time - adding a mechanism into UdpHelper for this
			// would be too messy, deal with it here instead.
			// its own 
			byte[] recvData;
			do
			{
				recvData = udpClient.Receive(ref IPEndPoint);

				// Parse the IPs from the packet
				string data = Encoding.Default.GetString(recvData);
				if ( data != "" )
				{
					string ipPort = "";
					int index = 0;
					string serverIp = "";
					int serverPort = 0;
					string tmp = "";
					
					data.Remove(0,6);

					while ( index < (data.Length -6) )
					{
						tmp = data.Substring(index,6);

						serverIp   = (int) ((byte) tmp[0]) +"." +(int) ((byte) tmp[1])+ "." +(int) ((byte) tmp[2])+ "." +(int) ((byte) tmp[3]);
						serverPort = ((byte) tmp[4] *256) + ((byte) tmp[5]);

						ipPort = serverIp+ ":" +serverPort;
						serverList.Add(ipPort);

						index += 6;
						lastIp = ipPort;
					}
				}

				// Send the last ip
				command = "1" + byteRegion + ip +"\x00\\gamedir\\cstrike\x00";
				sendData = Encoding.Default.GetBytes(command);
				udpClient.Send(sendData,sendData.Length,this.masterIp,this.masterPort);

				DateTime now = DateTime.Now;
				diff = (now - start);			
		
			} while (recvData != null && recvData.Length > 0 && (diff.Seconds*1000+diff.Milliseconds < this.timeout) );

			udpClient.Close();

			// Finished - call the GetServerListFinished event
			if ( this.GetServerListFinished != null )
			{
				ServerListEventArgs e = new ServerListEventArgs();
				e.Servers = this.serverList;
				this.GetServerListFinished(this,e);
			}
		}
		#endregion

		#region Private methods
		private void getServerInfo(string data)
		{
			if ( data.IndexOf("infostringresponse") != -1 )
			{
				int start = data.IndexOf("infostringresponse\x0\\");
				start += "infostringresponse\x0\\".Length;
				data = data.Substring(start,data.Length - start);

				string[] parts = data.Split('\\');

				// Loop through, finding out tokens
				for (int i=0;i < parts.Length;i++)
				{
					switch (parts[i])
					{
						case "map":
							if ( i+1 <= parts.Length )
								this.serverDetails.Map = parts[i+1];
							break;
						case "max":
							if ( i+1 <= parts.Length )
								this.serverDetails.MaxPlayers = Utility.IntParse(parts[i+1]);
							break;
						case "players":
							if ( i+1 <= parts.Length )
								this.serverDetails.PlayerCount = Utility.IntParse(parts[i+1]);
							break;
						case "description":
							if ( i+1 <= parts.Length )
								this.serverDetails.ModName = parts[i+1];
							break;
						case "password":
							if ( i+1 <= parts.Length )
								this.serverDetails.PasswordProtected = Utility.BoolParse(parts[i+1]);
							break;
						case "hostname":
							if ( i+1 <= parts.Length )
								this.serverDetails.Hostname = parts[i+1];
							break;
					}
				}
			}
		}

		private void getPlayers(string data)
		{
			if ( data.Length > 6 )
			{
				Player player;
				int start = 0;
				int end = 0;
				int tmpend = 0;
				string tmp ="";
				//Remove FF FF FF FF 44 04 01
				data = data.Substring(6,data.Length - 7);

				while (start < data.Length)
				{
					// Order of info: index,playername,0,8bytes of info	
					end = data.IndexOf("\x0",start);
					if ( end >0 && end +9 < data.Length )
					{
						tmp = data.Substring(start,(end +9) -start);
					}
					else
					{
						tmp = data.Substring(start,data.Length - start);
					}
					if ( tmp != "" )
					{
						player = new Player();

						// Get player name
						tmpend = tmp.IndexOf("\x0");
						string name = tmp.Substring(1,tmpend -1);
					
						// Work out frags and time
						string details = tmp.Substring(tmpend+1,tmp.Length - tmpend-1);
						int frags = 0;
						float time = 0;

						if ( details.Length >= 8 )
						{
							frags = ((byte) details[0]) + ((byte) details[1] + ((byte) details[2]) + ((byte) details[3]));
							byte[] tmpB = new byte[4] {(byte) details[4],(byte) details[5],(byte) details[6],(byte) details[7]};
							time = BitConverter.ToSingle(tmpB,0);
						}

						player.Name = name;
						player.Score = frags;
						player.Time = new TimeSpan(0,0,(int) time);
						player.Ping = 0;

						this.serverDetails.Players.Add(player);
					}

					start = end +9;
				}
			}
		}

		private void getRules(string data)
		{
			if ( data.Length >5 )
			{
				int ruleCount = (byte) data[5];

				int start = data.IndexOf("\x0");

				if ( start != -1 )
				{
					data = data.Substring(start+1,data.Length - (start +1));

					string[] parts = data.Split('\x0');

					// Loop through, adding tokens to the additional info hashtable
					for (int i=0;i < parts.Length;i+=2)
					{
						if ( parts[i] != "\x0" && parts.Length > i+1 && parts[i+1] != "\x0" && ! this.serverDetails.AdditionalInfo.ContainsKey(parts[i]) )
						{
							this.serverDetails.AdditionalInfo.Add(parts[i],parts[i+1]);
						}
					}
				}
			}
		}
		#endregion
	}
}
