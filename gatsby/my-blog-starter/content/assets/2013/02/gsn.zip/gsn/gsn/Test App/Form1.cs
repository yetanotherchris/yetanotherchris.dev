using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;

using Gsn;
using Gsn.Games;


namespace UdpTemp
{
	/// <summary>
	/// 
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		#region Component members
		private System.Windows.Forms.StatusBar statusBar1;
		private System.Windows.Forms.Button buttonQuery;
		private System.Windows.Forms.ComboBox comboBoxGameType;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.GroupBox groupBox3;
		private System.Windows.Forms.ColumnHeader columnHeader1;
		private System.Windows.Forms.ColumnHeader columnHeader2;
		private System.Windows.Forms.ColumnHeader columnHeader3;
		private System.Windows.Forms.ColumnHeader columnHeader4;
		private System.Windows.Forms.ColumnHeader columnHeader5;
		private System.Windows.Forms.ListView listViewPlayers;
		private System.Windows.Forms.ListView listViewAdditional;
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.TextBox textBoxIpPort;
		private System.Windows.Forms.Button buttonMaster;
		#endregion
		
		#region Members
		private IGameServerQuery serverQuery;
		private System.Windows.Forms.ColumnHeader columnHeaderIP;
		private System.Windows.Forms.ColumnHeader columnHeaderName;
		private System.Windows.Forms.ColumnHeader columnHeaderMap;
		private System.Windows.Forms.ColumnHeader columnHeaderPlayers;
		private System.Windows.Forms.ColumnHeader columnHeaderPassword;
		private System.Windows.Forms.ColumnHeader columnHeaderMod;
		private System.Windows.Forms.ListView listViewServers;
		private ArrayList serverList;
		#endregion

		#region Constructor, dispose,main
		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}
		#endregion

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.statusBar1 = new System.Windows.Forms.StatusBar();
			this.buttonQuery = new System.Windows.Forms.Button();
			this.comboBoxGameType = new System.Windows.Forms.ComboBox();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.listViewPlayers = new System.Windows.Forms.ListView();
			this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
			this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
			this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.listViewAdditional = new System.Windows.Forms.ListView();
			this.columnHeader4 = new System.Windows.Forms.ColumnHeader();
			this.columnHeader5 = new System.Windows.Forms.ColumnHeader();
			this.textBoxIpPort = new System.Windows.Forms.TextBox();
			this.buttonMaster = new System.Windows.Forms.Button();
			this.listViewServers = new System.Windows.Forms.ListView();
			this.columnHeaderIP = new System.Windows.Forms.ColumnHeader();
			this.columnHeaderName = new System.Windows.Forms.ColumnHeader();
			this.columnHeaderMap = new System.Windows.Forms.ColumnHeader();
			this.columnHeaderPlayers = new System.Windows.Forms.ColumnHeader();
			this.columnHeaderPassword = new System.Windows.Forms.ColumnHeader();
			this.columnHeaderMod = new System.Windows.Forms.ColumnHeader();
			this.groupBox1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.groupBox3.SuspendLayout();
			this.SuspendLayout();
			// 
			// statusBar1
			// 
			this.statusBar1.Location = new System.Drawing.Point(0, 346);
			this.statusBar1.Name = "statusBar1";
			this.statusBar1.Size = new System.Drawing.Size(610, 22);
			this.statusBar1.SizingGrip = false;
			this.statusBar1.TabIndex = 2;
			// 
			// buttonQuery
			// 
			this.buttonQuery.Location = new System.Drawing.Point(524, 30);
			this.buttonQuery.Name = "buttonQuery";
			this.buttonQuery.TabIndex = 6;
			this.buttonQuery.Text = "Query";
			this.buttonQuery.Click += new System.EventHandler(this.buttonQuery_Click);
			// 
			// comboBoxGameType
			// 
			this.comboBoxGameType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxGameType.Items.AddRange(new object[] {
																  "Battlefield 1942",
																  "Call of Duty",
																  "Half life (including Counter Strike, DOD)",
																  "Jedi Knight 2",
																  "Medal of Honor",
																  "Quake 3",
																  "Return to Castle Wolfenstein",
																  "Soldier of Fortune 2",
																  "Unreal Tournament 2003",
																  "Unreal Tournament 2004"});
			this.comboBoxGameType.Location = new System.Drawing.Point(8, 32);
			this.comboBoxGameType.Name = "comboBoxGameType";
			this.comboBoxGameType.Size = new System.Drawing.Size(280, 21);
			this.comboBoxGameType.TabIndex = 2;
			this.comboBoxGameType.SelectedIndexChanged += new System.EventHandler(this.comboBoxGameType_SelectedIndexChanged);
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.listViewServers});
			this.groupBox1.Location = new System.Drawing.Point(8, 64);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(592, 120);
			this.groupBox1.TabIndex = 3;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Servers";
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.listViewPlayers});
			this.groupBox2.Location = new System.Drawing.Point(8, 192);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(288, 152);
			this.groupBox2.TabIndex = 4;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Players";
			// 
			// listViewPlayers
			// 
			this.listViewPlayers.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																							  this.columnHeader1,
																							  this.columnHeader2,
																							  this.columnHeader3});
			this.listViewPlayers.Location = new System.Drawing.Point(8, 24);
			this.listViewPlayers.Name = "listViewPlayers";
			this.listViewPlayers.Size = new System.Drawing.Size(272, 120);
			this.listViewPlayers.TabIndex = 0;
			this.listViewPlayers.View = System.Windows.Forms.View.Details;
			// 
			// columnHeader1
			// 
			this.columnHeader1.Text = "Name";
			this.columnHeader1.Width = 165;
			// 
			// columnHeader2
			// 
			this.columnHeader2.Text = "Score";
			// 
			// columnHeader3
			// 
			this.columnHeader3.Text = "Ping";
			this.columnHeader3.Width = 43;
			// 
			// groupBox3
			// 
			this.groupBox3.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.listViewAdditional});
			this.groupBox3.Location = new System.Drawing.Point(304, 192);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(288, 152);
			this.groupBox3.TabIndex = 5;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "Additional information";
			// 
			// listViewAdditional
			// 
			this.listViewAdditional.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																								 this.columnHeader4,
																								 this.columnHeader5});
			this.listViewAdditional.Location = new System.Drawing.Point(10, 24);
			this.listViewAdditional.Name = "listViewAdditional";
			this.listViewAdditional.Size = new System.Drawing.Size(262, 120);
			this.listViewAdditional.TabIndex = 0;
			this.listViewAdditional.View = System.Windows.Forms.View.Details;
			// 
			// columnHeader4
			// 
			this.columnHeader4.Text = "Name";
			this.columnHeader4.Width = 100;
			// 
			// columnHeader5
			// 
			this.columnHeader5.Text = "Value";
			this.columnHeader5.Width = 158;
			// 
			// textBoxIpPort
			// 
			this.textBoxIpPort.Location = new System.Drawing.Point(8, 8);
			this.textBoxIpPort.Name = "textBoxIpPort";
			this.textBoxIpPort.Size = new System.Drawing.Size(280, 21);
			this.textBoxIpPort.TabIndex = 7;
			this.textBoxIpPort.Text = "";
			// 
			// buttonMaster
			// 
			this.buttonMaster.Location = new System.Drawing.Point(424, 31);
			this.buttonMaster.Name = "buttonMaster";
			this.buttonMaster.Size = new System.Drawing.Size(88, 23);
			this.buttonMaster.TabIndex = 8;
			this.buttonMaster.Text = "Get server list";
			this.buttonMaster.Click += new System.EventHandler(this.buttonMaster_Click);
			// 
			// listViewServers
			// 
			this.listViewServers.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																							  this.columnHeaderName,
																							  this.columnHeaderIP,
																							  this.columnHeaderMap,
																							  this.columnHeaderPlayers,
																							  this.columnHeaderPassword,
																							  this.columnHeaderMod});
			this.listViewServers.FullRowSelect = true;
			this.listViewServers.Location = new System.Drawing.Point(8, 24);
			this.listViewServers.Name = "listViewServers";
			this.listViewServers.Size = new System.Drawing.Size(576, 88);
			this.listViewServers.TabIndex = 1;
			this.listViewServers.View = System.Windows.Forms.View.Details;
			// 
			// columnHeaderIP
			// 
			this.columnHeaderIP.Text = "IP";
			this.columnHeaderIP.Width = 140;
			// 
			// columnHeaderName
			// 
			this.columnHeaderName.Text = "Name";
			this.columnHeaderName.Width = 150;
			// 
			// columnHeaderMap
			// 
			this.columnHeaderMap.Text = "Map";
			this.columnHeaderMap.Width = 100;
			// 
			// columnHeaderPlayers
			// 
			this.columnHeaderPlayers.Text = "Players";
			// 
			// columnHeaderPassword
			// 
			this.columnHeaderPassword.Text = "Passworded";
			// 
			// columnHeaderMod
			// 
			this.columnHeaderMod.Text = "Modname";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(610, 368);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.buttonMaster,
																		  this.textBoxIpPort,
																		  this.groupBox3,
																		  this.groupBox2,
																		  this.groupBox1,
																		  this.comboBoxGameType,
																		  this.buttonQuery,
																		  this.statusBar1});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Name = "Form1";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "GSN Test application";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.groupBox1.ResumeLayout(false);
			this.groupBox2.ResumeLayout(false);
			this.groupBox3.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		#region Event handlers
		private void buttonQuery_Click(object sender, System.EventArgs e)
		{
			/*
			Battlefield 1942
			Call of Duty
			Half life (including Counter Strike, DOD)
			Jedi Knight 2
			Medal of Honor
			Quake 3
			Return to Castle Wolfenstein
			Soldier of Fortune 2
			Unreal Tournament 2003
			Unreal Tournament 2004
			*/
			switch ( this.comboBoxGameType.SelectedIndex)
			{
				//case 0:
				//    this.serverQuery = new Battlefield1942();
				//    break;
				//case 1:
				//    this.serverQuery = new CallOfDuty();
				//    break;
				case 2:
					this.serverQuery = new Gsn.Games.Engines.HalfLife();
					break;
				//case 3:
				//    this.serverQuery = new JediKnight();
				//    break;
				//case 4:
				//    this.serverQuery = new MedalOfHonor();
				//    break;
				//case 5:
				//    this.serverQuery = new Quake3();
				//    break;
				//case 6:
				//    this.serverQuery = new Quake3();
				//    break;
				//case 7:
				//    this.serverQuery = new SoldierOfFortune2();
				//    break;
				//case 8:
				//    this.serverQuery = new Gsn.Games.Engines.UT2003();
				//    break;
				//case 9:
				//    this.serverQuery = new Gsn.Games.Engines.UT2003();
				//    break;
				//default:
				//    this.serverQuery = new Gsn.Games.Engines.Quake3();
					break;
			}

			if ( this.textBoxIpPort.Text.IndexOf(":") != -1 )
			{
				string ipport = this.textBoxIpPort.Text;
				int start = ipport.IndexOf(":");

				if ( start != -1 )
				{
					string ip = ipport.Substring(0,start);
					string port = ipport.Substring(start+1,ipport.Length - (start+1));

					if ( ip != "" && port != "" )
					{
						this.serverQuery.Timeout = 5000;
						this.serverQuery.GetServerDetailsFinished += new ServerEventHandler(serverQueryFinished);
						this.serverQuery.GetServerDetails(ip,int.Parse(port));
					}
					else
					{
						MessageBox.Show("Please enter an IP in the format IP:PORT");
					}

				}
				else
				{
					MessageBox.Show("Please enter an IP in the format IP:PORT");
				}
			}
		}

		private void buttonMaster_Click(object sender, System.EventArgs e)
		{
			switch ( this.comboBoxGameType.SelectedIndex)
			{
				//case 0:
				//    this.serverQuery = new Battlefield1942();
				//    break;
				//case 1:
				//    this.serverQuery = new CallOfDuty();
				//    break;
				case 2:
					this.serverQuery = new Gsn.Games.Engines.HalfLife();
					break;
				//case 3:
				//    this.serverQuery = new JediKnight();
				//    break;
				//case 4:
				//    this.serverQuery = new MedalOfHonor();
				//    break;
				//case 5:
				//    this.serverQuery = new Quake3();
				//    break;
				//case 6:
				//    this.serverQuery = new Quake3();
				//    break;
				//case 7:
				//    this.serverQuery = new SoldierOfFortune2();
				//    break;
				//case 8:
				//    this.serverQuery = new Gsn.Games.Engines.UT2003();
				//    break;
				//case 9:
				//    this.serverQuery = new Gsn.Games.Engines.UT2003();
				//    break;
				//default:
				//    this.serverQuery = new Gsn.Games.Engines.Quake3();
				//    break;
			}
			this.serverQuery.GetServerListFinished += new ServerListEventHandler(serverListFinished);
			this.serverQuery.GetServerList();
		}
		private void comboBoxGameType_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			/*
			0 Battlefield 1942
			1 Call of Duty
			2 Half life (including Counter Strike, DOD)
			3 Jedi Knight 2
			4 Medal of Honor
			5 Quake 3
			6 Return to Castle Wolfenstein
			7 Soldier of Fortune 2
			8 Unreal Tournament 2003
			9 Unreal Tournament 2004
			*/

			// Stick an example IP in
			switch ( this.comboBoxGameType.SelectedIndex)
			{
				case 0:
					this.textBoxIpPort.Text = "195.149.21.222:23000";
					break;
				case 1:
					this.textBoxIpPort.Text = "193.201.52.82:28960";
					break;
				case 2:
					this.textBoxIpPort.Text = "80.253.115.31:27035";
					break;
				case 3:
					this.textBoxIpPort.Text = "131.211.173.71:27960";
					break;
				case 4:
					this.textBoxIpPort.Text = "195.149.21.154:12203";
					break;
				case 5:
					this.textBoxIpPort.Text = "213.40.130.40:27962";
					break;
				case 6:
					this.textBoxIpPort.Text = "217.158.150.55:27010";
					break;
				case 7:
					this.textBoxIpPort.Text = "82.197.68.37:20103";
					break;
				case 8:
					this.textBoxIpPort.Text = "62.204.69.131:7787";
					break;
				case 9:
					this.textBoxIpPort.Text = "217.161.41.46:7787";
					break;
				default:
					this.textBoxIpPort.Text = "";
					break;
			}

		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			this.comboBoxGameType.SelectedIndex = 0;
		}
		#endregion

		#region Event handlers for server query
		private void serverQueryFinished(object send, ServerEventArgs e)
		{
			this.listViewServers.Items.Clear();

			ListViewItem listViewItem = this.listViewServers.Items.Add(this.serverQuery.ServerDetails.Hostname);
			listViewItem.SubItems.Add(this.serverQuery.ServerDetails.Ip + ":" +this.serverQuery.ServerDetails.Port);
			listViewItem.SubItems.Add(this.serverQuery.ServerDetails.Map );
			listViewItem.SubItems.Add(this.serverQuery.ServerDetails.PlayerCount+ "/" +this.serverQuery.ServerDetails.MaxPlayers);
			listViewItem.SubItems.Add(((this.serverQuery.ServerDetails.PasswordProtected) ? "yes" :"no"));
			listViewItem.SubItems.Add(this.serverQuery.ServerDetails.ModName);
			
			// Players
			this.listViewPlayers.Items.Clear();
			for (int i=0;i < this.serverQuery.ServerDetails.Players.Count;i++)
			{
				Player player = this.serverQuery.ServerDetails.Players.Item(i);

				listViewItem = this.listViewPlayers.Items.Add(player.Name);
				listViewItem.SubItems.Add(player.Score +"");
				listViewItem.SubItems.Add(player.Ping +"");
			}

			// Rules or server info
			this.listViewAdditional.Items.Clear();
			foreach (string key in this.serverQuery.ServerDetails.AdditionalInfo.Keys)
			{
				listViewItem = this.listViewAdditional.Items.Add(key);
				listViewItem.SubItems.Add(serverQuery.ServerDetails.AdditionalInfo[key] +"");
			}

		}
		private void serverListFinished(object sender, ServerListEventArgs e)
		{
			this.listViewServers.Items.Clear();
			this.serverList = this.serverQuery.ServerList;

			for (int i=0;i < this.serverQuery.ServerList.Count;i++)
			{
				this.statusBar1.Text = i+ "/" +this.serverQuery.ServerList.Count;
				ListViewItem listViewItem = this.listViewServers.Items.Add("???");
				listViewItem.SubItems.Add(this.serverQuery.ServerList[i]+ "");
			}
		}
		#endregion
	}
}
