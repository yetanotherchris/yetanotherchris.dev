using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Collections;

namespace Gsn
{
	public class UdpClient : System.Net.Sockets.UdpClient
	{
		#region Base members
		public UdpClient() : base() {}
		public UdpClient(int port) : base(port){}
		public UdpClient(IPEndPoint localEP) : base(localEP){}
		#endregion

		#region Public properties
		/// <summary>
		/// 
		/// </summary>
		public bool ReuseAddress
		{
			get
			{
				object o = this.Client.GetSocketOption(SocketOptionLevel.Socket,SocketOptionName.ReuseAddress);
				return Convert.ToBoolean(o);
			}
			set
			{
				Socket socket = this.Client;
				socket.SetSocketOption(SocketOptionLevel.Socket,SocketOptionName.ReuseAddress, Convert.ToInt32(value));
			}
		}

		/// <summary>
		/// 
		/// </summary>
		public int Timeout
		{
			get
			{
				Socket socket = this.Client;
				return (int) socket.GetSocketOption(SocketOptionLevel.Socket,SocketOptionName.ReceiveTimeout);
			}
			set
			{
				if ( value < 0 )
				{
					value = 0;
				}

				Socket socket = this.Client;
				socket.SetSocketOption(SocketOptionLevel.Socket,SocketOptionName.ReceiveTimeout, value);
			}
		}

		/// <summary>
		/// 
		/// </summary>
		public int SendTimeout
		{
			get
			{
				Socket socket = this.Client;
				return (int) socket.GetSocketOption(SocketOptionLevel.Socket,SocketOptionName.SendTimeout);
			}
			set
			{
				if ( value < 0 )
				{
					value = 0;
				}

				Socket socket = this.Client;
				socket.SetSocketOption(SocketOptionLevel.Socket,SocketOptionName.SendTimeout, value);
			}
		}

		/// <summary>
		/// 
		/// </summary>
		public Socket Socket
		{
			get 
			{ 
				return this.Client; 
			}
			set
			{
				if ( value == null )
				{
					throw new ArgumentNullException("Socket", "Socket is null.");
				}
				this.Client = value;
			}
		}

		/// <summary>
		/// 
		/// </summary>
		public bool Connected
		{
			get
			{
				return Socket.Connected;
			}
		}

		/// <summary>
		/// 
		/// </summary>
		public bool IsActive
		{
			get
			{ 
				return this.Active; 
			}
		}

		/// <summary>
		/// 
		/// </summary>
		public IPEndPoint RemoteIPEndPoint
		{
			get
			{
				return (IPEndPoint) Socket.RemoteEndPoint;
			}
		}

		/// <summary>
		/// 
		/// </summary>
		public IPEndPoint LocalIPEndPoint
		{
			get
			{
				return (IPEndPoint) Socket.LocalEndPoint;
			}
		}
		#endregion

		#region Public methods
		// Standard send + receive (while != null)
		// Half life send + receive
		// Half life master send + receive
		// UT2003 send and receive (while final)

		public byte[] QueryGameServer( GameEngineType EngineType, string Command, string Ip, int Port )
		{
			byte[] com = System.Text.ASCIIEncoding.ASCII.GetBytes( Command );
			IPEndPoint hostIpEndPoint = new IPEndPoint( IPAddress.Any, 0 );
			IPEndPoint remoteIpEndPoint = new IPEndPoint( IPAddress.Parse( Ip ), Port );

			return this.QueryGameServer( EngineType, com, ref remoteIpEndPoint, hostIpEndPoint );
		}

		public byte[] QueryGameServer(GameEngineType EngineType,byte[] Command, string Ip,int Port)
		{
			IPEndPoint hostIpEndPoint = new IPEndPoint(IPAddress.Any,0);
			IPEndPoint remoteIpEndPoint = new IPEndPoint(IPAddress.Parse(Ip),Port);

			return this.QueryGameServer(EngineType,Command,ref remoteIpEndPoint,hostIpEndPoint);
		}

		public byte[] QueryGameServer( GameEngineType EngineType, string Command, ref IPEndPoint LocalEndPoint, IPEndPoint DestinationEndPoint )
		{
			byte[] com = System.Text.ASCIIEncoding.ASCII.GetBytes( Command );
			byte[] result = null;
			string ret;

			switch ( EngineType )
			{
				case GameEngineType.None:
					result = this.sendAndReceive( com, ref LocalEndPoint, DestinationEndPoint );
					break;

				case GameEngineType.HalfLife:
					ret = this.sendReceiveHalfLife( com, ref LocalEndPoint, DestinationEndPoint );
					result = System.Text.ASCIIEncoding.ASCII.GetBytes( ret );
					break;

				case GameEngineType.Quake3:
					ret = this.sendReceiveQuake3( com, ref LocalEndPoint, DestinationEndPoint );
					result = System.Text.ASCIIEncoding.ASCII.GetBytes( ret );
					break;

				case GameEngineType.UnrealTournament2003:
					ret = this.sendReceiveUT2003( com, ref LocalEndPoint, DestinationEndPoint );
					result = System.Text.ASCIIEncoding.ASCII.GetBytes( ret );
					break;
			}

			return result;
		}

		public byte[] QueryGameServer( GameEngineType EngineType, byte[] Command, ref IPEndPoint LocalEndPoint, IPEndPoint DestinationEndPoint )
		{
			switch ( EngineType )
			{
				case GameEngineType.None:
					return this.sendAndReceive( Command, ref LocalEndPoint, DestinationEndPoint );

				case GameEngineType.HalfLife:
					return Encoding.UTF8.GetBytes(this.sendReceiveHalfLife( Command, ref LocalEndPoint, DestinationEndPoint ));

				case GameEngineType.Quake3:
					return Encoding.UTF8.GetBytes(this.sendReceiveQuake3( Command, ref LocalEndPoint, DestinationEndPoint ));

				case GameEngineType.UnrealTournament2003:
					return Encoding.UTF8.GetBytes(this.sendReceiveUT2003( Command, ref LocalEndPoint, DestinationEndPoint ));
				default:
					throw new NotImplementedException("Engine unsupported");
			}
		}
		#endregion

		#region Private methods
		private byte[] sendAndReceive(byte[] Command, ref IPEndPoint LocalEndPoint,IPEndPoint DestinationEndPoint)
		{
			if ( Command == null || DestinationEndPoint == null )
				return null;

			byte[] receive;

			this.Send(Command, Command.Length, DestinationEndPoint); //Send using base's Send();
			receive = this.Receive(ref LocalEndPoint);

			return receive;
		}

		private string sendReceiveHalfLife(byte[] Command, ref IPEndPoint LocalEndPoint,IPEndPoint DestinationEndPoint)
		{
			if ( Command == null || DestinationEndPoint == null )
				return null;

			byte[] receive;
			string result = "";

			this.Send(Command, Command.Length, DestinationEndPoint); //Send using base's Send();

			int packetCount = 0;
			int packetIndex = 0;
			Hashtable packets = new Hashtable();
			do
			{
				receive = this.Receive(ref LocalEndPoint);

				if ( receive != null )
				{
					string data = Encoding.Default.GetString(receive);

					if ( data != "" )
					{
						// If first byte is 254 then we have multiple packets
						if ( (byte) data[0] == 254 )
						{
							// High order contains count, low order index
							packetCount = ((byte) data[8]) & 15; // indexed from 0
							packetIndex = ((byte) data[8]) >> 4;
							packetCount -= 1;

							packets[packetIndex] = data.Remove(0,9);
						}
						else
						{
							packets[0] = data;
							
						}
					}
					result += Encoding.Default.GetString(receive);
				}

			}while ( this.Socket.Available > 0 && packetIndex < packetCount );

			return result;
		}

		private string sendReceiveQuake3(byte[] Command, ref IPEndPoint LocalEndPoint,IPEndPoint DestinationEndPoint)
		{
			if ( Command == null || Command == null )
				return null;

			byte[] receive;
			string result = "";

			this.Send(Command, Command.Length, DestinationEndPoint); //Send using base's Send();

			int m = this.Socket.Available;
			do
			{
				receive = this.Receive(ref LocalEndPoint);

				if ( receive != null )
				{
					result += Encoding.Default.GetString(receive);
				}

			}while ( this.Socket.Available > 0 );

			return result;
		}

		private string sendReceiveUT2003(byte[] Command, ref IPEndPoint LocalEndPoint,IPEndPoint DestinationEndPoint)
		{
			if ( DestinationEndPoint == null || DestinationEndPoint == null )
				return null;

			byte[] receive;
			string result = "";

			this.Send(Command, Command.Length, DestinationEndPoint); //Send using base's Send();

			int m = this.Socket.Available;
			do
			{
				receive = this.Receive(ref LocalEndPoint);

				if ( receive != null )
				{
					result += Encoding.Default.GetString(receive);
				}
				else
				{
					System.Diagnostics.Debug.WriteLine("UT2003: " +receive.Length+ " bytes received.");
				}

			}while ( this.Socket.Available > 0 );

			return result;
		}
		#endregion
	}

	public enum GameEngineType
	{
		None,
		HalfLife,
		Quake3,
		UnrealTournament2003
	}

}
