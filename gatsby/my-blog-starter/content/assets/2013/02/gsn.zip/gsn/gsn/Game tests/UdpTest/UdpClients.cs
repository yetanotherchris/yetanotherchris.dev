using System;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Text;
using System.Collections;

namespace UdpTest
{
	public class UdpClientNew : UdpClient
	{

		/// <summary>
		/// 
		/// </summary>
		public int ReceiveTimeout
		{
			get
			{
				Socket socket = this.Client;
				return (int) socket.GetSocketOption(SocketOptionLevel.Socket,SocketOptionName.ReceiveTimeout);
			}
			set
			{
				if ( value < 0 )
				{
					value = 0;
				}

				Socket socket = this.Client;
				socket.SetSocketOption(SocketOptionLevel.Socket,SocketOptionName.ReceiveTimeout, value);
			}
		}

		/// <summary>
		/// 
		/// </summary>
		public int SendTimeout
		{
			get
			{
				Socket socket = this.Client;
				return (int) socket.GetSocketOption(SocketOptionLevel.Socket,SocketOptionName.SendTimeout);
			}
			set
			{
				if ( value < 0 )
				{
					value = 0;
				}

				Socket socket = this.Client;
				socket.SetSocketOption(SocketOptionLevel.Socket,SocketOptionName.SendTimeout, value);
			}
		}

		public Socket Socket
		{
			get { return this.Client; }
			set
			{
				if ( value == null )
					throw new ArgumentNullException("Socket", "Socket is null.");
				this.Client = value;
			}
		}

		public string SendReceiveHalfLife(byte[] dgram, IPEndPoint destEP, ref IPEndPoint remoteEP)
		{
			if ( dgram == null || destEP == null )
				return null;

			byte[] receive;
			string result = "";

			this.Send(dgram, dgram.Length, destEP); //Send using base's Send();

			int packetCount = 0;
			int packetIndex = 0;
			Hashtable packets = new Hashtable();
			do
			{
				receive = this.Receive(ref remoteEP);

				if ( receive != null )
				{
					string data = Encoding.Default.GetString(receive);

					if ( data != "" )
					{
						// If first byte is 254 then we have multiple packets
						if ( (byte) data[0] == 254 )
						{
							// High order contains count, low order index
							packetCount = ((byte) data[8]) & 15; // indexed from 0
							packetIndex = ((byte) data[8]) >> 4;
							packetCount -= 1;

							packets[packetIndex] = data.Remove(0,9);
						}
						else
						{
							packets[0] = data;
							
						}
					}
					result += Encoding.Default.GetString(receive);
				}

			}while ( this.Socket.Available > 0 && packetIndex < packetCount );

			return result;
		}
		private int hlMasterRegion = 1;
		protected string masterIp = "207.173.177.11";
		protected int masterPort = 27010;

		public ArrayList hlMaster()
		{
			ArrayList arrayList = new ArrayList();
			TimeSpan diff;
			byte byteRegion = 0;
			string lastIp = "";

			string ip  = "0.0.0.0:0";
			
			if ( this.hlMasterRegion > -1 && this.hlMasterRegion < 8 )
			{
				byteRegion = (byte) this.hlMasterRegion;
			}
			string command = "1" + byteRegion + "0.0.0.0:0\x0";//\\gamedir\\cstrike\x0";
			
			DateTime start = DateTime.Now;

			// Send the command
			IPEndPoint IPEndPoint = new IPEndPoint(IPAddress.Any,0);	

			byte[] sendData = Encoding.Default.GetBytes(command);
			this.Send(sendData,sendData.Length,this.masterIp,this.masterPort);

			// We don't use UDP helper for this, as the master query for
			// Half Life requires the last IP of the previous packet to
			// be sent each time - adding a mechanism into UdpHelper for this
			// would be too messy, deal with it here instead.
			// its own 
			byte[] recvData;

			do 
			{
				recvData = this.Receive(ref IPEndPoint);
				// Parse the IPs from the packet
				string data = Encoding.Default.GetString(recvData);
				if ( data != "" )
				{
					string ipPort = "";
					int index = 0;
					string serverIp = "";
					int serverPort = 0;
					string tmp = "";
					
					data = data.Remove(0,6);

					while ( index < data.Length )
					{
						tmp = data.Substring(index,6);

						serverIp   = (int) ((byte) tmp[0]) +"." +(int) ((byte) tmp[1])+ "." +(int) ((byte) tmp[2])+ "." +(int) ((byte) tmp[3]);
						serverPort = ((byte) tmp[4] *256) + ((byte) tmp[5]);

						ipPort = serverIp+ ":" +serverPort;
						arrayList.Add(ipPort);

						index += 6;
						lastIp = ipPort;
					}
				}

				// Send the last ip
				command = "1" + byteRegion + lastIp +"\x00\\gamedir\\cstrike\x00";
				sendData = Encoding.Default.GetBytes(command);
				this.Send(sendData,sendData.Length,this.masterIp,this.masterPort);

				DateTime now = DateTime.Now;
				diff = (now - start);			
		
			} while ( recvData != null );//this.Socket.Available > 0 );

			return arrayList;

		}
	}


	public class TimedUdpClient : UdpClient
	{
		private int timeout = 5000;
		private Thread timeoutWatchdog;

		public int Timeout
		{
			get { return timeout; }
			set { timeout = value; }
		}

		public new byte[] Receive(ref IPEndPoint remote)
		{
			byte [] ret;
			timeoutWatchdog = new Thread(new ThreadStart(StartWatchdog));
			timeoutWatchdog.Start();
			try
			{
				ret = base.Receive(ref remote);
			}
			catch (SocketException)
			{
				ret=null;
			}
			finally
			{
				timeoutWatchdog.Abort();
			}
			return ret;
		}

		private void StartWatchdog()
		{
			Thread.Sleep(timeout);
			this.Send(new byte[] {0x00},1,"",8000);
		}
	}
}
