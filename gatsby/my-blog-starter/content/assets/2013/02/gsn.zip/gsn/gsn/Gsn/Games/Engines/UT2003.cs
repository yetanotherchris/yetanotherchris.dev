using System;
using System.Net;
using System.Net.Sockets;
using System.Collections;
using System.Text;
using System.Text.RegularExpressions;

namespace Gsn.Games.Engines
{
	/// <summary>
	/// Summary description for UT2003.
	/// </summary>
	public class UT2003 : IGameServerQuery
	{				  
		#region IGameServerQuery implementation
		/// <summary>
		/// See <see cref="IGameServerQuery.Timeout">IGameServerQuery.Timeout</see>
		/// </summary>
		public virtual int Timeout 
		{ 
			get
			{
				return this.timeout;
			}
			set
			{
				this.timeout = value;
			}
		}

		/// <summary>
		/// See <see cref="IGameServerQuery.ServerDetails">IGameServerQuery.ServerDetails</see>
		/// </summary>
		public virtual Server ServerDetails
		{ 
			get
			{
				return this.serverDetails;
			}
			set
			{
				this.serverDetails = value;
			}
		}

		/// <summary>
		/// See <see cref="IGameServerQuery.ServerList">IGameServerQuery.ServerList</see>
		/// </summary>
		public virtual ArrayList ServerList
		{ 
			get
			{
				return this.serverList;
			}
			set
			{
				this.serverList = value;
			}
		}

		/// <summary>
		/// See <see cref="IGameServerQuery.MasterServerIp">IGameServerQuery.MasterServerIp</see>
		/// </summary>
		public virtual string MasterServerIp 
		{ 
			get
			{
				return this.masterIp;
			}
			set
			{
				this.masterIp = value;
			}
		}

		/// <summary>
		/// See <see cref="IGameServerQuery.MasterServerPort">IGameServerQuery.MasterServerPort</see>
		/// </summary>
		public virtual int MasterServerPort 
		{ 
			get
			{
				return this.masterPort;
			}
			set
			{
				this.masterPort = value;
			}
		}

		/// <summary>
		/// See <see cref="IGameServerQuery.ServerDetailsFinished">IGameServerQuery.Timeout</see>
		/// </summary>
		public virtual event ServerEventHandler GetServerDetailsFinished;

		/// <summary>
		/// See <see cref="IGameServerQuery.GetServerListFinished">IGameServerQuery.GetServerListFinished</see>
		/// </summary>
		public virtual event ServerListEventHandler GetServerListFinished;

		/// <summary>
		/// Private member for the public property.
		/// </summary>
		private int timeout = 10000;

		/// <summary>
		/// Private member for the public property.
		/// </summary>
		protected string masterIp;

		/// <summary>
		/// Private member for the public property.
		/// </summary>
		protected int masterPort;

		/// <summary>
		/// Private member for the public property.
		/// </summary>
		protected ArrayList serverList;

		/// <summary>
		/// Private member for the public property.
		/// </summary>
		protected Server serverDetails;
		#endregion

		#region Public methods
		/// <summary>
		/// See See <see cref="IGameServerQuery.GetServerDetails">IGameServerQuery.GetServerDetails</see>
		/// </summary>
		public virtual void GetServerDetails(string Ip,int Port)
		{
			this.serverDetails = new Server();
			this.serverDetails.AdditionalInfo = new Hashtable();
			this.serverDetails.Players = new PlayerCollection();

			UdpClient udpClient = new UdpClient();

			// Server info
			this.serverDetails.Ip = Ip;
			this.serverDetails.Port = Port;

			string command = "\\status\\";
			udpClient.Timeout = 1000;
			string response = udpClient.GetUnrealUdpResponse(Ip,Port,command);

			if ( response != "" )
			{
				string serverinfo = "";
				
				if ( response.IndexOf("\\player_") != -1 )
				{
					string playerinfo = "";
					int end = response.IndexOf("\\player_");

					serverinfo = response.Substring(1,end);
					playerinfo = response.Substring(end,response.Length - end);

					this.getServerInfo(serverinfo);
					this.getPlayers(playerinfo);
				}
				else
				{
					serverinfo = response.Substring(0,response.Length);
					this.getServerInfo(serverinfo);
				}
					
			}
			else
			{
				this.serverDetails.Map = "None";
				this.serverDetails.Hostname = "Unable to connect";
			}

			// Fire the event to indicate processing is finished
			if ( this.GetServerDetailsFinished != null )
			{
				ServerEventArgs e = new ServerEventArgs();
				e.ServerInfo = this.serverDetails;
				this.GetServerDetailsFinished(this, e);
			}

		}

		/// <summary>
		/// See <see cref="IGameServerQuery.GetServerList">IGameServerQuery.GetServerList</see>
		/// </summary>
		public virtual void GetServerList()
		{

		}
		#endregion

		#region Protected methods
		protected virtual void getServerInfo(string serverinfo)
		{
			
			string[] parts = serverinfo.Split('\\');

			for (int i=0;i < parts.Length;i+=2)
			{
				switch (parts[i])
				{
					case "mapname":
						if ( parts.Length >= i+1)
							this.serverDetails.Map = parts[i+1];
						break;
					case "hostname":
						if ( parts.Length >= i+1)
							this.serverDetails.Hostname = parts[i+1];
						break;
					case "numplayers":
						if ( parts.Length >= i+1)
							this.serverDetails.PlayerCount = Utility.IntParse(parts[i+1]);
						break;
					case "maxplayers":
						if ( parts.Length >= i+1)
							this.serverDetails.MaxPlayers = Utility.IntParse(parts[i+1]);
						break;
					case "password":
						if ( parts.Length >= i+1)
							this.serverDetails.PasswordProtected = Utility.BoolParse(parts[i+1]);
						break;
					default:
						int f= parts.Length;
						int g = i;
						if ( parts.Length >= i+1 && ! this.serverDetails.AdditionalInfo.ContainsKey(parts[i]) && parts[i] != "queryid" )
						{
							this.serverDetails.AdditionalInfo.Add(parts[i],parts[i+1] );
						}
						break;
				}
			}

		}

		protected virtual void getPlayers(string playerinfo)
		{
			string[] players = Utility.Tokenize("\\player_",playerinfo);

			Player player;
			int playerId;
			int nameEnd;
			int nameStart;
			string name = "";
			string info = "";

			for(int i=0;i < players.Length;i++)
			{
				// Get name
				nameEnd = players[i].IndexOf("\\frags_");
				
				if ( nameEnd != -1 )
				{
					player = new Player();

					name = players[i].Substring(0,nameEnd);
					info = players[i].Substring(nameEnd,players[i].Length - nameEnd);

					// Remove the id\ from the start (should always have this information)
					// [Need to account for player names with \ in]
					nameStart = name.IndexOf("\\");
					if ( nameStart != -1 )
					{
						name = name.Substring(nameStart+1,name.Length - (nameStart +1));
					}
					player.Name = name;

					string[] parts = info.Split('\\');
					for (int n=0;n < parts.Length;n++)
					{
						if ( parts[n].IndexOf("frags_") != -1 && parts.Length > n+1)
						{
							player.Score = Utility.IntParse(parts[n+1]);
						}
						else if ( parts[n].IndexOf("ping_") != -1 && parts.Length > n+1)
						{
							player.Ping = Utility.IntParse(parts[n+1]);
						}
						else if ( parts[n].IndexOf("team_") != -1 && parts.Length > n+1)
						{
							player.Team = Utility.IntParse(parts[n+1]);
						}
					}

					this.serverDetails.Players.Add(player);
				}
			} // end loop around players
		}
		#endregion
	}
}

