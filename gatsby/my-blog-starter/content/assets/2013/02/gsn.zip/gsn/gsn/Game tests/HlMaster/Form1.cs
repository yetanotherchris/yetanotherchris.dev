using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Text;

namespace HlMaster
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.RichTextBox richTextBox1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.button1 = new System.Windows.Forms.Button();
			this.richTextBox1 = new System.Windows.Forms.RichTextBox();
			this.SuspendLayout();
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(480, 256);
			this.button1.Name = "button1";
			this.button1.TabIndex = 0;
			this.button1.Text = "button1";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// richTextBox1
			// 
			this.richTextBox1.Location = new System.Drawing.Point(8, 8);
			this.richTextBox1.Name = "richTextBox1";
			this.richTextBox1.Size = new System.Drawing.Size(544, 240);
			this.richTextBox1.TabIndex = 1;
			this.richTextBox1.Text = "";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(560, 286);
			this.Controls.Add(this.richTextBox1);
			this.Controls.Add(this.button1);
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			UdpClientNew udp = new UdpClientNew();
			udp.SendTimeout = 5000;
			udp.ReceiveTimeout = 5000;
			ArrayList arrayList = udp.QueryMaster();

			this.richTextBox1.Text = "";
			for (int i=0;i < arrayList.Count;i++)
			{
				string ipport = (string) arrayList[i];
				string[] parts = ipport.Split(':');
				this.Ip = parts[0];
				this.Port = int.Parse(parts[1]);

				Thread thread = new Thread(new ThreadStart(queryserver));
				thread.Start();
				
			}
		}

		public string Ip;
		public int Port;

		private void queryserver()
		{
			UdpClientNew udp = new UdpClientNew();
			udp.SendTimeout = 5000;
			
			udp.ReceiveTimeout = 5000;
			string command = "\xff\xff\xff\xffdetails\x0";
			byte[] sendData = Encoding.Default.GetBytes(command);


			IPEndPoint fromIPEndPoint = new IPEndPoint(IPAddress.Any,0);	
			IPEndPoint toIPEndPoint = new IPEndPoint(IPAddress.Parse(this.Ip),this.Port);

			string result = udp.SendReceiveHalfLife(sendData,toIPEndPoint,ref fromIPEndPoint);
			this.richTextBox1.Text += result.Replace("\x0","");
		}
	}
}
