using System;
using System.Net;
using System.Net.Sockets;
using System.Collections;
using System.Text;

namespace Gsn.Games
{
	/// <summary>
	/// 
	/// </summary>
	public class Battlefield1942 : Engines.UT2003
	{				  
		#region Public members
		/// <summary>
		/// See See <see cref="IGameServerQuery.GetServerDetails">IGameServerQuery.GetServerDetails</see>
		/// </summary>
		public override void GetServerDetails(string Ip,int Port)
		{
			this.serverDetails = new Server();
			this.serverDetails.AdditionalInfo = new Hashtable();
			this.serverDetails.Players = new PlayerCollection();

			Gsn.UdpClient udpClient = new Gsn.UdpClient ();

			// Server info
			this.serverDetails.Ip = Ip;
			this.serverDetails.Port = Port;

			string command = "\\status\\";
			udpClient.Timeout = 5000;
			string response = udpClient.QueryGameServer(GameEngineType.UnrealTournament2003,command,Ip,Port);

			if ( response != "" && response.IndexOf("\\final") != -1 && response.IndexOf("\\deaths_") != -1 )
			{
				string playerinfo = "";
				string serverinfo = "";
				int end = response.IndexOf("\\deaths_");

				serverinfo = response.Substring(1,end);

				// Add the teamname info on, this assumes it's
				// at the end of the packet (haven't found a case 
				// where it's not).
				int teamNames = response.IndexOf("\\teamname_");
				if ( teamNames != -1 )
				{
					serverinfo += response.Substring(teamNames,response.Length - teamNames);
				}

				playerinfo = response.Substring(end,response.Length - end);

				// Remove the first \ for tokenising
				playerinfo = playerinfo.Substring(1,playerinfo.Length-1);
				
				// Remove the teamname info if it's there, this assumes it's
				// at the end of the packet (haven't found a case 
				// where it's not).
				teamNames = response.IndexOf("\\teamname_");
				if ( teamNames != -1 )
				{
					response = response.Substring(0,teamNames);
				}

				this.getServerInfo(serverinfo);
				this.getPlayers(playerinfo);
					
			}
			else
			{
				this.serverDetails.Map = "None";
				this.serverDetails.Hostname = "Unable to connect";
			}

			// Fire the event to indicate processing is finished
			if ( this.GetServerDetailsFinished != null )
			{
				this.GetServerDetailsFinished(this,new EventArgs());
			}
		}

		/// <summary>
		/// See <see cref="IGameServerQuery.GetServerList">IGameServerQuery.GetServerList</see>
		/// </summary>
		public override void GetServerList()
		{

		}
		#endregion

		#region Private methods
		protected override void getPlayers(string playerinfo)
		{
			// This method is over-ridden as bf1942 returns the names
			// in a completely different order to UT2003
			string[] players = Utility.Tokenize("\\deaths_",playerinfo);

			Player player;
			int keyHashStart;

			for(int i=0;i < players.Length;i++)
			{
				// Get name
				keyHashStart = players[i].IndexOf("\\keyhash_");
				
				if ( keyHashStart != -1 )
				{
					player = new Player();
					players[i] = players[i].Substring(keyHashStart,players[i].Length - keyHashStart);

					// Remove first \
					players[i] = players[i].Substring(1,players[i].Length -1);

					string[] parts = players[i].Split('\\');
					for (int n=0;n < parts.Length;n++)
					{
						if ( parts[n].IndexOf("playername_") != -1 && parts.Length > n+1)
						{
							player.Name = parts[n+1];
						}
						else if ( parts[n].IndexOf("deaths_") != -1 && Utility.IsNumeric(parts[n]) && parts.Length > n+1)
						{
							player.Deaths = Utility.IntParse(parts[n+1]);
						}
						else if ( parts[n].IndexOf("score_") != -1 && parts.Length > n+1)
						{
							player.Score = Utility.IntParse(parts[n+1]);
						}
						else if ( parts[n].IndexOf("ping_") != -1 && parts.Length > n+1)
						{
							player.Ping = Utility.IntParse(parts[n+1]);
						}
						else if ( parts[n].IndexOf("team_") != -1 && parts.Length > n+1)
						{
							player.Team = Utility.IntParse(parts[n+1]);
						}
						else if ( parts[n].IndexOf("playername_") != -1 && parts.Length > n+1)
						{
							player.Name = parts[n+1];
						}
						else if ( parts[n].IndexOf("keyhash_") != -1 && parts.Length > n+1)
						{
							player.AdditionalInfo.Add("keyhash",parts[n+1]);
						}
					}

					this.serverDetails.Players.Add(player);
				}
			} // end loop around players
			
		}
		#endregion
	}
}

