using System;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Text;
using System.Collections;

namespace HlMaster
{
	public class UdpClientNew : UdpClient
	{

		// Gives us access to the UdpClient's raw socket
		public Socket Socket
		{
			get { return this.Client; }
			set
			{
				if ( value == null )
					throw new ArgumentNullException("Socket", "Socket is null.");
				this.Client = value;
			}
		}

		public int ReceiveTimeout
		{
			get
			{
				Socket s = this.Client;
				return (int)s.GetSocketOption(SocketOptionLevel.Socket,
					SocketOptionName.ReceiveTimeout);
			}
			set
			{
				if ( value < 0 )
					value = 0;
				Socket s = this.Client;
				s.SetSocketOption(SocketOptionLevel.Socket,SocketOptionName.ReceiveTimeout, value);
			}
		}

		public int SendTimeout
		{
			get
			{
				Socket s = this.Client;
				return (int)s.GetSocketOption(SocketOptionLevel.Socket,SocketOptionName.SendTimeout);
			}
			set
			{
				if ( value < 0 )
					value = 0;
				Socket s = this.Client;
				//Uses the Socket returned by Client to set an option that is not available using UdpClient.
				s.SetSocketOption(SocketOptionLevel.Socket,SocketOptionName.SendTimeout, value);
			}
		}

		private int hlMasterRegion = 3;
		protected string masterIp = "208.186.20.40";
		protected int masterPort = 27010;

		public ArrayList QueryMaster()
		{
			//
			// +++ Add a breakpoint here
			//

			ArrayList arrayList = new ArrayList();
			byte byteRegion = 0;
			string lastIp = "";
			string ip  = "0.0.0.0:0";
			
			// Regions are 0 to 7
			if ( this.hlMasterRegion > -1 && this.hlMasterRegion < 8 )
			{
				byteRegion = (byte) this.hlMasterRegion;
			}
			
			// Get this computer's IP
			IPEndPoint IPEndPoint = new IPEndPoint(IPAddress.Any,0);	

			// Encode and send the command
			string command = "1" + byteRegion + "0.0.0.0\x0\\gamedir\\cstrike\x0";
			
			byte[] sendData = Encoding.Default.GetBytes(command);
			sendData[1] = byteRegion;

			this.Send(sendData,sendData.Length,this.masterIp,this.masterPort);

			bool listFinished = false;
			// Get the packet
			byte[] recvData;
			do 
			{
				recvData = this.Receive(ref IPEndPoint);

				// Parse the IPs from the packet
				string data = Encoding.Default.GetString(recvData);
				if ( data != "" )
				{
					string ipPort = "";
					int index = 0;
					string serverIp = "";
					int serverPort = 0;
					string tmp = "";
					
					// First 6 characters are not needed
					data = data.Remove(0,6);

					while ( index < data.Length )
					{
						tmp = data.Substring(index,6);

						serverIp   = (int) ((byte) tmp[0]) +"." +(int) ((byte) tmp[1])+ "." +(int) ((byte) tmp[2])+ "." +(int) ((byte) tmp[3]);
						serverPort = ((byte) tmp[4] *256) + ((byte) tmp[5]);

						ipPort = serverIp+ ":" +serverPort;
						arrayList.Add(ipPort);
						System.Diagnostics.Debug.WriteLine(ipPort);

						if ( ipPort.IndexOf("0.0.0.0") != -1 )
						{
							listFinished = true;
							break;

						}

						index += 6;
						lastIp = ipPort;		
					}
				}

				if ( listFinished )
				{
					break;
				}
				else
				{

					// Send the last ip
					command = "1" + byteRegion + lastIp +"\x00\\gamedir\\cstrike\x00";
					sendData = Encoding.Default.GetBytes(command);
					sendData[1] = byteRegion;
					this.Send(sendData,sendData.Length,this.masterIp,this.masterPort);	
				}
		
			} while ( recvData != null );//this.Socket.Available > 0 );

			return arrayList;

		}
		public string SendReceiveHalfLife(byte[] Command, IPEndPoint DestinationEndPoint, ref IPEndPoint LocalEndPoint)
		{
			if ( Command == null || DestinationEndPoint == null )
				return null;

			byte[] receive;
			string result = "";

			this.Send(Command, Command.Length, DestinationEndPoint); //Send using base's Send();

			int packetCount = 0;
			int packetIndex = 0;
			Hashtable packets = new Hashtable();
			do
			{
				receive = this.Receive(ref LocalEndPoint);

				if ( receive != null )
				{
					string data = Encoding.Default.GetString(receive);

					if ( data != "" )
					{
						// If first byte is 254 then we have multiple packets
						if ( (byte) data[0] == 254 )
						{
							// High order contains count, low order index
							packetCount = ((byte) data[8]) & 15; // indexed from 0
							packetIndex = ((byte) data[8]) >> 4;
							packetCount -= 1;

							packets[packetIndex] = data.Remove(0,9);
						}
						else
						{
							packets[0] = data;
							
						}
					}
					result += Encoding.Default.GetString(receive);
				}

			}while ( this.Socket.Available > 0 && packetIndex < packetCount );

			return result;
		}
	}
}

