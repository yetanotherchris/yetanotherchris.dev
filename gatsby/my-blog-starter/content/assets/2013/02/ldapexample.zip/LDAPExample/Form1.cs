using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.DirectoryServices;
using ActiveDs;
using System.Runtime.InteropServices;
using System.Threading;

namespace LDAPExample
{
	public class Form1 : System.Windows.Forms.Form
	{
		#region Components
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.TreeView treeView1;
		private System.Windows.Forms.ImageList imageList1;
		private System.ComponentModel.IContainer components;
		#endregion

		#region Constructor, dispose,main
		public Form1()
		{
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}
		#endregion

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.panel1 = new System.Windows.Forms.Panel();
			this.treeView1 = new System.Windows.Forms.TreeView();
			this.panel2 = new System.Windows.Forms.Panel();
			this.button1 = new System.Windows.Forms.Button();
			this.imageList1 = new System.Windows.Forms.ImageList(this.components);
			this.panel1.SuspendLayout();
			this.panel2.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.Controls.AddRange(new System.Windows.Forms.Control[] {
																				 this.treeView1});
			this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(592, 182);
			this.panel1.TabIndex = 2;
			// 
			// treeView1
			// 
			this.treeView1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.treeView1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.treeView1.ImageList = this.imageList1;
			this.treeView1.Name = "treeView1";
			this.treeView1.Size = new System.Drawing.Size(592, 182);
			this.treeView1.TabIndex = 0;
			// 
			// panel2
			// 
			this.panel2.Controls.AddRange(new System.Windows.Forms.Control[] {
																				 this.button1});
			this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panel2.Location = new System.Drawing.Point(0, 182);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(592, 48);
			this.panel2.TabIndex = 3;
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(512, 16);
			this.button1.Name = "button1";
			this.button1.TabIndex = 2;
			this.button1.Text = "Geet";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// imageList1
			// 
			this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
			this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
			this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
			this.imageList1.TransparentColor = System.Drawing.Color.Fuchsia;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(592, 230);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.panel1,
																		  this.panel2});
			this.Name = "Form1";
			this.Text = "Form1";
			this.panel1.ResumeLayout(false);
			this.panel2.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		#region Click, make the tree
		private void button1_Click(object sender, System.EventArgs e)
		{
			//
			// Active Directory, note lack of CN, this gets schema
			//
			//DirectoryEntry entry = new DirectoryEntry("LDAP://yourdomainserver/CN=Schema,CN=Configuration,DC=internal,DC=company,DC=com","owta\\chris","dqwe");
			
			//
			// Active Directory, note lack of CN, this gets other objects (users etc.)
			//
			//DirectoryEntry entry = new DirectoryEntry("LDAP://yourdomainserver/DC=internal,DC=company,DC=com","domain\\chris","dqwe");
			
			//
			// OpenLDAP, anonymous
			//
			//DirectoryEntry entry = new DirectoryEntry("LDAP://ldapserver/dc=company,dc=company,dc=com","","",AuthenticationTypes.Anonymous);
			
			//
			// OpenLDAP, authenticated
			//
			//DirectoryEntry entry = new DirectoryEntry("LDAP://ldapserver:389/dc=company,dc=company,dc=com","cn=Manager,dc=internal,dc=owta,dc=net","slapper",AuthenticationTypes.ServerBind);
			
			//
			// Netscape/Sun ONE, anonymous
			//
			//DirectoryEntry entry = new DirectoryEntry("LDAP://athlon:389/dc=company,dc=com","","",AuthenticationTypes.Anonymous);
			
			//
			// Netscape/Sun ONE, authenticated
			//
			//DirectoryEntry entry = new DirectoryEntry("LDAP://athlon:389/dc=company,dc=net","uid=chris,ou=people,dc=company,dc=com","password",AuthenticationTypes.ServerBind);
			
			// IBM default DNs are: SCHEMA,LOCALHOST,PWDPOLICY
			//
			// IBM, anonymous
			//
			//DirectoryEntry entry = new DirectoryEntry("LDAP://athlon:389/CN=LOCALHOST","","",AuthenticationTypes.Anonymous);
			
			//
			// IBM, authenticated
			//
			DirectoryEntry entry = new DirectoryEntry("LDAP://athlon:389/CN=LOCALHOST","cn=root","password",AuthenticationTypes.ServerBind);
			

			// Get the root dn properties
			TreeNode treeNode = new TreeNode(entry.Name);
			TreeNode treeNode1;
			
			foreach (string propName in entry.Properties.PropertyNames) 
			{
				foreach (object value in entry.Properties[propName] ) 
				{
					treeNode1 = new TreeNode( propName + "=" + value);
					treeNode.Nodes.Add(treeNode1);
				}
				Application.DoEvents();
			}
			treeNode.ImageIndex = 1;
			treeNode.SelectedImageIndex = 1;
	
			//
			// Get all the objects and their properties.
			// This takes a long time for even a small
			// Active Directory (~40 computers,~40 users),
			// and takes a very long time with the schema.
			// Expect it take 2 minutes at least.
			//
			// This is because it's loading the whole tree at
			// once, instead of streaming it, which would
			// be the ideal method if this was turned into
			// a proper ldap browser/editor.
			//
			Cursor = Cursors.WaitCursor;
			//makeTree(entry.Children,treeNode);
			Cursor = Cursors.Default;
			treeView1.Nodes.Add(treeNode);
		}

		private void makeTree(DirectoryEntries directoryEntries,TreeNode treeNode)
		{
			LargeInteger li;

			foreach (DirectoryEntry directoryEntry in directoryEntries)
			{	
				TreeNode treeNode1 = new TreeNode( directoryEntry.Name );

				foreach (string propName in directoryEntry.Properties.PropertyNames) 
				{
					foreach (object value in directoryEntry.Properties[propName] ) 
					{
						object val = value;

						//
						// For active directory
						//
						if ( propName == "lastLogon" )
						{
							// Integer8 conversion from http://groups.google.com/groups?threadm=OACdmn5wBHA.2368%40tkmsftngp02
							li = (LargeIntegerClass)Marshal.CreateWrapperOfType(value, typeof(LargeIntegerClass));
							long date = (((long)(li.HighPart) << 32) + (long) li.LowPart);
							Marshal.ReleaseComObject(li);    //Release COM object
							val = DateTime.FromFileTime(date);
						}

						TreeNode treeNode2 = new TreeNode( propName + "=" + val);
						treeNode2.Tag = directoryEntry.Path + "," + propName;
						treeNode2.ForeColor = Color.Blue;
						treeNode1.Nodes.Add(treeNode2);
					}
					Application.DoEvents();
				}
				treeNode1.ImageIndex = 1;
				treeNode.Nodes.Add(treeNode1);
				Application.DoEvents();
				makeTree(directoryEntry.Children,treeNode1);
			}
		}
		#endregion
	}
}
